"""douyin.py 离线单元测试（不触网、不启浏览器）。

对抗式断言：
- 播放地址三种形态都必须能取到（曾真实 KeyError: 0）；
- 质量档位必须真的封顶（选了 480 不能给 1080）；
- 文件名必须去掉抖音标题里的换行/@/话题符；
- aweme_id 提取必须能从「收藏页 modal_id」「分享短链」「裸 id」三种入口命中，
  且不能把时间戳之类无关数字误当 id。
"""
import json
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))

import douyin as dy  # noqa: E402


# ---------- 链接识别 ----------

@pytest.mark.parametrize("url", [
    "https://www.douyin.com/user/self?from_tab_name=main&modal_id=7696507927519875953&showTab=favorite_collection",
    "https://www.douyin.com/video/7696507927519875953",
    "https://v.douyin.com/iAbCdEf/",
    "https://www.iesdouyin.com/share/video/7696507927519875953/",
])
def test_is_douyin_true(url):
    assert dy.is_douyin(url) is True


@pytest.mark.parametrize("url", [
    "https://www.bilibili.com/video/BV1moCdYWEjQ",
    "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
    "not-a-url",
])
def test_is_douyin_false(url):
    assert dy.is_douyin(url) is False


# ---------- aweme_id 提取 ----------

def test_extract_aweme_id_from_modal_id():
    url = ("https://www.douyin.com/user/self?from_tab_name=main"
           "&modal_id=7696507927519875953&showTab=favorite_collection")
    assert dy.extract_aweme_id(url) == "7696507927519875953"


def test_extract_aweme_id_from_video_path():
    assert dy.extract_aweme_id("https://www.douyin.com/video/7696507927519875953") == "7696507927519875953"


def test_extract_aweme_id_bare_id():
    assert dy.extract_aweme_id("7696507927519875953") == "7696507927519875953"


def test_extract_aweme_id_rejects_short_number():
    """逆向断言：13 位以内的数字不是 aweme_id，不能被当成 id（否则会去抓不存在的视频）。"""
    assert dy.extract_aweme_id("https://v.douyin.com/abc/") is None
    assert dy.extract_aweme_id("1234567890123") is None


# ---------- 播放地址解析 ----------

def test_first_url_list_of_dict():
    assert dy.first_url([{"src": "https://a"}]) == "https://a"


def test_first_url_dict_urllist():
    assert dy.first_url({"urlList": ["https://b"]}) == "https://b"


def test_first_url_plain_string():
    assert dy.first_url("https://c") == "https://c"


def test_first_url_empty_is_none():
    assert dy.first_url([]) is None
    assert dy.first_url({}) is None


DETAIL = {
    "awemeId": "7696507927519875953",
    "itemTitle": "AI做代码动画动效大片",
    "desc": "带 #话题 的\n描述",
    "createTime": 1791982895,
    "authorInfo": {"nickname": "卡尔的AI沃茨", "followerCount": 97758},
    "textExtra": [{"hashtagName": "动效设计"}, {"hashtagName": "AI视频"}],
    "video": {
        "duration": 413546,
        "width": 1920,
        "height": 1440,
        "bitRateList": [
            {"playAddr": [{"src": "https://lo"}], "height": 720, "bitRate": 800000, "gearName": "normal_720"},
            {"playAddr": {"urlList": ["https://hi"]}, "height": 1080, "bitRate": 1055074, "gearName": "normal_1080"},
            {"playAddr": [{"src": "https://mid"}], "height": 960, "bitRate": 900000, "gearName": "normal_960"},
        ],
    },
}


def test_pick_stream_best_takes_highest():
    url, info = dy.pick_stream(DETAIL, "best")
    assert url == "https://hi" and info["height"] == 1080


def test_pick_stream_caps_at_720():
    url, info = dy.pick_stream(DETAIL, "720")
    assert url == "https://lo" and info["height"] == 720


def test_pick_stream_480_falls_back_instead_of_empty():
    """逆向：档位低于所有可选流时，宁可给最小的也不返回空。"""
    url, info = dy.pick_stream(DETAIL, "480")
    assert url and info["height"] == 720


def test_pick_stream_no_candidates():
    assert dy.pick_stream({"video": {}}, "best") == (None, {})


def test_pick_stream_falls_back_to_play_api():
    detail = {"video": {"playApi": "https://api"}}
    assert dy.pick_stream(detail, "best")[0] == "https://api"


def test_pick_stream_prefers_bitrate_over_resolution():
    """真实坑：adapt_lowest_1440_1（1440 高、712k）比 normal_1080_0（1080 高、1055k）更糊。
    按分辨率挑 = 主动降质，必须按码率挑。"""
    detail = {"video": {"bitRateList": [
        {"playAddr": [{"src": "https://fake-1440"}], "height": 1440, "bitRate": 712768,
         "gearName": "adapt_lowest_1440_1", "videoFormat": "mp4"},
        {"playAddr": [{"src": "https://real-1080"}], "height": 1080, "bitRate": 1055074,
         "gearName": "normal_1080_0", "videoFormat": "mp4"},
    ]}}
    assert dy.pick_stream(detail, "best")[0] == "https://real-1080"


def test_pick_stream_reads_xhr_snake_case():
    """XHR 接口的形状和 SSR 不一样（bit_rate / play_addr.url_list），不能只认驼峰。"""
    detail = {"video": {"bit_rate": [
        {"play_addr": {"url_list": ["https://s1080"]}, "height": 1080, "bit_rate": 1055074,
         "gear_name": "normal_1080_0", "format": "mp4"},
        {"play_addr": {"url_list": ["https://s720"]}, "height": 720, "bit_rate": 851656,
         "gear_name": "normal_720_0", "format": "mp4"},
    ]}}
    assert dy.pick_stream(detail, "best")[0] == "https://s1080"
    assert dy.pick_stream(detail, "720")[0] == "https://s720"


def test_height_from_gear():
    assert dy._height_from_gear("normal_1080_0") == 1080
    assert dy._height_from_gear("adapt_lowest_1440_1") == 1440
    assert dy._height_from_gear("weird") == 0


def test_pick_stream_uses_gear_when_height_missing():
    """XHR 里 br 不带 height，只看码率会把 -q 720 变成"随便给一档"。"""
    detail = {"video": {"bit_rate": [
        {"play_addr": {"url_list": ["https://g1080"]}, "bit_rate": 1055074,
         "gear_name": "normal_1080_0", "format": "mp4"},
        {"play_addr": {"url_list": ["https://g720"]}, "bit_rate": 851656,
         "gear_name": "normal_720_0", "format": "mp4"},
    ]}}
    assert dy.pick_stream(detail, "720")[0] == "https://g720"


def test_pick_stream_prefers_mp4_over_dash():
    detail = {"video": {"bitRateList": [
        {"playAddr": [{"src": "https://dash"}], "height": 1080, "bitRate": 1200000,
         "gearName": "normal_1080_0", "videoFormat": "dash"},
        {"playAddr": [{"src": "https://mp4"}], "height": 1080, "bitRate": 1055074,
         "gearName": "normal_1080_0", "videoFormat": "mp4"},
    ]}}
    assert dy.pick_stream(detail, "best")[0] == "https://mp4"


# ---------- 元数据 / 文件名 ----------

def test_meta_of_schema():
    m = dy.meta_of(DETAIL)
    assert m["aweme_id"] == "7696507927519875953"
    assert m["author"] == "卡尔的AI沃茨"
    assert m["duration_ms"] == 413546
    assert m["tags"] == ["动效设计", "AI视频"]


def test_sanitize_strips_platform_chars():
    assert dy.sanitize("a/b\nc#话题@人") == "a_b_c_话题_人"


def test_build_filename_has_id_suffix():
    name = dy.build_filename(DETAIL, "7696507927519875953")
    assert name.endswith("-7696507927519875953.mp4")
    assert "\n" not in name


# ---------- profile 目录解析 ----------

def test_default_profile_prefers_auth_dy(tmp_path, monkeypatch):
    monkeypatch.delenv("MEDIA_DOWNLOADER_DOUYIN_PROFILE", raising=False)
    (tmp_path / ".auth-dy").mkdir()
    (tmp_path / ".auth").mkdir()
    assert dy.default_profile(tmp_path).name == ".auth-dy"


def test_default_profile_env_overrides(tmp_path, monkeypatch):
    monkeypatch.setenv("MEDIA_DOWNLOADER_DOUYIN_PROFILE", str(tmp_path / "custom"))
    assert dy.default_profile(tmp_path) == tmp_path / "custom"


def test_default_profile_falls_back_to_auth(tmp_path, monkeypatch):
    monkeypatch.delenv("MEDIA_DOWNLOADER_DOUYIN_PROFILE", raising=False)
    (tmp_path / ".auth").mkdir()
    assert dy.default_profile(tmp_path).name == ".auth"


def test_default_profile_walks_up_from_subdir(tmp_path, monkeypatch):
    """在子目录里跑 skill 时，必须找到工作区根的 .auth-dy，
    不能就地造一个空 profile（真实踩过：772 个浏览器文件塞进 skill 目录）。"""
    monkeypatch.delenv("MEDIA_DOWNLOADER_DOUYIN_PROFILE", raising=False)
    root_auth = tmp_path / ".auth-dy"
    root_auth.mkdir()
    sub = tmp_path / "skills" / "some-skill" / "scripts"
    sub.mkdir(parents=True)
    assert dy.default_profile(sub) == root_auth


def test_default_profile_no_ancestor_falls_back_to_cwd(tmp_path, monkeypatch):
    monkeypatch.delenv("MEDIA_DOWNLOADER_DOUYIN_PROFILE", raising=False)
    assert dy.default_profile(tmp_path) == tmp_path / ".auth-dy"


# ---------- 下载主流程（全 monkeypatch，不触网） ----------

def test_download_rejects_bad_url(tmp_path):
    assert dy.download("https://www.douyin.com/", output_dir=tmp_path) == 3


def test_download_success_writes_file_and_meta(tmp_path, monkeypatch):
    async def fake_fetch(aweme_id, profile, headed, debug_dir=None):
        return DETAIL, [], None

    monkeypatch.setattr(dy, "_fetch", fake_fetch)
    monkeypatch.setattr(dy, "download_file", lambda url, dest, cookies=None: dest.write_bytes(b"x" * 2048))

    rc = dy.download("7696507927519875953", output_dir=tmp_path, print_path=True)
    assert rc == 0
    assert list(tmp_path.glob("*.mp4"))
    assert (tmp_path / "7696507927519875953.meta.json").exists()


def test_download_fails_when_no_detail(tmp_path, monkeypatch):
    async def fake_fetch(aweme_id, profile, headed, debug_dir=None):
        return None, [], None

    monkeypatch.setattr(dy, "_fetch", fake_fetch)
    assert dy.download("7696507927519875953", output_dir=tmp_path) == 3


# ---------- 抖音文章（aweme_type 163） ----------
# 真实坑：文章页也挂一个 duration=0 的 0.9MB "video"，按视频逻辑走会下到一个没用的壳，
# 真正内容在 article_info.article_content 里（JSON 字符串里套 markdown）。

ARTICLE_DETAIL = {
    "aweme_id": "7699018868055919887",
    "aweme_type": 163,
    "desc": "art-motion发布！可能是最有审美的动画skill",
    "create_time": 1792567524,
    "author": {"nickname": "花叔"},
    "article_info": {
        "article_title": "art-motion发布！",
        "article_id": "7699018868055919887",
        "article_content": json.dumps({
            "long_article_abstract": "这是摘要。",
            "markdown": "正文第一段。\n\n![图1](https://p3.example/a.jpeg width=1600 height=900)\n\n正文第二段。",
        }, ensure_ascii=False),
    },
    "video": {"duration": 0, "play_addr": {"url_list": ["https://v/cover.mp4"]}},
}


def test_is_article_by_type_and_by_field():
    assert dy.is_article(ARTICLE_DETAIL) is True
    assert dy.is_article({"aweme_type": 0}) is False
    assert dy.is_article(DETAIL) is False


def test_article_body_splits_json_string():
    body = dy.article_body(ARTICLE_DETAIL)
    assert body["title"] == "art-motion发布！"
    assert body["abstract"] == "这是摘要。"
    assert "正文第一段" in body["markdown"]


def test_extract_aweme_id_from_article_url():
    assert dy.extract_aweme_id("https://www.douyin.com/article/7699018868055919887") == "7699018868055919887"


def test_save_article_localises_images(tmp_path, monkeypatch):
    monkeypatch.setattr(dy, "download_file", lambda url, dest, cookies=None: dest.write_bytes(b"img"))
    md_path = dy.save_article(ARTICLE_DETAIL, "7699018868055919887", tmp_path)
    text = md_path.read_text(encoding="utf-8")
    assert "7699018868055919887-assets/01.jpeg" in text   # 图片链接被换成本地路径
    assert "https://p3.example/a.jpeg" not in text
    assert (tmp_path / "7699018868055919887-assets/01.jpeg").exists()
    assert "这是摘要。" in text


def test_save_article_keeps_remote_url_when_image_fails(tmp_path, monkeypatch):
    def boom(url, dest, cookies=None):
        raise OSError("403")

    monkeypatch.setattr(dy, "download_file", boom)
    text = dy.save_article(ARTICLE_DETAIL, "7699018868055919887", tmp_path).read_text(encoding="utf-8")
    assert "https://p3.example/a.jpeg" in text  # 图挂了也要留原文链接，别静默丢内容


def test_download_routes_article_to_markdown(tmp_path, monkeypatch):
    async def fake_fetch(aweme_id, profile, headed, debug_dir=None):
        return ARTICLE_DETAIL, [], None

    monkeypatch.setattr(dy, "_fetch", fake_fetch)
    monkeypatch.setattr(dy, "download_file", lambda url, dest, cookies=None: dest.write_bytes(b"x"))
    monkeypatch.setattr(dy, "pick_stream", lambda *a, **k: pytest.fail("文章不该走选流"))
    assert dy.download("7699018868055919887", output_dir=tmp_path) == 0
    assert (tmp_path / "7699018868055919887.md").exists()


if __name__ == "__main__":
    sys.exit(pytest.main([__file__, "-v"]))
