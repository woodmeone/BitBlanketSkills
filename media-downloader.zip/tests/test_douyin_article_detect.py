"""回归测试：两个真实 bug（2026-10-24 实测发现）。

bug 1  is_article 只判断 `articleInfo` 字段**是否存在**，而抖音视频页常带一个
        空壳 `articleInfo: {isCartoon: null, hasMore: null}`。
        结果：一条 13 分钟真实视频（awemeType=0、有 playAddr、23 个码率档）
        被误判成文章，最终只落下一个 0.5 KB 的标题 md，视频根本没下。

bug 2  `print("... ✓ ...")` 在 GBK 控制台下抛 UnicodeEncodeError，
        整个下载在"文件已写好、但打印时崩掉"的状态下退出（exit 1），
        看起来像下载失败，实际文件是好的——误导性极强。
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))

import douyin  # noqa: E402


# ---------------------------------------------------------------- bug 1
def test_empty_article_info_is_not_article():
    """空壳 articleInfo（只有 isCartoon/hasMore）不得判成文章。"""
    detail = {
        "awemeType": 0,
        "articleInfo": {"isCartoon": None, "hasMore": None},
        "video": {"playAddr": [{"src": "https://x/a.mp4"}], "duration": 783188},
    }
    assert douyin.is_article(detail) is False


def test_filled_article_info_is_article():
    """真有 article_content 的才是文章。"""
    detail = {
        "articleInfo": {
            "articleContent": '{"markdown": "# 标题\\n正文"}',
            "articleTitle": "某篇文章",
        }
    }
    assert douyin.is_article(detail) is True


def test_snake_case_article_content():
    detail = {"article_info": {"article_content": '{"markdown": "正文"}'}}
    assert douyin.is_article(detail) is True


def test_aweme_type_163_is_article():
    """显式 aweme_type=163 仍按文章处理（老路径不能丢）。"""
    assert douyin.is_article({"awemeType": 163}) is True
    assert douyin.is_article({"aweme_type": "163"}) is True


def test_empty_article_dict_is_not_article():
    assert douyin.is_article({"articleInfo": {}}) is False
    assert douyin.is_article({"articleInfo": None}) is False


def test_no_article_field_is_not_article():
    assert douyin.is_article({"awemeType": 0, "video": {"playDuration": 1}}) is False


# ---------------------------------------------------------------- bug 2
def test_print_safe_helpers_exist():
    """必须有一个"编码安全打印"的出口，或模块顶部已 reconfigure stdout。"""
    import io

    ok = hasattr(douyin, "_safe_print") or hasattr(douyin, "safe_print")
    # 或者模块已经 reconfigure 过 stdout（部分环境 io.TextIOWrapper 才有该方法）
    reconfigured = isinstance(sys.stdout, io.TextIOWrapper) and \
        getattr(sys.stdout, "encoding", "").lower().startswith("utf")
    assert ok or reconfigured or not isinstance(sys.stdout, io.TextIOWrapper)


def test_print_symbols_are_ascii_fallback_safe():
    """关键：不得在 print 里直接嵌非 GBK 字符而不做兜底。"""
    src = (Path(douyin.__file__).parent / "douyin.py").read_text(encoding="utf-8")
    # 若用了 ✓/× 等符号，必须有 safe 打印兜底或 reconfigure
    uses_symbol = any(s in src for s in ("\u2713", "\u2717", "\u00d7"))
    has_guard = ("reconfigure" in src) or ("_safe_print" in src) or ("safe_print" in src)
    assert (not uses_symbol) or has_guard, \
        "print 里有非 ASCII 符号，但没有 reconfigure 或 safe_print 兜底"


# ---------------------------------------------------------------- 视频分支不受影响
def test_normal_video_detail_shape():
    """常规视频 detail：23 档码率、有 playAddr —— 不得被判成文章。"""
    detail = {
        "awemeType": 0,
        "video": {
            "duration": 783188,
            "playAddr": [{"src": "https://x/a.mp4"}],
            "bitRateList": [{"gearName": "normal_1080_0"}] * 23,
        },
        "desc": "某视频",
    }
    assert douyin.is_article(detail) is False
