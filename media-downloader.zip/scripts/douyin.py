#!/usr/bin/env python3
"""抖音单条视频下载（Playwright 复用登录态 + SSR 数据）。

为什么需要这条路：yt-dlp 的 Douyin 提取器现在直接抛
`Fresh cookies (not necessarily logged in) are needed`，带不带浏览器 cookie 都一样
——它要的不是"登录态"，是自己某条接口拿不到的新鲜凭证。换 profile、重新扫码都无效。

本模块改用「被动拦截」思路（与 audience-harvest 同源）：
  真开一次视频页 → 让页面自己证明身份 → 从页面自己吐的数据里取播放地址。

两条数据来源，按顺序试：
  1) XHR `/aweme/v1/web/aweme/detail/`（有时根本不发）
  2) 页面 HTML 里的 `<script id="RENDER_DATA">`（URL-encoded JSON，字段比接口还全）

纯函数（extract_aweme_id / first_url / pick_stream / sanitize / meta_of）与执行分离，
便于离线测试；playwright 只在真正抓取时 import，测试环境无需安装浏览器。
"""
from __future__ import annotations

import argparse
import asyncio
import json
import os
import re
import subprocess
import sys
import urllib.parse
from pathlib import Path

# GBK 控制台下 print('✓') 会抛 UnicodeEncodeError —— 那会在"文件已写好"之后崩，
# 让一次成功的下载看起来像失败（真实踩过）。这里统一改成 UTF-8，失败则退化为
# "遇到不能编码的字符就替换"，绝不因为打印而中断流程。
try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except (AttributeError, ValueError):  # 老 Python / 被重定向的流
    pass

DOUYIN_HOSTS = ("douyin.com", "iesdouyin.com")
DEFAULT_PROFILE_DIRNAME = ".auth-dy"
UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36"
)
_FILENAME_BAD = re.compile(r'[\\/:*?"<>|\r\n\t#@]+')


# ---------------- 纯函数（离线可测） ----------------

def is_douyin(url: str) -> bool:
    """判断链接是否抖音系（含 v.douyin.com 短链、iesdouyin.com 分享页）。"""
    host = urllib.parse.urlparse(url).netloc.lower()
    return any(h in host for h in DOUYIN_HOSTS)


def extract_aweme_id(url_or_id: str) -> str | None:
    """从链接或裸 id 里取 aweme_id。

    覆盖：/video/<id>、?modal_id=<id>、?vid=<id>、分享文本里夹带的 id。
    抖音 id 是 19 位数字（历史上出现过 15–20 位，取 15–20 位数字串）。
    """
    if not url_or_id:
        return None
    if url_or_id.isdigit() and 15 <= len(url_or_id) <= 20:
        return url_or_id
    m = re.search(r"(?:modal_id|aweme_id|vid|item_ids)=(\d{15,20})", url_or_id)
    if m:
        return m.group(1)
    m = re.search(r"/(?:video|note|article|share/video|share/article)/(\d{15,20})", url_or_id)
    if m:
        return m.group(1)
    m = re.search(r"\b(\d{15,20})\b", url_or_id)
    return m.group(1) if m else None


def first_url(addr) -> str | None:
    """抖音的播放地址结构一处一个样，统一取第一个可用字符串。

    实际见过三种：
        [{"src": "https://..."}]          # bitRateList 里
        {"urlList": ["https://..."]}      # 部分节点
        "https://..."                     # playApi
    直接 addr[0]["src"] 会炸（真实踩过 KeyError: 0）。
    """
    if isinstance(addr, str):
        return addr or None
    if isinstance(addr, dict):
        for key in ("urlList", "url_list"):
            lst = addr.get(key)
            if isinstance(lst, list) and lst:
                return first_url(lst)
        return addr.get("src")
    if isinstance(addr, list):
        for item in addr:
            got = first_url(item)
            if got:
                return got
    return None


def _node_get(d: dict, *keys, default=None):
    for k in keys:
        if isinstance(d, dict) and d.get(k) is not None:
            return d[k]
    return default


def _height_from_gear(gear: str) -> int:
    """码率档位名里带分辨率：normal_1080_0 / adapt_lowest_1440_1 / low_720_0。"""
    m = re.search(r"_(\d{3,4})_", gear or "")
    return int(m.group(1)) if m else 0


def pick_stream(detail: dict, quality: str = "best") -> tuple[str | None, dict]:
    """按质量档位挑播放地址。

    返回 (url, info)。info 里带 height/bitrate/gear，方便 agent 报告"实际下到了什么"。
    quality: best/1080/720/480 按 height 上限筛；audio 不在这里处理（由调用方抽轨）。
    """
    video = _node_get(detail, "video", default={}) or {}
    cands: list[dict] = []
    # 同一份视频，SSR 走驼峰（bitRateList），XHR 接口走蛇形（bit_rate），两条都要认
    for br in _node_get(video, "bitRateList", "bit_rate_list", "bit_rate", default=[]) or []:
        url = first_url(_node_get(br, "playAddr", "play_addr")) or _node_get(br, "playApi", "play_api")
        if url:
            gear = _node_get(br, "gearName", "gear_name", default="")
            cands.append({
                "url": url,
                "height": int(_node_get(br, "height", default=0) or 0) or _height_from_gear(gear),
                "bitrate": int(_node_get(br, "bitRate", "bit_rate", default=0) or 0),
                "gear": gear,
                "fmt": _node_get(br, "videoFormat", "format", default=""),
            })
    if not cands:  # 没有码率表就退回 playAddr 一族
        for key in ("playAddr", "play_addr", "playAddrH265", "downloadAddr", "playApi"):
            url = first_url(_node_get(video, key))
            if url:
                cands.append({"url": url, "height": 0, "bitrate": 0, "gear": key, "fmt": ""})
    if not cands:
        return None, {}

    # 同一条视频，抖音会给出 mp4 与 dash 两套几乎相同的档位；能整段下就别要 dash
    # （dash 需要 ffmpeg 合流，多一步失败点）。
    mp4_only = [c for c in cands if c["fmt"] == "mp4"]
    pool = mp4_only or cands

    cap = {"best": 10**9, "1080": 1080, "720": 720, "480": 480}.get(quality, 10**9)
    within = [c for c in pool if c["height"] <= cap]
    # 按码率排，不按分辨率：实测 `adapt_lowest_1440_1`（1440 高、712kbps）
    # 比 `normal_1080_0`（1080 高、1055kbps）还糊，按高度选会挑到更差的那条。
    best = max(within, key=lambda c: (c["bitrate"], c["height"])) if within \
        else min(pool, key=lambda c: (c["height"], -c["bitrate"]))
    return best["url"], {k: best[k] for k in ("height", "bitrate", "gear", "fmt")}


def sanitize(name: str, limit: int = 50) -> str:
    """把标题变成安全文件名（去平台非法字符、去掉话题 @ 与换行）。"""
    name = _FILENAME_BAD.sub("_", name or "").strip(" ._")
    return name[:limit] or "douyin"


def build_filename(detail: dict, aweme_id: str) -> str:
    title = _node_get(detail, "itemTitle", "desc", "title", default="") or ""
    return f"{sanitize(title)}-{aweme_id}.mp4"


def meta_of(detail: dict) -> dict:
    """抽成稳定 schema：以后换站点/换字段名，下游（转录、选题库）不用改。"""
    video = _node_get(detail, "video", default={}) or {}
    author = _node_get(detail, "authorInfo", "author", default={}) or {}
    return {
        "aweme_id": _node_get(detail, "awemeId", "aweme_id"),
        "title": _node_get(detail, "itemTitle", "desc", "title") or "",
        "desc": _node_get(detail, "desc"),
        "create_time": _node_get(detail, "createTime", "create_time"),
        "duration_ms": _node_get(video, "duration"),
        "width": _node_get(video, "width"),
        "height": _node_get(video, "height"),
        "author": _node_get(author, "nickname"),
        "author_sec_uid": _node_get(author, "secUid", "sec_uid"),
        "author_followers": _node_get(author, "followerCount", "follower_count"),
        "tags": [
            t.get("hashtagName") or t.get("hashtag_name")
            for t in (_node_get(detail, "textExtra", "text_extra", default=[]) or [])
            if isinstance(t, dict)
        ],
        "stats": {k: _node_get(detail, k) for k in
                  ("diggCount", "commentCount", "shareCount", "collectCount", "playCount")},
    }


def default_profile(workspace: str | Path | None = None) -> Path:
    """登录态目录：环境变量 > 就近祖先里的 .auth-dy > 就近祖先里的 .auth。

    注意「就近祖先」而不是只用 cwd：agent 常在子目录里跑 skill，若按 cwd 生成，
    Playwright 会在那种地方造一个全新的空 profile（实测把 772 个文件塞进 skill 目录），
    然后当然没登录态。所以这里向上找，找不到才退回 cwd。
    """
    env = os.environ.get("MEDIA_DOWNLOADER_DOUYIN_PROFILE")
    if env:
        return Path(env)
    ws = Path(workspace) if workspace else Path.cwd()
    for name in (DEFAULT_PROFILE_DIRNAME, ".auth"):
        for base in (ws, *ws.resolve().parents):
            cand = base / name
            if cand.is_dir():
                return cand
    return ws / DEFAULT_PROFILE_DIRNAME


# ---------------- 抓取（需要 playwright + 已登录 profile） ----------------

async def _fetch(aweme_id: str, profile: Path, headed: bool, debug_dir: Path | None = None):
    """打开视频页取 detail。返回 (detail, cookies, 页面截图路径 or None)。"""
    from playwright.async_api import async_playwright  # 惰性 import：测试不装浏览器也能过

    captured: list[dict] = []
    pw = await async_playwright().start()
    ctx = await pw.chromium.launch_persistent_context(
        user_data_dir=str(profile),
        headless=not headed,
        viewport={"width": 1440, "height": 900},
        args=["--disable-blink-features=AutomationControlled"],
    )
    page = ctx.pages[0] if ctx.pages else await ctx.new_page()

    async def on_response(resp):
        if any(k in resp.url for k in ("aweme/detail", "aweme/v1/web/aweme")):
            try:
                captured.append({"url": resp.url, "data": await resp.json()})
            except Exception:
                pass

    page.on("response", on_response)
    shot = None
    detail = None
    try:
        for target in (f"https://www.douyin.com/video/{aweme_id}",
                       f"https://www.douyin.com/jingxuan?modal_id={aweme_id}"):
            try:
                await page.goto(target, wait_until="domcontentloaded", timeout=60000)
            except Exception as exc:
                print(f"[douyin] 打开 {target} 失败：{exc}", file=sys.stderr)
            await asyncio.sleep(5)
            for item in captured:
                data = item["data"]
                if isinstance(data, dict):
                    detail = _node_get(data, "aweme_detail", "aweme", "item")
                    if detail:
                        break
            if detail:
                break
            # 兜底：SSR 数据（实测这条才是主路）
            html = await page.content()
            m = re.search(r'id="RENDER_DATA"[^>]*>(.*?)</script>', html, re.S)
            if m:
                try:
                    ssr = json.loads(urllib.parse.unquote(m.group(1)))
                except Exception:
                    ssr = None
                if ssr:
                    detail = _find_video_node(ssr)
            if detail:
                break

        cookies = await ctx.cookies("https://www.douyin.com")
        if debug_dir:
            debug_dir.mkdir(parents=True, exist_ok=True)
            shot = debug_dir / f"{aweme_id}.png"
            try:
                await page.screenshot(path=str(shot))
            except Exception:
                shot = None
    finally:
        await ctx.close()
        await pw.stop()
    return detail, cookies, shot


def _find_video_node(obj):
    """在 SSR 树里找带 video.playAddr/bitRateList 的那个节点。"""
    if isinstance(obj, dict):
        video = obj.get("video")
        if isinstance(video, dict) and ("playAddr" in video or "bitRateList" in video):
            return obj
        for v in obj.values():
            got = _find_video_node(v)
            if got:
                return got
    elif isinstance(obj, list):
        for v in obj:
            got = _find_video_node(v)
            if got:
                return got
    return None


def download_file(url: str, dest: Path, cookies: list[dict] | None = None) -> Path:
    """带 Referer + cookie 直连 CDN 下载（抖音 CDN 校验 Referer，不带会 403）。"""
    import requests

    session = requests.Session()
    session.headers.update({"User-Agent": UA, "Referer": "https://www.douyin.com/"})
    for c in cookies or []:
        session.cookies.set(c["name"], c["value"], domain=c.get("domain"), path=c.get("path", "/"))
    dest.parent.mkdir(parents=True, exist_ok=True)
    with session.get(url, stream=True, timeout=180) as r:
        r.raise_for_status()
        with open(dest, "wb") as f:
            for chunk in r.iter_content(1 << 20):
                f.write(chunk)
    return dest


# ---------------- 抖音文章（aweme_type 163 / business_id=article） ----------------
# 文章页也会带一个 duration=0 的 0.9MB "video"（封面动画），下它没意义；
# 真正的内容在 article_info.article_content 的 markdown 里。

def is_article(detail: dict) -> bool:
    """判断是不是抖音文章。

    历史教训（2026-10-24 实测）：只判断 `articleInfo` **字段是否存在**是错的。
    抖音视频页普遍带一个**空壳** `articleInfo: {isCartoon: null, hasMore: null}`，
    于是真实视频被误判成文章——一条 13 分钟、23 档码率的视频最终只落下一个
    0.5 KB 的标题 md，视频根本没下。

    现在的判据（任一成立才算文章）：
      ① `awemeType == 163`（显式类型）
      ② `articleInfo` 里**真有正文**（articleContent / article_content 非空）
    """
    info = _node_get(detail, "article_info", "articleInfo", default=None)
    if isinstance(info, dict) and info:
        raw = _node_get(info, "article_content", "articleContent", default="") or ""
        if isinstance(raw, str) and raw.strip():
            return True
        if isinstance(raw, dict) and raw:
            return True
        # 有标题也算（极少数文章正文走别的字段）
        title = _node_get(info, "article_title", "articleTitle", default="") or ""
        if isinstance(title, str) and title.strip():
            return True
    return str(_node_get(detail, "aweme_type", "awemeType", default="")) == "163"


def article_body(detail: dict) -> dict:
    """返回 {title, abstract, markdown}。article_content 是"JSON 字符串里套 markdown"。"""
    info = _node_get(detail, "article_info", "articleInfo", default={}) or {}
    raw = _node_get(info, "article_content", "articleContent", default="") or ""
    title = _node_get(info, "article_title", "articleTitle", default="") or \
        _node_get(detail, "desc", default="")
    abstract, markdown = "", ""
    if isinstance(raw, str) and raw.strip().startswith("{"):
        try:
            parsed = json.loads(raw)
            abstract = parsed.get("long_article_abstract") or parsed.get("abstract") or ""
            markdown = parsed.get("markdown") or ""
        except Exception:
            markdown = raw
    elif isinstance(raw, dict):
        abstract = raw.get("long_article_abstract") or ""
        markdown = raw.get("markdown") or ""
    else:
        markdown = str(raw)
    return {"title": title, "abstract": abstract, "markdown": markdown or abstract}


_IMG_MD = re.compile(r"!\[([^\]]*)\]\((\S+?)(?:\s+width=(\d+)\s+height=(\d+))?\)")


def save_article(detail: dict, aweme_id: str, out_dir: Path,
                 cookies: list[dict] | None = None) -> Path:
    """把文章存成 md + 本地图片。返回 md 路径。"""
    body = article_body(detail)
    author = _node_get(_node_get(detail, "authorInfo", "author", default={}) or {}, "nickname", default="")
    created = _node_get(detail, "create_time", "createTime", default=0)
    asset_dir = out_dir / f"{aweme_id}-assets"
    asset_dir.mkdir(parents=True, exist_ok=True)  # 先建目录：单张图下载失败不该影响其它图
    md = body["markdown"]
    n_img = 0

    def repl(m):
        nonlocal n_img
        alt, url, w, h = m.groups()
        n_img += 1
        name = f"{n_img:02d}.jpeg"
        label = alt or f"图{n_img}"
        try:
            download_file(url, asset_dir / name, cookies)
            return f"![{label}]({aweme_id}-assets/{name})"
        except Exception as exc:  # 图挂了也要保留原文链接
            print(f"[douyin] 图片 {n_img} 下载失败：{exc}", file=sys.stderr)
            return f"![{label}]({url})"

    md = _IMG_MD.sub(repl, md)

    header = [
        f"# {body['title']}", "",
        f"> 抖音文章 ｜ id `{aweme_id}` ｜ 作者 {author or '⬜'} ｜ 发布 {created}",
        f"> 原文：https://www.douyin.com/article/{aweme_id}",
        f"> 抓取：由 media-downloader/scripts/douyin.py 保存（图片已本地化到 `{aweme_id}-assets/`）",
        "",
    ]
    if body["abstract"] and body["abstract"] not in md:
        header += ["## 摘要", "", body["abstract"], ""]
    md_path = out_dir / f"{aweme_id}.md"
    md_path.write_text("\n".join(header) + md, encoding="utf-8")
    print(f"[douyin] ✓ 文章 → {md_path.name}（{len(md)} 字，{n_img} 张图）")
    return md_path


def to_audio(video: Path, ffmpeg: str | None) -> Path:
    """抽 mp3（转录用）。ffmpeg 缺失时抛错，不静默产出假文件。"""
    if not ffmpeg:
        raise FileNotFoundError("抽音频需要 ffmpeg；请设置 MEDIA_DOWNLOADER_FFMPEG 或装到 PATH")
    out = video.with_suffix(".mp3")
    subprocess.run(
        [ffmpeg, "-loglevel", "error", "-y", "-i", str(video), "-vn",
         "-ac", "1", "-ar", "16000", "-acodec", "libmp3lame", str(out)],
        check=True,
    )
    return out


def download(
    url: str,
    output_dir: str | Path = "media-downloads",
    quality: str = "best",
    headed: bool = False,
    profile: str | Path | None = None,
    save_meta: bool = True,
    keep_video_when_audio: bool = True,
    ffmpeg: str | None = None,
    print_path: bool = False,
) -> int:
    """抖音下载主流程。返回退出码（0 成功 / 3 拿不到详情 / 4 没有播放地址）。"""
    aweme_id = extract_aweme_id(url)
    if not aweme_id:
        print(f"[douyin] 链接里找不到 aweme_id：{url}", file=sys.stderr)
        return 3

    prof = Path(profile) if profile else default_profile()
    out_dir = Path(output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    detail, cookies, shot = asyncio.run(_fetch(aweme_id, prof, headed))
    if not detail:
        print(
            f"[douyin] 两种路径都没拿到视频详情。检查登录态目录是否存在：{prof}\n"
            "        首次使用请先用该 profile 扫码登录一次抖音。",
            file=sys.stderr,
        )
        return 3

    meta = meta_of(detail)
    if save_meta:
        (out_dir / f"{aweme_id}.meta.json").write_text(
            json.dumps({"meta": meta, "detail": detail}, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

    # 文章（图文/长文）没有真视频：article 页那个 duration=0 的 mp4 只是封面动画
    if is_article(detail):
        md_path = save_article(detail, aweme_id, out_dir, cookies)
        print(json.dumps(meta, ensure_ascii=False))
        if print_path:
            print(str(md_path.resolve()))
        return 0

    play_url, info = pick_stream(detail, "best" if quality == "audio" else quality)
    if not play_url:
        print("[douyin] 没有可用播放地址（可能已下架/私密/需付费）", file=sys.stderr)
        return 4

    dest = out_dir / build_filename(detail, aweme_id)
    if dest.exists() and dest.stat().st_size > 1024:
        print(f"[douyin] 已存在，跳过下载：{dest}")
    else:
        download_file(play_url, dest, cookies)
        got = (f"{info.get('height')}p" if info.get("height") else "分辨率未知")
        rate = (f"@{info.get('bitrate')}bps" if info.get("bitrate") else "码率未知")
        gear = info.get("gear") or "?"
        print(f"[douyin] ✓ {dest.name}  {dest.stat().st_size / 1048576:.1f} MB  {got} {rate} [{gear}]")
        if not info.get("height") and quality not in ("best", "audio"):
            print(f"[douyin] 注意：这条只返回了单一码流，-q {quality} 无法生效，拿到的是可用最好的一档。",
                  file=sys.stderr)

    result = dest
    if quality == "audio":
        result = to_audio(dest, ffmpeg)
        print(f"[douyin] ✓ 音频轨 → {result.name}")
        if not keep_video_when_audio:
            dest.unlink(missing_ok=True)

    print(json.dumps(meta, ensure_ascii=False))
    if print_path:
        print(str(result.resolve()))
    return 0


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="下载抖音单条视频（绕过失效的 yt-dlp 提取器）")
    ap.add_argument("url", help="抖音链接或 aweme_id")
    ap.add_argument("-q", "--quality", default="best", choices=["best", "1080", "720", "480", "audio"])
    ap.add_argument("-o", "--output", default="media-downloads")
    ap.add_argument("--headed", action="store_true", help="显示浏览器窗口（排障用）")
    ap.add_argument("--profile", default=None, help="登录态目录（默认 .auth-dy，可 env 覆盖）")
    ap.add_argument("--no-meta", action="store_true", help="不写 <id>.meta.json")
    ap.add_argument("--drop-video", action="store_true", help="-q audio 时删掉中间 mp4")
    ap.add_argument("--print-path", action="store_true")
    ns = ap.parse_args(argv)

    ffmpeg = None
    try:
        from download import find_ffmpeg  # 同目录复用（脚本内跑）；作为模块导入时忽略
        ffmpeg = find_ffmpeg()
    except Exception:
        ffmpeg = os.environ.get("MEDIA_DOWNLOADER_FFMPEG")

    return download(
        ns.url,
        output_dir=ns.output,
        quality=ns.quality,
        headed=ns.headed,
        profile=ns.profile,
        save_meta=not ns.no_meta,
        keep_video_when_audio=not ns.drop_video,
        ffmpeg=ffmpeg,
        print_path=ns.print_path,
    )


if __name__ == "__main__":
    sys.exit(main())
