---
name: "media-downloader"
description: "给一个视频链接就能把视频下载到工作区 media-downloads/。B站/YouTube 等上千站点走 yt-dlp；抖音走专用通道（Playwright 复用已登录 profile + 解析页面 SSR 数据），因为 yt-dlp 的 Douyin 提取器已失效。支持质量档位、仅音频、浏览器 cookies 解锁高清。当用户说「下载这个视频/这个链接帮我下下来/扒个视频/下载B站视频/下载抖音视频」时调用。"
---

# 视频下载（media-downloader）

把任意视频链接落到工作区的一个固定位置。**一句话：给链接 → 文件出现在 `media-downloads/`。**

## 第一性原理：为什么不直接驱动 media-downloader 的 GUI

[mhogomchungu/media-downloader](https://github.com/mhogomchungu/media-downloader) 是一个 **Qt/C++ 图形界面外壳**，它自己不下载，而是把活转交给 `yt-dlp`、`aria2c`、`wget` 等 CLI 引擎，默认引擎就是 **yt-dlp**。

agent 无法可靠地点击 GUI，但可以直接调用 GUI 背后的引擎——效果完全一致，且可脚本化、可测试。因此本 skill 封装 yt-dlp，并对**引擎已经失效的站点**另开一条"被动拦截"通道（见 §抖音）。

## 两条通道（先选路，再谈参数）

| 站点 | 通道 | 脚本 | 为什么 |
|---|---|---|---|
| B站 / YouTube / 其它 yt-dlp 覆盖的站点 | **yt-dlp** | `scripts/download.py` | 一个引擎通吃 |
| **抖音 / iesdouyin** | **douyin.py（Playwright + SSR）** | `scripts/douyin.py`（`download.py` 自动转发） | yt-dlp 的 Douyin 提取器直接报 `Fresh cookies (not necessarily logged in) are needed`，**带不带 cookie 都一样**，重登录无效 |

路由是自动的：`download.py` 见到 `douyin.com` / `iesdouyin.com` 就转给 `douyin.py`，参数（`-q/-o/--print-path`）照旧。

## 已部署的资产（本工作区实测）

| 资产 | 路径 | 说明 |
|---|---|---|
| yt-dlp | `pip install yt-dlp` → `python -m yt_dlp` | ⚠️ 早期版本的 `tools/bin/yt-dlp.exe` 与 media-downloader 便携版**已从本工作区移除**，不要再找 `tools/` |
| ffmpeg | `**/node_modules/@remotion/compositor-*/ffmpeg.exe` | `find_ffmpeg()` 会自动 glob 到，无需装 PATH |
| 抖音登录态 | `.auth-dy/`（`Chrome` profile） | Playwright 直接复用，不扫码 |

查找顺序：
- yt-dlp：`MEDIA_DOWNLOADER_YTDLP` 环境变量 → `tools/` 内置副本 → PATH 上的 `yt-dlp` → **`python -m yt_dlp`（有 pip 包就用，本机实测走这条）**
- ffmpeg：`MEDIA_DOWNLOADER_FFMPEG` → media-downloader 便携版 → Remotion compositor → PATH
- 抖音 profile：`MEDIA_DOWNLOADER_DOUYIN_PROFILE` → `<ws>/.auth-dy` → `<ws>/.auth`

## 怎么用

一切通过 `scripts/download.py`（抖音也走它，不用换命令）。先定位本 skill 目录（记为 `$SKILL`）：

```bash
python "$SKILL/scripts/download.py" "<链接>"
```

常用形态：

```bash
# 1) 默认：最佳质量，落到 ./media-downloads/
python "$SKILL/scripts/download.py" "https://www.bilibili.com/video/BV1moCdYWEjQ"

# 2) 只要音频（转 mp3）——做字幕/剪辑素材时最省时间
python "$SKILL/scripts/download.py" "<链接>" -q audio

# 3) 限高 720P（未登录 B站 的上限，速度快）
python "$SKILL/scripts/download.py" "<链接>" -q 720

# 4) 解锁 1080P/更高：借用浏览器已登录的 cookies（B站等）
python "$SKILL/scripts/download.py" "<链接>" -q 1080 --cookies-from-browser chrome

# 5) 指定目录 + 打印最终文件路径（agent 需要拿到路径时必加）
python "$SKILL/scripts/download.py" "<链接>" -o "media-downloads/bili" --print-path

# 6) 抖音：链接可以是视频页、收藏页带 modal_id、分享短链，也可以直接给 19 位 id
python "$SKILL/scripts/download.py" "https://www.douyin.com/user/self?modal_id=7696507927519875953" --print-path
```

`--print-path` 会打印最终文件绝对路径，便于直接把路径交给后续 skill（如 asr-subtitle）。

## 抖音通道（专项说明）

### 它做的事

1. `extract_aweme_id()`：从链接里取 19 位 aweme_id（支持 `modal_id=`、`/video/<id>`、`/share/video/<id>`、裸 id）；
2. Playwright `launch_persistent_context(user_data_dir=".auth-dy")` 真开一次视频页——**让页面自证身份**，不逆向签名、不伪造请求；
3. 取数据两条路，按序试：XHR `/aweme/v1/web/aweme/detail/`（**经常根本不发**）→ 页面 `<script id="RENDER_DATA">` 的 SSR JSON（**实测这条才是主路**，字段比接口还全）；
4. `pick_stream()` 按档位选流（码率表里的 `gearName` 如 `normal_1080_0`）；
5. 带 `Referer: https://www.douyin.com/` + cookie 直连 CDN 下载（**不带 Referer 会 403**）；
6. 顺手落一份 `<id>.meta.json`（标题/作者/时长/画幅/话题/互动数 + 全量 detail），下次不用再抓。

### 文章（图文 / 长文）也会被识别

抖音文章（`/article/<id>`，`aweme_type=163`）页面同样挂一个 `duration=0` 的 mp4——那只是封面壳，**下它没意义**。本通道会自动识别并改走文章路径：

- 输出 `<id>.md`：标题 + 作者 + 原文链接 + 正文 markdown；
- 正文里的图片**本地化**到 `<id>-assets/01.jpeg ...` 并把链接改成本地路径（单张失败时保留远程链接，不会静默丢内容）；
- 文章正文藏在 `article_info.article_content` 里，是个 **JSON 字符串里套 markdown**（`long_article_abstract` + `markdown`），要二次解析。

### 已知坑（都已内置处理，列出来是让你别重复踩）

| 现象 | 原因 | 处置 |
|---|---|---|
| `Fresh cookies (not necessarily logged in) are needed` | yt-dlp Douyin 提取器要的不是登录态 | 别修 yt-dlp，走本通道 |
| 拦不到 detail XHR | 页面走 SSR，不发这个请求 | 解析 `RENDER_DATA` |
| `KeyError: 0` | `playAddr` 有三种形态（`[{src}]` / `{urlList}` / 字符串） | `first_url()` 递归取 |
| 打开时弹"扫码享高清"遮罩 | 未登录只影响画质档位 | **视频照常可下**，SSR 数据完整 |
| CDN 403 | 缺 Referer | `download_file()` 已带 |
| 文章下到一个小 mp4 / 内容是空的 | 文章页的播放壳 | 走文章路径，产出 `.md` |

### 前置条件

- 登录态目录（默认 `.auth-dy/`）必须存在且登录过一次抖音；缺了会明确报"请先扫码登录"而不是静默失败。
- 首次使用若 profile 是空的，可加 `--headed` 跑到窗口里手动扫码，之后无头复用。

## 质量档位

| `-q` | 含义 |
|---|---|
| `best`（默认） | 可用最高质量（抖音=码率最高的那档） |
| `1080` / `720` / `480` | 限高，越小越快；**没有低于该档的流时取最接近的一档**，不会悄悄给你 1080 |
| `audio` | 仅音频轨（B站走 yt-dlp 转 mp3；抖音下完 mp4 再用 ffmpeg 抽 16k 单声道 mp3） |

## 执行守则（给 agent 的判断规则）

1. **先看域名再想引擎。** 抖音系→直接信本 skill 的专用通道；其它→yt-dlp。别对抖音反复重试 yt-dlp。
2. **先探测再下载。** 大文件耗时耗流量。不确定链接是否可下时，先前置 `--skip-download --print` 或用 `yt-dlp -F "<链接>"` 看格式表。
3. **默认不下播放列表。** 脚本已强制 `--no-playlist`；用户明确要整列表时才加 `--playlist`。
4. **B站/抖音高清要登录。** 报 `become a premium member` / `missing` 时提示用户（B站用 `--cookies-from-browser chrome`），**不要**擅自替用户读取 cookies 而不告知。
5. **失败先看退出码与末行。** 抖音通道退出码：`3`=拿不到详情（多半 profile 没登录）、`4`=没有播放地址（下架/私密/付费）。
6. **产物归位。** 一律落在工作区内，默认 `media-downloads/`；不要写到工作区外。
7. **合规边界。** 仅下载用户有权获取的内容，不绕过付费墙、不批量爬取他人作品。

## 与 asr-subtitle 串联（下载 → 出字幕）

```bash
python "$SKILL/scripts/download.py" "<链接>" --print-path      # 拿路径
python "<asr-subtitle>/scripts/transcribe.py" "<上一步的路径>"   # 出 srt
```

> 转录视频要先抽音频，asr-subtitle 需要 ffmpeg 在 PATH；把 `find_ffmpeg()` 找到的那个目录临时加进 `$env:PATH` 即可。

## 依赖与故障排查

- Python 3.10+；`yt-dlp`（pip）；抖音通道额外要 `playwright` + `requests`。
- `未找到 yt-dlp 引擎` → `pip install yt-dlp`（脚本会自动退回 `python -m yt_dlp`），或设 `MEDIA_DOWNLOADER_YTDLP`。
- 下载极慢/中断 → 用 `--ytdlp-args --limit-rate 5M` 把任意 yt-dlp 原生参数透传进去（仅 yt-dlp 通道）。
- 想以库形式复用：`download.build_args(...)`、`douyin.pick_stream(...)`、`douyin.first_url(...)` 都是纯函数。

## 测试

```bash
python -m pytest "$SKILL/tests" -q      # 64 项，全离线，不触网、不启浏览器
```

- `test_download.py`：引擎查找优先级、`python -m yt_dlp` 兜底、输出目录解析、参数构造（含"默认禁播放列表"的逆向断言）、未知档位报错、退出码透传、**路由**（抖音必须走抖音通道、B站必须走 yt-dlp）。
- `test_douyin.py`：链接识别、aweme_id 提取（含"13 位数字不是 id"的逆向断言）、`playAddr` 三种形态、档位封顶与降级、元数据 schema、文件名净化、profile 解析优先级、下载主流程（含"拿不到详情返回 3"）、**文章路径**（JSON 字符串解析、图片本地化、图片失败保留远程链接、文章不走选流）。
