"""asr-subtitle 离线单元测试（不联网、不调真实 ASR）。

对抗式审查视角：
- 默认格式必须是 srt（用户硬需求）。
- 视频/音频/非法格式三条分支都要走到。
- 引擎名非法必须报错，绝不静默兜底。
- srt→vtt 转换的时间戳逗号必须换成点（vtt 规范），否则下游播放器解析失败。
"""
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))

import transcribe as tr  # noqa: E402


# ---------- 格式判断 ----------

def test_prepare_audio_passes_through_supported_audio(tmp_path):
    mp3 = tmp_path / "a.mp3"
    mp3.write_bytes(b"x")
    assert tr.prepare_audio(mp3, tmp_path) == mp3


def test_prepare_audio_rejects_unknown_ext(tmp_path):
    bad = tmp_path / "a.pdf"
    bad.write_bytes(b"x")
    with pytest.raises(ValueError):
        tr.prepare_audio(bad, tmp_path)


def test_prepare_audio_calls_extract_for_video(tmp_path, monkeypatch):
    mp4 = tmp_path / "v.mp4"
    mp4.write_bytes(b"x")
    monkeypatch.setattr(tr, "extract_audio", lambda v, d, f=None: d / "v.mp3")
    (tmp_path / "v.mp3").write_bytes(b"y")
    out = tr.prepare_audio(mp4, tmp_path)
    assert out.suffix == ".mp3"


# ---------- 引擎校验 ----------

def test_transcribe_unknown_engine_raises(monkeypatch):
    with pytest.raises(ValueError):
        tr.transcribe(Path("x.mp3"), engine="nope")


def test_default_engine_is_bcut():
    assert tr.DEFAULT_ENGINE == "bcut"
    assert "bcut" in tr.ENGINE_MAP


# ---------- 输出路径解析 ----------

def test_resolve_out_default_same_dir(tmp_path):
    inp = tmp_path / "movie.mp4"
    out = tr.resolve_out(inp, None, "srt")
    assert out == tmp_path / "movie.srt"


def test_resolve_out_dir_expands(tmp_path):
    inp = tmp_path / "movie.mp4"
    out = tr.resolve_out(inp, str(tmp_path / "sub"), "srt")
    assert out == tmp_path / "sub" / "movie.srt"


def test_resolve_out_explicit_file_wins(tmp_path):
    inp = tmp_path / "movie.mp4"
    target = tmp_path / "custom.ass"
    out = tr.resolve_out(inp, str(target), "srt")
    assert out == target


# ---------- 写盘格式分发 ----------

class _FakeSeg:
    def __init__(self, text, s, e):
        self.text, self.start_time, self.end_time = text, s, e

    def to_srt_ts(self):
        s, e = self.start_time, self.end_time
        return f"00:00:0{s},{s}00 --> 00:00:0{e},{e}00"

    @property
    def transcript(self):
        return self.text


class _FakeData:
    def __init__(self):
        self.segments = [_FakeSeg("你好", 0, 1), _FakeSeg("世界", 1, 2)]

    def has_data(self):
        return True

    def to_srt(self, save_path=None):
        text = "\n".join(
            f"{n}\n{s.to_srt_ts()}\n{s.transcript}\n" for n, s in enumerate(self.segments, 1))
        if save_path:
            Path(save_path).write_text(text, encoding="utf-8")
        return text

    def save(self, path):
        if path.endswith(".srt"):
            self.to_srt(save_path=path)
        else:
            Path(path).write_text("saved:" + Path(path).suffix, encoding="utf-8")


def test_write_subtitle_default_srt(tmp_path):
    out = tr.write_subtitle(_FakeData(), tmp_path / "s", "srt")
    assert out.suffix == ".srt" and out.exists()
    assert "你好" in out.read_text(encoding="utf-8")


def test_write_subtitle_txt(tmp_path):
    out = tr.write_subtitle(_FakeData(), tmp_path / "s.txt", "txt")
    assert out.suffix == ".txt"


def test_write_subtitle_vtt_converts_commas(tmp_path):
    out = tr.write_subtitle(_FakeData(), tmp_path / "s", "vtt")
    content = out.read_text(encoding="utf-8")
    assert content.startswith("WEBVTT")
    assert "-->" in content
    assert "," not in content.split("-->")[0].split("\n\n")[-1]  # 时间戳无逗号


def test_write_subtitle_unknown_format_raises(tmp_path):
    with pytest.raises(ValueError):
        tr.write_subtitle(_FakeData(), tmp_path / "s", "pdf")


# ---------- srt→vtt 纯函数 ----------

def test_srt_to_vtt_header_and_dots():
    srt = "1\n00:00:01,000 --> 00:00:02,000\nhi\n"
    vtt = tr._srt_to_vtt(srt)
    assert vtt.startswith("WEBVTT\n\n")
    assert "00:00:01.000 --> 00:00:02.000" in vtt


# ---------- 真实 fixture 冒烟（联网，可选） ----------

def test_real_bcut_on_fixture(tmp_path):
    """端到端：真实调用 BcutASR。无网络时跳过，不阻断离线套件。"""
    fixture = Path(__file__).resolve().parents[1] / "tests" / "fixture.mp3"
    if not fixture.exists():
        pytest.skip("fixture.mp3 缺失")
    import requests
    try:
        requests.get("https://member.bilibili.com", timeout=8)
    except Exception:
        pytest.skip("无网络，跳过真实 ASR 冒烟")
    data = tr.transcribe(fixture, engine="bcut")
    out = tr.write_subtitle(data, tmp_path / "fixture", "srt")
    assert out.exists() and out.stat().st_size > 0


if __name__ == "__main__":
    sys.exit(pytest.main([__file__, "-v"]))
