#!/usr/bin/env python3
"""asr-subtitle skill 核心脚本：音频/视频 → 字幕文件（默认 srt）。

第一性原理：AsrTools 是 PyQt5 GUI，agent 无法无头驱动；但其转录内核
`bk_asr` 是纯 Python 库（依赖仅 requests），可直接 import。故 skill 封装 bk_asr，
默认走 BcutASR（必剪/B站免费接口，最稳）。视频先经 ffmpeg 抽音频再转录。

输出格式默认 srt；用户明确要 txt/ass/json/vtt 时才切换。
"""
from __future__ import annotations

import argparse
import subprocess
import sys
import tempfile
from pathlib import Path

# 让 vendor/bk_asr 可被 import（与 skill 目录同根，软链接后依然成立）
_HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(_HERE.parent / "vendor"))

from bk_asr import BcutASR, JianYingASR, KuaiShouASR  # noqa: E402

ENGINE_MAP = {
    "bcut": BcutASR,
    "jianying": JianYingASR,
    "kuaishou": KuaiShouASR,
}
DEFAULT_ENGINE = "bcut"

# 引擎直接接受的音频格式（BaseASR.SUPPORTED_SOUND_FORMAT）
SUPPORTED_AUDIO = {"flac", "m4a", "mp3", "wav"}
# 需要抽音频的视频容器
VIDEO_EXT = {"mp4", "mkv", "mov", "avi", "webm", "flv", "wmv", "m4v", "ts"}

VALID_FORMATS = {"srt", "txt", "ass", "json", "vtt"}


def find_ffmpeg() -> str | None:
    import shutil
    return shutil.which("ffmpeg")


def extract_audio(video: Path, out_dir: Path, ffmpeg: str | None = None) -> Path:
    """视频 → 16k 单声道 mp3（ASR 友好，体积小）。找不到 ffmpeg 抛错。"""
    ffmpeg = ffmpeg or find_ffmpeg()
    if not ffmpeg:
        raise RuntimeError("未找到 ffmpeg，无法从视频抽取音频。请安装 ffmpeg 或改传音频文件。")
    out = out_dir / (video.stem + ".mp3")
    cmd = [ffmpeg, "-y", "-i", str(video), "-vn", "-ac", "1", "-ar", "16000",
           "-c:a", "libmp3lame", "-q:a", "4", str(out)]
    proc = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace")
    if proc.returncode != 0 or not out.exists():
        raise RuntimeError(f"ffmpeg 抽音频失败：{proc.stderr[-400:]}")
    return out


def prepare_audio(input_path: Path, work_dir: Path) -> Path:
    """输入若是视频则抽音频，若已是支持的音频则原样返回。"""
    ext = input_path.suffix.lower().lstrip(".")
    if ext in SUPPORTED_AUDIO:
        return input_path
    if ext in VIDEO_EXT:
        return extract_audio(input_path, work_dir)
    raise ValueError(
        f"不支持的输入格式 .{ext}；请提供音频（{sorted(SUPPORTED_AUDIO)}）或视频（{sorted(VIDEO_EXT)}）"
    )


def transcribe(audio: Path, engine: str = DEFAULT_ENGINE, use_cache: bool = False):
    """跑 ASR，返回 ASRData。engine 非法时抛 ValueError。"""
    if engine not in ENGINE_MAP:
        raise ValueError(f"未知引擎: {engine}，可选 {sorted(ENGINE_MAP)}")
    asr = ENGINE_MAP[engine](str(audio), use_cache=use_cache)
    return asr.run()


def write_subtitle(asr_data, out_path: Path, fmt: str = "srt") -> Path:
    """按格式写盘。srt/txt/ass/json 走 ASRData.save；vtt 由 srt 转换。"""
    fmt = fmt.lower().lstrip(".")
    if fmt not in VALID_FORMATS:
        raise ValueError(f"未知字幕格式: {fmt}，可选 {sorted(VALID_FORMATS)}")
    out_path = out_path.with_suffix("." + fmt)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    if fmt == "vtt":
        srt_tmp = out_path.with_suffix(".srt.tmp")
        asr_data.to_srt(save_path=str(srt_tmp))
        out_path.write_text(_srt_to_vtt(srt_tmp.read_text(encoding="utf-8")), encoding="utf-8")
        srt_tmp.unlink(missing_ok=True)
    else:
        asr_data.save(str(out_path))
    return out_path


def _srt_to_vtt(srt: str) -> str:
    """极简 srt→vtt 转换：改头、逗号换点。"""
    body = srt.replace(",", ".")
    return "WEBVTT\n\n" + body


def resolve_out(input_path: Path, out: str | None, fmt: str) -> Path:
    if out:
        p = Path(out)
        return p if p.suffix else p / (input_path.stem + "." + fmt)
    return input_path.with_suffix("." + fmt)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="音频/视频 → 字幕（默认 srt）")
    parser.add_argument("input", help="音频或视频文件路径")
    parser.add_argument("-f", "--format", default="srt", choices=sorted(VALID_FORMATS),
                        help="字幕格式（默认 srt）")
    parser.add_argument("-e", "--engine", default=DEFAULT_ENGINE, choices=sorted(ENGINE_MAP),
                        help=f"ASR 引擎（默认 {DEFAULT_ENGINE}）")
    parser.add_argument("-o", "--out", default=None, help="输出路径（默认与输入同名同目录）")
    parser.add_argument("--use-cache", action="store_true", help="启用本地转录缓存")
    ns = parser.parse_args(argv)

    inp = Path(ns.input)
    if not inp.exists():
        print(f"[asr-subtitle] 输入不存在: {inp}", file=sys.stderr)
        return 2

    try:
        with tempfile.TemporaryDirectory(prefix="asr_") as td:
            audio = prepare_audio(inp, Path(td))
            asr_data = transcribe(audio, engine=ns.engine, use_cache=ns.use_cache)
            out = resolve_out(inp, ns.out, ns.format)
            written = write_subtitle(asr_data, out, ns.format)
    except Exception as e:  # noqa: BLE001 —— CLI 边界统一报错
        print(f"[asr-subtitle] 失败: {e}", file=sys.stderr)
        return 1

    if not asr_data.has_data():
        print("[asr-subtitle] 警告：未识别到任何语音内容（可能是纯音乐/静音）。", file=sys.stderr)
    print(f"[asr-subtitle] 已生成 {ns.format.upper()} 字幕 → {written}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
