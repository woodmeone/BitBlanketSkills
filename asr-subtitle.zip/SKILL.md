---
name: "asr-subtitle"
description: "给一个音频或视频文件，直接生成字幕，默认 srt。对接 AsrTools 的转录内核 bk_asr（必剪/剪映/快手免费接口），视频自动经 ffmpeg 抽音频再转录，可选 txt/ass/json/vtt。当用户说「给这个视频/音频出字幕/转录成 srt/扒台词/做字幕」时调用，常与 media-downloader 串联。"
---

# 字幕转录（asr-subtitle）

把音频/视频变成带时间轴的字幕。**一句话：给文件 → 默认得到 `.srt`。**

## 第一性原理：为什么不跑 AsrTools 的 GUI

[WEIFENG2333/AsrTools](https://github.com/WEIFENG2333/AsrTools) 的外壳是 PyQt5 图形界面，agent 无法无头点击。但它真正的转录能力全在内核包 `bk_asr` 里——那是**纯 Python 库，依赖仅 `requests`**，可直接 `import`。

所以本 skill 把 `bk_asr` vendor 进来（`vendor/bk_asr/`，含 ASRData/BaseASR/BcutASR/JianYingASR/KuaiShouASR），直接调用其类，行为与 GUI 完全一致。

## 引擎选择（默认 bcut）

| 引擎 | 服务 | 特点 |
|---|---|---|
| `bcut`（默认） | 必剪（B站） | 免费、中文效果好，**当前唯一稳定可用**；轮询已内置 412 退避容错 |
| `jianying` | 剪映 | 支持字级时间戳；依赖第三方签名服务 `asrtools-update.bkfeng.top`，常不可用 |
| `kuaishou` | 快手 | 接口已被官方禁用（返回 501），仅作占位，勿默认使用 |

> 三个都是**在线**接口，需要网络。默认且推荐 `bcut`。
> **412 风控**：短时间内高频请求 B站查询端点会触发瞬时限流（返回 412 HTML）。脚本已对轮询做退避重试；若仍失败，**等 1–2 分钟再试**，不要连续重跑。

## 怎么用

```bash
# 1) 默认 srt，输出与输入同名同目录
python "$SKILL/scripts/transcribe.py" "<音频或视频路径>"

# 2) 明确要别的格式（仅当用户指定时才用）
python "$SKILL/scripts/transcribe.py" "<路径>" -f txt
python "$SKILL/scripts/transcribe.py" "<路径>" -f ass

# 3) 指定输出目录/文件名
python "$SKILL/scripts/transcribe.py" "<路径>" -o "media-downloads/subs"

# 4) 换引擎
python "$SKILL/scripts/transcribe.py" "<路径>" -e kuaishou
```

`$SKILL` 为本 skill 目录。输入可以是：
- 音频：`.mp3 .wav .m4a .flac`（直接转录）
- 视频：`.mp4 .mkv .mov .webm ...`（先 ffmpeg 抽 16k 单声道 mp3 再转录，需 PATH 上有 ffmpeg）

## 与 media-downloader 串联（下载→出字幕一条龙）

```bash
# 先下视频，拿到最终路径
python "<media-downloader>/scripts/download.py" "<链接>" -q audio --print-path
# 再对下载产物出字幕
python "<asr-subtitle>/scripts/transcribe.py" "<上一步的音频路径>"
```

## 执行守则（给 agent 的判断规则）

1. **格式默认 srt。** 用户没特别说格式，就**绝不**改默认；只有明确要 txt/ass/json/vtt 时才传 `-f`。
2. **视频缺 ffmpeg 会明确报错**，提示装 ffmpeg 或改传音频，不要静默失败。
3. **在线接口有隐私边界**：转录会把音频上传到必剪/剪映/快手服务器。涉及敏感内容（学生隐私、内部资料）时**先告知用户**再跑。
4. **空结果要报告**：纯音乐/静音会得到空字幕，脚本会打印警告——如实转达，别当成成功。
5. **失败重试链**：`bcut` 报错 → 试 `kuaishou` → 仍失败则报告网络/接口问题，不要无限重试。

## 测试

```bash
python -m pytest "$SKILL/tests" -q
```

离线套件覆盖：格式分支、引擎校验、输出路径解析、srt→vtt 时间戳转换、写盘分发。
`test_real_bcut_on_fixture` 为联网冒烟，无网络自动跳过。

## 依赖

- Python 3.10+、`requests`（已具备）。
- 转录视频需 `ffmpeg` 在 PATH（media-downloader 便携版自带，路径 `tools/media-downloader/.../3rdParty/ffmpeg/bin`，如未全局安装可将其加入 PATH）。

## 许可与来源

`vendor/bk_asr/` 来自 [WEIFENG2333/AsrTools](https://github.com/WEIFENG2333/AsrTools)（MIT License），本 skill 内保留了上游 `LICENSE`。对 `BcutASR._run` 的轮询做了本地容错改动（退避重试瞬时 412）。
