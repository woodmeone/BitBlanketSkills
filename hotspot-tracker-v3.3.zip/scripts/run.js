import { chromium } from 'playwright';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const OUTPUT_DIR = process.env.OUTPUT_DIR || path.join(process.cwd(), 'HotSpotReport');
const HEADLESS = process.env.HEADLESS !== 'false';

async function scrapeDouyinHot(browser, retryCount = 0) {
  console.log('\n🎵 开始抓取抖音热榜...');
  
  const context = await browser.newContext({
    userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    viewport: { width: 1920, height: 1080 }
  });
  const page = await context.newPage();

  let hotSearchData = null;
  let trendingApiData = null;
  let creatorTrendingData = null;

  page.on('response', async (response) => {
    const url = response.url();
    try {
      if (url.includes('/hot/search/list') || url.includes('/aweme/v1/web/hot/search/list') || url.includes('/hot/search') || url.includes('aweme/v1/hot')) {
        const json = await response.json();
        console.log('   ✅ 拦截到抖音热榜API响应:', url.substring(0, 80));
        if (!hotSearchData || (json.data && json.data.word_list && json.data.word_list.length > 0)) {
          hotSearchData = json;
        }
      }
      if (url.includes('trending') || url.includes('rising') || url.includes('/hot/search/list')) {
        const json = await response.json();
        if (json.data && json.data.trending_list) {
          console.log('   ✅ 拦截到飙升榜API响应');
          trendingApiData = json;
        }
      }
      if (url.includes('creator.douyin.com') && (url.includes('hot') || url.includes('trending') || url.includes('rank'))) {
        const json = await response.json();
        console.log('   ✅ 拦截到创作者中心API响应:', url.substring(0, 80));
        creatorTrendingData = json;
      }
    } catch (e) {}
  });

  try {
    console.log('   🌐 访问抖音热榜...');
    await page.goto('https://www.douyin.com/hot', {
      waitUntil: 'domcontentloaded',
      timeout: 120000
    });
    console.log('   ⏳ 等待页面加载...');
    await page.waitForTimeout(30000);

    const realtimeList = [];
    const risingList = [];

    console.log('   🔍 检查API数据...');
    if (hotSearchData) {
      console.log('   ✅ 热榜API数据已获取');
    } else {
      console.log('   ⚠️ 未拦截到热榜API数据');
    }
    if (trendingApiData) {
      console.log('   ✅ 飙升榜API数据已获取');
    }

    if (hotSearchData && hotSearchData.data) {
      const d = hotSearchData.data;
      
      if (d.word_list && d.word_list.length > 0) {
        console.log(`   📊 解析实时热点数据(API): ${d.word_list.length} 条`);
        d.word_list.forEach((item, index) => {
          if (item.word && item.word.length > 0) {
            const hotValue = item.hot_value || item.view_count || 0;
            const hotUrl = `https://www.douyin.com/search/${encodeURIComponent(item.word)}?type=hot`;
            realtimeList.push({
              rank: index + 1,
              title: item.word,
              hot: hotValue,
              url: hotUrl
            });
          }
        });
      }
      
      if (d.trending_list && d.trending_list.length > 0) {
        console.log(`   📈 解析飙升热点数据(API): ${d.trending_list.length} 条`);
        d.trending_list.forEach((item, index) => {
          if (item.word && item.word.length > 0) {
            const hotValue = item.hot_value || item.video_count * 10000 || item.discuss_video_count * 10000 || 0;
            const hotUrl = `https://www.douyin.com/search/${encodeURIComponent(item.word)}?type=hot`;
            risingList.push({
              rank: index + 1,
              title: item.word,
              hot: hotValue,
              url: hotUrl
            });
          }
        });
      }
    }

    if (risingList.length < 15) {
      console.log('   📈 尝试访问抖音创作者中心抖音指数页面...');
      
      let creatorPageData = null;
      const creatorPage = await context.newPage();
      
      creatorPage.on('response', async (response) => {
        const url = response.url();
        try {
          if (url.includes('creator.douyin.com') && (url.includes('hot') || url.includes('trending') || url.includes('rank') || url.includes('index'))) {
            const json = await response.json();
            console.log('   ✅ 创作者中心页面拦截到API响应:', url.substring(0, 80));
            creatorPageData = json;
          }
        } catch (e) {}
      });
      
      try {
        await creatorPage.goto('https://creator.douyin.com/creator-micro/home', {
          waitUntil: 'domcontentloaded',
          timeout: 60000
        });
        await creatorPage.waitForTimeout(10000);
        
        if (creatorPageData && creatorPageData.data) {
          const data = creatorPageData.data;
          let trendingItems = [];
          
          if (data.trending_list && data.trending_list.length > 0) {
            trendingItems = data.trending_list;
          } else if (data.hot_list && data.hot_list.length > 0) {
            trendingItems = data.hot_list;
          } else if (data.rising_list && data.rising_list.length > 0) {
            trendingItems = data.rising_list;
          } else if (data.word_list && data.word_list.length > 0) {
            trendingItems = data.word_list;
          } else if (Array.isArray(data)) {
            trendingItems = data;
          }
          
          if (trendingItems.length > risingList.length) {
            risingList.length = 0;
            trendingItems.forEach((item, index) => {
              const title = item.word || item.title || item.name || item.text || '';
              if (title && title.length > 0) {
                const hotValue = item.hot_value || item.hot || item.heat || item.view_count || 0;
                const hotUrl = `https://www.douyin.com/search/${encodeURIComponent(title)}?type=hot`;
                risingList.push({
                  rank: index + 1,
                  title: title,
                  hot: hotValue,
                  url: hotUrl
                });
              }
            });
            console.log(`   📈 从创作者中心API获取飙升榜: ${risingList.length} 条`);
          }
        }
        
        if (risingList.length < 15) {
          console.log('   📈 从创作者中心页面DOM提取飙升榜数据...');
          const pageRisingData = await creatorPage.evaluate(() => {
            const items = [];
            const seen = new Set();
            
            const extractHotValue = (element) => {
              const allText = element.innerText || '';
              const hotMatch = allText.match(/(\d+(?:\.\d+)?)[\s]*(万|亿)/);
              if (hotMatch) {
                const num = parseFloat(hotMatch[1]);
                if (hotMatch[2] === '亿') return num * 100000000;
                if (hotMatch[2] === '万') return num * 10000;
              }
              return 0;
            };

            const allLinks = document.querySelectorAll('a[href*="/search/"], a[href*="hot"], [class*="hot-item"], [class*="trending"]');
            allLinks.forEach((link) => {
              const title = link.textContent?.trim().split('\n')[0]?.trim() || '';
              const href = link.href || '';
              
              if (title.length < 2 || title.length > 50) return;
              if (seen.has(title)) return;
              
              const parent = link.closest('[class*="item"], [class*="Item"], li, div, tr');
              const hotValue = parent ? extractHotValue(parent) : 0;
              
              seen.add(title);
              items.push({
                rank: items.length + 1,
                title: title,
                hot: hotValue,
                url: href || 'https://www.douyin.com/hot'
              });
            });
            
            return items;
          });
          
          if (pageRisingData.length > risingList.length) {
            risingList.length = 0;
            risingList.push(...pageRisingData);
            console.log(`   📈 从创作者中心DOM提取飙升榜: ${risingList.length} 条`);
          }
        }
      } catch (e) {
        console.log('   ⚠️ 访问创作者中心页面失败:', e.message);
      } finally {
        await creatorPage.close();
      }
    }

    if (risingList.length < 15) {
      console.log('   📈 尝试访问飙升榜专用页面...');
      
      let risingPageData = null;
      const risingPage = await context.newPage();
      
      risingPage.on('response', async (response) => {
        const url = response.url();
        try {
          if (url.includes('/hot/search/list') || url.includes('/aweme/v1/web/hot/search/list')) {
            const json = await response.json();
            if (json.data && json.data.trending_list) {
              console.log('   ✅ 飙升榜页面拦截到API响应');
              risingPageData = json;
            }
          }
        } catch (e) {}
      });
      
      try {
        await risingPage.goto('https://www.douyin.com/hot?tab=1', {
          waitUntil: 'domcontentloaded',
          timeout: 60000
        });
        await risingPage.waitForTimeout(15000);
        
        if (risingPageData && risingPageData.data && risingPageData.data.trending_list) {
          const trendingList = risingPageData.data.trending_list;
          if (trendingList.length > risingList.length) {
            risingList.length = 0;
            trendingList.forEach((item, index) => {
              if (item.word && item.word.length > 0) {
                const hotValue = item.hot_value || item.video_count * 10000 || item.discuss_video_count * 10000 || 0;
                const hotUrl = `https://www.douyin.com/search/${encodeURIComponent(item.word)}?type=hot`;
                risingList.push({
                  rank: index + 1,
                  title: item.word,
                  hot: hotValue,
                  url: hotUrl
                });
              }
            });
            console.log(`   📈 从飙升榜页面API获取: ${risingList.length} 条`);
          }
        }
      } catch (e) {
        console.log('   ⚠️ 访问飙升榜页面失败:', e.message);
      } finally {
        await risingPage.close();
      }
    }

    if (risingList.length < 15) {
      console.log('   📈 尝试点击飙升榜tab获取更多数据...');
      
      try {
        const risingTabSelectors = [
          'div:has-text("飙升榜")',
          'span:has-text("飙升榜")',
          'div:has-text("飙升")',
          'span:has-text("飙升")',
          '[class*="tab"]:nth-child(2)',
          '[class*="Tab"]:nth-child(2)',
          'div[role="tab"]:nth-child(2)',
          '[class*="rising"]',
          '[class*="Rising"]',
          '[class*="trending"]',
          '[class*="Trending"]'
        ];
        
        for (const selector of risingTabSelectors) {
          try {
            const tab = await page.$(selector);
            if (tab) {
              const isVisible = await tab.isVisible();
              if (!isVisible) continue;
              
              await tab.click();
              console.log(`   ✅ 点击飙升榜tab: ${selector}`);
              await page.waitForTimeout(5000);
              break;
            }
          } catch (e) {}
        }
        
        console.log('   📈 滚动页面加载更多飙升榜数据...');
        for (let i = 0; i < 15; i++) {
          await page.evaluate(() => {
            window.scrollBy(0, 800);
          });
          await page.waitForTimeout(2000);
        }
        
        console.log('   📈 从页面DOM提取飙升榜数据...');
        const pageRisingData = await page.evaluate(() => {
          const items = [];
          const seen = new Set();
          
          const extractHotValue = (element) => {
            const allText = element.innerText || '';
            const hotMatch = allText.match(/(\d+(?:\.\d+)?)[\s]*(万|亿)/);
            if (hotMatch) {
              const num = parseFloat(hotMatch[1]);
              if (hotMatch[2] === '亿') return num * 100000000;
              if (hotMatch[2] === '万') return num * 10000;
            }
            return 0;
          };

          const allLinks = document.querySelectorAll('a[href*="/search/"]');
          allLinks.forEach((link) => {
            const title = link.textContent?.trim().split('\n')[0]?.trim() || '';
            const href = link.href || '';
            
            if (title.length < 2 || title.length > 50) return;
            if (seen.has(title)) return;
            
            const parent = link.closest('[class*="item"], [class*="Item"], li, div');
            const hotValue = parent ? extractHotValue(parent) : 0;
            
            seen.add(title);
            items.push({
              rank: items.length + 1,
              title: title,
              hot: hotValue,
              url: href || 'https://www.douyin.com/hot'
            });
          });
          
          return items;
        });
        
        if (pageRisingData.length > risingList.length) {
          risingList.length = 0;
          risingList.push(...pageRisingData);
          console.log(`   📈 从点击后DOM提取飙升榜: ${risingList.length} 条`);
        }
      } catch (e) {
        console.log('   ⚠️ 点击飙升榜tab失败:', e.message);
      }
    }

    if (risingList.length < 15 && realtimeList.length > 15) {
      console.log('   📈 从实时热点列表补充飙升榜数据...');
      const risingTitles = new Set(risingList.map(item => item.title));
      const supplementItems = realtimeList.slice(15, 30).filter(item => !risingTitles.has(item.title));
      supplementItems.forEach((item, index) => {
        if (risingList.length < 15) {
          risingList.push({
            rank: risingList.length + 1,
            title: item.title,
            hot: item.hot,
            url: item.url
          });
        }
      });
      console.log(`   📈 飙升榜数据补充后: ${risingList.length} 条`);
    }

    if (risingList.length < 15) {
      console.log('   📈 从页面DOM提取飙升榜数据...');
      const pageRisingData = await page.evaluate(() => {
        const items = [];
        const seen = new Set();
        
        const extractHotValue = (element) => {
          const allText = element.innerText || '';
          const hotMatch = allText.match(/(\d+(?:\.\d+)?)[\s]*(万|亿)/);
          if (hotMatch) {
            const num = parseFloat(hotMatch[1]);
            if (hotMatch[2] === '亿') return num * 100000000;
            if (hotMatch[2] === '万') return num * 10000;
          }
          return 0;
        };

        const risingContainers = document.querySelectorAll(
          '[class*="rising"], [class*="Rising"], [class*="trending"], [class*="Trending"], ' +
          '[class*="飙升"], section:nth-child(2), div:nth-child(2) [class*="list"]'
        );
        
        risingContainers.forEach((container) => {
          const links = container.querySelectorAll('a[href*="/search/"]');
          links.forEach((link) => {
            const title = link.textContent?.trim().split('\n')[0]?.trim() || '';
            const href = link.href || '';
            
            if (title.length < 2 || title.length > 50) return;
            if (seen.has(title)) return;
            
            const parent = link.closest('[class*="item"], [class*="Item"], li, div');
            const hotValue = parent ? extractHotValue(parent) : 0;
            
            seen.add(title);
            items.push({
              rank: items.length + 1,
              title: title,
              hot: hotValue,
              url: href || 'https://www.douyin.com/hot'
            });
          });
        });

        if (items.length < 15) {
          const allLinks = document.querySelectorAll('a[href*="/search/"]');
          const allItems = [];
          const allSeen = new Set();
          
          allLinks.forEach((link) => {
            const title = link.textContent?.trim().split('\n')[0]?.trim() || '';
            if (title.length >= 2 && title.length <= 50 && !allSeen.has(title)) {
              allSeen.add(title);
              const parent = link.closest('[class*="item"], [class*="Item"], li, div');
              const hotValue = parent ? extractHotValue(parent) : 0;
              allItems.push({
                title: title,
                hot: hotValue,
                url: link.href || 'https://www.douyin.com/hot'
              });
            }
          });
          
          allItems.slice(15, 30).forEach((item, index) => {
            if (!seen.has(item.title)) {
              seen.add(item.title);
              items.push({
                rank: items.length + 1,
                ...item
              });
            }
          });
        }

        return items;
      });

      if (pageRisingData.length > risingList.length) {
        risingList.length = 0;
        risingList.push(...pageRisingData);
        console.log(`   📈 从DOM提取飙升榜: ${risingList.length} 条`);
      }
    }

    if (realtimeList.length < 15) {
      console.log('   📊 从页面DOM提取实时热点数据...');
      const pageRealtimeData = await page.evaluate(() => {
        const items = [];
        const seen = new Set();
        
        const extractHotValue = (element) => {
          const allText = element.innerText || '';
          const hotMatch = allText.match(/(\d+(?:\.\d+)?)[\s]*(万|亿)/);
          if (hotMatch) {
            const num = parseFloat(hotMatch[1]);
            if (hotMatch[2] === '亿') return num * 100000000;
            if (hotMatch[2] === '万') return num * 10000;
          }
          return 0;
        };

        const realtimeContainers = document.querySelectorAll(
          '[class*="realtime"], [class*="Realtime"], [class*="hot-list"], [class*="HotList"], ' +
          '[class*="word-list"], section:first-child, div:first-child [class*="list"]'
        );
        
        realtimeContainers.forEach((container) => {
          const links = container.querySelectorAll('a[href*="/search/"]');
          links.forEach((link) => {
            const title = link.textContent?.trim().split('\n')[0]?.trim() || '';
            const href = link.href || '';
            
            if (title.length < 2 || title.length > 50) return;
            if (seen.has(title)) return;
            
            const parent = link.closest('[class*="item"], [class*="Item"], li, div');
            const hotValue = parent ? extractHotValue(parent) : 0;
            
            seen.add(title);
            items.push({
              rank: items.length + 1,
              title: title,
              hot: hotValue,
              url: href || 'https://www.douyin.com/hot'
            });
          });
        });

        if (items.length < 15) {
          const allLinks = document.querySelectorAll('a[href*="/search/"]');
          const allSeen = new Set();
          
          allLinks.forEach((link) => {
            const title = link.textContent?.trim().split('\n')[0]?.trim() || '';
            if (title.length >= 2 && title.length <= 50 && !allSeen.has(title)) {
              allSeen.add(title);
              const parent = link.closest('[class*="item"], [class*="Item"], li, div');
              const allText = parent ? parent.innerText : '';
              const hotMatch = allText.match(/(\d+(?:\.\d+)?)[\s]*(万|亿)/);
              let hotValue = 0;
              if (hotMatch) {
                const num = parseFloat(hotMatch[1]);
                hotValue = hotMatch[2] === '亿' ? num * 100000000 : num * 10000;
              }
              items.push({
                rank: items.length + 1,
                title: title,
                hot: hotValue,
                url: link.href || 'https://www.douyin.com/hot'
              });
            }
          });
        }

        return items;
      });

      if (pageRealtimeData.length > realtimeList.length) {
        realtimeList.length = 0;
        realtimeList.push(...pageRealtimeData);
        console.log(`   📊 从DOM提取实时热点: ${realtimeList.length} 条`);
      }
    }

    console.log(`   📊 抖音实时热点: ${realtimeList.length} 条数据`);
    console.log(`   📈 抖音飙升热点: ${risingList.length} 条数据`);
    
    return { 
      platform: 'douyin', 
      source: '抖音热榜', 
      source_url: 'https://www.douyin.com/hot', 
      hot_list: realtimeList.slice(0, 15),
      rising_list: risingList.slice(0, 15)
    };
  } catch (error) {
    console.error('   ❌ 抖音抓取失败:', error.message);
    if (retryCount < 2) {
      console.log(`   🔄 准备重试 (${retryCount + 1}/2)...`);
      await context.close();
      return scrapeDouyinHot(browser, retryCount + 1);
    }
    return { platform: 'douyin', source: '抖音热榜', source_url: 'https://www.douyin.com/hot', hot_list: [], rising_list: [], error: error.message };
  } finally {
    await context.close();
  }
}

async function scrapeWeiboHot(browser) {
  console.log('\n📱 开始抓取微博热搜榜...');
  
  const context = await browser.newContext({
    userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    viewport: { width: 1920, height: 1080 }
  });
  const page = await context.newPage();

  try {
    console.log('   🌐 访问微博热搜...');
    await page.goto('https://s.weibo.com/top/summary', {
      waitUntil: 'domcontentloaded',
      timeout: 60000
    });
    await page.waitForTimeout(10000);

    const hotList = [];
    
    const pageItems = await page.evaluate(() => {
      const items = [];
      const seenTitles = new Set();
      
      const rows = document.querySelectorAll('tbody tr, table tr');
      rows.forEach((row, i) => {
        const titleEl = row.querySelector('td:nth-child(2) a, a');
        const title = titleEl ? titleEl.textContent?.trim() : '';
        const href = titleEl?.href || '';
        
        const hotEl = row.querySelector('td:nth-child(3), .hot');
        let hotText = hotEl ? hotEl.textContent?.trim() : '0';
        let hotValue = 0;
        if (hotText.includes('万')) {
          hotValue = parseFloat(hotText.replace('万', '')) * 10000;
        } else if (hotText.includes('亿')) {
          hotValue = parseFloat(hotText.replace('亿', '')) * 100000000;
        } else {
          hotValue = parseInt(hotText.replace(/[^0-9]/g, '')) || 0;
        }
        
        if (title && title.length > 2 && !seenTitles.has(title) && !title.includes('登录')) {
          seenTitles.add(title);
          items.push({
            rank: items.length + 1,
            title: title,
            hot: hotValue,
            url: href || 'https://s.weibo.com/top/summary',
            author: '',
            category: '微博'
          });
        }
      });
      return items;
    });
    hotList.push(...pageItems);

    console.log(`   📊 微博热搜榜: ${hotList.length} 条数据`);
    return { platform: 'weibo', source: '微博热搜榜', source_url: 'https://s.weibo.com/top/summary', hot_list: hotList.slice(0, 15) };
  } catch (error) {
    console.error('   ❌ 微博热搜抓取失败:', error.message);
    return { platform: 'weibo', source: '微博热搜榜', source_url: 'https://s.weibo.com/top/summary', hot_list: [], error: error.message };
  } finally {
    await context.close();
  }
}

async function scrapeBilibiliHot(browser) {
  console.log('\n📺 开始抓取B站热榜...');
  
  const context = await browser.newContext({
    userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    viewport: { width: 1920, height: 1080 }
  });
  const page = await context.newPage();

  let rankData = null;

  page.on('response', async (response) => {
    const url = response.url();
    if (url.includes('/x/web-interface/rank') || url.includes('/rank/v2') || url.includes('/popular/rank')) {
      try {
        const json = await response.json();
        console.log('   ✅ 拦截到B站排名API响应');
        rankData = json;
      } catch (e) {}
    }
  });

  try {
    await page.goto('https://www.bilibili.com/v/popular/rank/all', {
      waitUntil: 'domcontentloaded',
      timeout: 60000
    });
    await page.waitForTimeout(10000);

    const hotList = [];
    if (rankData && rankData.data) {
      const list = rankData.data.list || rankData.data.rank_list || rankData.data || [];
      list.forEach((item, index) => {
        const videoUrl = item.short_link_v2 || item.url || `https://www.bilibili.com/video/${item.bvid}`;
        hotList.push({
          rank: index + 1,
          title: item.title || item.name || '',
          hot: item.stat?.view || item.play || item.hot || 0,
          url: videoUrl,
          author: item.owner?.name || item.author || '',
          category: item.tname || item.category || ''
        });
      });
    }

    if (hotList.length === 0) {
      console.log('   ⚠️ API数据为空，尝试从页面提取...');
      const pageItems = await page.evaluate(() => {
        const items = [];
        const rankItems = document.querySelectorAll('.rank-item, [class*="rank-item"], li');
        rankItems.forEach((item, index) => {
          const titleEl = item.querySelector('.title, [class*="title"], a');
          const title = titleEl ? titleEl.textContent.trim() : '';
          const linkEl = item.querySelector('a[href*="/video/"]');
          const url = linkEl ? linkEl.href : '';
          if (title && url) {
            items.push({
              rank: index + 1,
              title: title,
              hot: 0,
              url: url,
              author: '',
              category: ''
            });
          }
        });
        return items;
      });
      hotList.push(...pageItems);
    }

    console.log(`   📊 B站热榜: ${hotList.length} 条数据`);
    return { platform: 'bilibili', source: 'B站热榜', source_url: 'https://www.bilibili.com/v/popular/rank/all', hot_list: hotList };
  } catch (error) {
    console.error('   ❌ B站抓取失败:', error.message);
    return { platform: 'bilibili', source: 'B站热榜', source_url: 'https://www.bilibili.com/v/popular/rank/all', hot_list: [], error: error.message };
  } finally {
    await context.close();
  }
}

async function scrapeXiaohongshuHot(browser) {
  console.log('\n📕 开始抓取小红书热榜...');
  
  const context = await browser.newContext({
    userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    viewport: { width: 1920, height: 1080 }
  });
  const page = await context.newPage();

  let hotSearchData = null;

  page.on('response', async (response) => {
    const url = response.url();
    try {
      if (url.includes('/api/sns/web/v1/search/hot') || 
          url.includes('/api/sns/web/v1/hot_search') ||
          url.includes('/api/sns/web/v1/hot') ||
          url.includes('/api/sns/web/v2/search/hotlist')) {
        const json = await response.json();
        console.log('   ✅ 拦截到小红书热榜API响应:', url);
        hotSearchData = json;
      }
    } catch (e) {}
  });

  try {
    console.log('   🌐 访问小红书首页...');
    await page.goto('https://www.xiaohongshu.com/', {
      waitUntil: 'domcontentloaded',
      timeout: 60000
    });
    await page.waitForTimeout(5000);
    
    console.log('   🌐 点击搜索框触发热榜...');
    try {
      await page.click('input[type="text"], [class*="search-input"], [placeholder*="搜索"]');
      await page.waitForTimeout(3000);
    } catch (e) {
      console.log('   ⚠️ 点击搜索框失败');
    }
    
    console.log('   🌐 访问小红书热榜页面...');
    await page.goto('https://www.xiaohongshu.com/search_result?keyword=&source=hot_search', {
      waitUntil: 'domcontentloaded',
      timeout: 60000
    });
    await page.waitForTimeout(8000);

    const hotList = [];
    
    if (hotSearchData && hotSearchData.data) {
      console.log('   📊 从热榜API解析数据...');
      const items = hotSearchData.data.items || hotSearchData.data.list || hotSearchData.data.queries || hotSearchData.data.searchHotList || hotSearchData.data.hotList || [];
      items.forEach((item, index) => {
        const title = item.query || item.text || item.word || item.title || item.searchWord || item.name || '';
        const hotValue = item.hot_value || item.heat || item.score || item.hotValue || item.hot || 0;
        if (title && title.length > 1) {
          hotList.push({
            rank: index + 1,
            title: title,
            hot: hotValue,
            url: `https://www.xiaohongshu.com/search_result?keyword=${encodeURIComponent(title)}`,
            author: '',
            category: item.type || ''
          });
        }
      });
    }
    
    if (hotList.length < 15) {
      console.log('   ⚠️ API数据不足，尝试从页面DOM提取热榜...');
      const pageItems = await page.evaluate(() => {
        const items = [];
        const seenTitles = new Set();
        
        const hotItems = document.querySelectorAll('[class*="hot-item"], [class*="HotItem"], [class*="trend"], [class*="Trend"], [class*="search-hot"]');
        hotItems.forEach((item) => {
          const text = item.textContent?.trim() || '';
          if (text && text.length > 1 && text.length < 100 && !seenTitles.has(text)) {
            seenTitles.add(text);
            items.push({
              rank: items.length + 1,
              title: text,
              hot: 0,
              url: `https://www.xiaohongshu.com/search_result?keyword=${encodeURIComponent(text)}`,
              author: '',
              category: ''
            });
          }
        });
        
        if (items.length < 10) {
          const allLinks = document.querySelectorAll('a[href*="search_result"], a[href*="search"]');
          allLinks.forEach((link) => {
            const text = link.textContent?.trim() || '';
            if (text && text.length > 2 && text.length < 50 && !seenTitles.has(text)) {
              seenTitles.add(text);
              items.push({
                rank: items.length + 1,
                title: text,
                hot: 0,
                url: link.href || `https://www.xiaohongshu.com/search_result?keyword=${encodeURIComponent(text)}`,
                author: '',
                category: ''
              });
            }
          });
        }
        
        if (items.length < 10) {
          const allText = document.body.innerText || '';
          const lines = allText.split('\n').filter(l => l.trim().length > 2 && l.trim().length < 50);
          lines.forEach((line) => {
            const text = line.trim();
            if (text && !seenTitles.has(text) && !text.includes('小红书') && !text.includes('登录')) {
              seenTitles.add(text);
              items.push({
                rank: items.length + 1,
                title: text,
                hot: 0,
                url: `https://www.xiaohongshu.com/search_result?keyword=${encodeURIComponent(text)}`,
                author: '',
                category: ''
              });
            }
          });
        }
        
        return items;
      });
      
      pageItems.forEach(item => {
        if (!hotList.find(h => h.title === item.title)) {
          hotList.push(item);
        }
      });
    }
    
    const uniqueList = [];
    const seenTitles = new Set();
    for (const item of hotList) {
      if (!seenTitles.has(item.title) && item.title.length > 1) {
        seenTitles.add(item.title);
        uniqueList.push({
          ...item,
          rank: uniqueList.length + 1
        });
      }
    }

    console.log(`   📊 小红书热榜: ${uniqueList.length} 条数据`);
    return { platform: 'xiaohongshu', source: '小红书热榜', source_url: 'https://www.xiaohongshu.com/search_result?keyword=&source=hot_search', hot_list: uniqueList.slice(0, 15) };
  } catch (error) {
    console.error('   ❌ 小红书抓取失败:', error.message);
    return { platform: 'xiaohongshu', source: '小红书热榜', source_url: 'https://www.xiaohongshu.com/search_result?keyword=&source=hot_search', hot_list: [], error: error.message };
  } finally {
    await context.close();
  }
}

async function scrapeGitHubTrending(browser) {
  console.log('\n🐙 开始抓取GitHub Trending Weekly...');
  
  const context = await browser.newContext({
    userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    viewport: { width: 1920, height: 1080 }
  });
  const page = await context.newPage();

  try {
    console.log('   🌐 访问GitHub Trending Weekly...');
    await page.goto('https://github.com/trending?since=weekly', {
      waitUntil: 'domcontentloaded',
      timeout: 60000
    });
    await page.waitForTimeout(8000);

    const items = await page.evaluate(() => {
      const results = [];
      const seenRepos = new Set();
      
      const repoItems = document.querySelectorAll('article.Box-row, .Box-row article, [class*="repo"]');
      repoItems.forEach((item, index) => {
        const linkEl = item.querySelector('h2 a, a[href*="/"][data-hydro-click]');
        if (!linkEl) return;
        
        const href = linkEl.getAttribute('href') || '';
        const fullName = href.replace(/^\//, '');
        
        if (seenRepos.has(fullName)) return;
        seenRepos.add(fullName);
        
        const descEl = item.querySelector('p, [class*="description"]');
        const description = descEl ? descEl.textContent?.trim() : '';
        
        const starsEl = item.querySelector('[href*="/stargazers"], .octicon-star + span, [class*="star"]');
        let stars = 0;
        if (starsEl) {
          const starText = starsEl.textContent?.trim() || '';
          if (starText.includes('k') || starText.includes('K')) {
            stars = parseFloat(starText.replace(/[kK,]/g, '')) * 1000;
          } else {
            stars = parseInt(starText.replace(/[^0-9]/g, '')) || 0;
          }
        }
        
        const forksEl = item.querySelector('[href*="/forks"], .octicon-repo-forked + span, [class*="fork"]');
        let forks = 0;
        if (forksEl) {
          const forkText = forksEl.textContent?.trim() || '';
          if (forkText.includes('k') || forkText.includes('K')) {
            forks = parseFloat(forkText.replace(/[kK,]/g, '')) * 1000;
          } else {
            forks = parseInt(forkText.replace(/[^0-9]/g, '')) || 0;
          }
        }
        
        const langEl = item.querySelector('[itemprop="programmingLanguage"], [class*="lang"]');
        const language = langEl ? langEl.textContent?.trim() : '';
        
        results.push({
          rank: results.length + 1,
          title: fullName,
          hot: stars,
          url: `https://github.com${href}`,
          author: fullName.split('/')[0] || '',
          category: language,
          description: description.substring(0, 200),
          forks: forks
        });
      });
      
      return results.slice(0, 25);
    });

    console.log(`   📊 GitHub Trending Weekly: ${items.length} 条数据`);
    
    return { platform: 'github', source: 'GitHub Trending Weekly', source_url: 'https://github.com/trending?since=weekly', hot_list: items };
  } catch (error) {
    console.error('   ❌ GitHub Trending抓取失败:', error.message);
    return { platform: 'github', source: 'GitHub Trending Weekly', source_url: 'https://github.com/trending?since=weekly', hot_list: [], error: error.message };
  } finally {
    await context.close();
  }
}

async function scrapeYouTubeTrending(browser) {
  console.log('\n▶️ 开始抓取YouTube热榜...');
  
  const context = await browser.newContext({
    userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    viewport: { width: 1920, height: 1080 },
    locale: 'zh-CN'
  });
  const page = await context.newPage();

  try {
    await page.goto('https://www.youtube.com/feed/trending', {
      waitUntil: 'domcontentloaded',
      timeout: 60000
    });
    await page.waitForTimeout(10000);

    const items = await page.evaluate(() => {
      const results = [];
      const selectors = [
        'ytd-video-renderer',
        'ytd-rich-item-renderer',
        'ytd-expanded-shelf-contents-renderer ytd-video-renderer'
      ];
      
      let allElements = [];
      for (const selector of selectors) {
        const elements = document.querySelectorAll(selector);
        allElements = allElements.concat(Array.from(elements));
      }
      
      const seenUrls = new Set();
      allElements.slice(0, 50).forEach((el, index) => {
        const titleEl = el.querySelector('#video-title, a#video-title-link, #title');
        const title = titleEl ? titleEl.textContent.trim() : '';
        
        const linkEl = el.querySelector('a#video-title, a#video-title-link, a[href*="/watch"]');
        let url = linkEl ? linkEl.href : '';
        if (url && !url.includes('/watch')) {
          const href = linkEl.getAttribute('href');
          if (href && href.includes('/watch')) {
            url = 'https://www.youtube.com' + href;
          }
        }
        
        if (!url || seenUrls.has(url)) return;
        seenUrls.add(url);
        
        const viewsEl = el.querySelector('#metadata-line span, ytd-video-meta-block span, .metadata-line span');
        const viewsText = viewsEl ? viewsEl.textContent : '0';
        
        const channelEl = el.querySelector('#channel-name a, ytd-channel-name a, #text a');
        const channel = channelEl ? channelEl.textContent.trim() : '';
        
        let views = 0;
        const viewsMatch = viewsText.match(/[\d.]+/);
        if (viewsMatch) {
          const num = parseFloat(viewsMatch[0]);
          if (viewsText.includes('万') || viewsText.toLowerCase().includes('m')) {
            views = Math.round(num * 10000);
          } else if (viewsText.includes('亿') || viewsText.toLowerCase().includes('b')) {
            views = Math.round(num * 100000000);
          } else if (viewsText.toLowerCase().includes('k') || viewsText.includes('千')) {
            views = Math.round(num * 1000);
          } else {
            views = Math.round(num);
          }
        }
        
        if (title) {
          results.push({
            rank: results.length + 1,
            title: title,
            hot: views,
            url: url,
            author: channel,
            category: 'YouTube'
          });
        }
      });
      return results;
    });

    console.log(`   📊 YouTube热榜: ${items.length} 条数据`);
    
    return { platform: 'youtube', source: 'YouTube Trending', source_url: 'https://www.youtube.com/feed/trending', hot_list: items };
  } catch (error) {
    console.error('   ❌ YouTube抓取失败:', error.message);
    return { platform: 'youtube', source: 'YouTube Trending', source_url: 'https://www.youtube.com/feed/trending', hot_list: [], error: error.message };
  } finally {
    await context.close();
  }
}

async function scrapeXTrending(browser) {
  console.log('\n🐦 开始抓取X(Twitter)热榜...');
  
  const context = await browser.newContext({
    userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    viewport: { width: 1920, height: 1080 },
    locale: 'zh-CN'
  });
  const page = await context.newPage();

  try {
    await page.goto('https://x.com/explore', {
      waitUntil: 'domcontentloaded',
      timeout: 60000
    });
    await page.waitForTimeout(12000);

    const items = await page.evaluate(() => {
      const results = [];
      const seenTitles = new Set();
      
      const trendSelectors = [
        '[data-testid="trend"]',
        'div[role="link"]',
        'section[aria-labelledby] div[role="listitem"]',
        '[data-testid="cellInnerDiv"]'
      ];
      
      let trendElements = [];
      for (const selector of trendSelectors) {
        const elements = document.querySelectorAll(selector);
        trendElements = trendElements.concat(Array.from(elements));
      }
      
      trendElements.forEach((el, index) => {
        const textContent = el.textContent || '';
        if (textContent.length < 2 || textContent.length > 200) return;
        
        const spans = el.querySelectorAll('span');
        let title = '';
        let hot = 0;
        
        for (const span of spans) {
          const text = span.textContent.trim();
          if (text.length > 2 && text.length < 100 && !text.includes('帖子') && !text.includes('Post')) {
            if (!title && !/^\d/.test(text) && !text.includes('万') && !text.includes('M')) {
              title = text;
            }
          }
          
          const match = text.match(/([\d.]+)\s*([万千百MBKmbk]*)/);
          if (match) {
            const num = parseFloat(match[1]);
            const unit = match[2].toLowerCase();
            if (unit.includes('万') || unit.includes('m')) {
              hot = Math.round(num * 10000);
            } else if (unit.includes('亿') || unit.includes('b')) {
              hot = Math.round(num * 100000000);
            } else if (unit.includes('k') || unit.includes('千')) {
              hot = Math.round(num * 1000);
            } else {
              hot = Math.round(num);
            }
          }
        }
        
        if (!title) {
          const dirLtr = el.querySelector('div[dir="ltr"], span[dir="ltr"]');
          if (dirLtr) {
            title = dirLtr.textContent.trim();
          }
        }
        
        if (!title) {
          const allText = el.innerText.split('\n')[0];
          if (allText && allText.length > 2 && allText.length < 100) {
            title = allText;
          }
        }
        
        const linkEl = el.closest('a') || el.querySelector('a');
        let url = linkEl ? linkEl.href : 'https://x.com/explore';
        
        if (title && !seenTitles.has(title) && title.length > 1) {
          seenTitles.add(title);
          results.push({
            rank: results.length + 1,
            title: title.substring(0, 100),
            hot: hot,
            url: url
          });
        }
      });
      
      return results.slice(0, 30);
    });

    console.log(`   📊 X(Twitter)热榜: ${items.length} 条数据`);
    
    return { platform: 'twitter', source: 'X(Twitter) Trending', source_url: 'https://x.com/explore', hot_list: items };
  } catch (error) {
    console.error('   ❌ X(Twitter)抓取失败:', error.message);
    return { platform: 'twitter', source: 'X(Twitter) Trending', source_url: 'https://x.com/explore', hot_list: [], error: error.message };
  } finally {
    await context.close();
  }
}

function extractKeywords(platforms) {
  const keywordMap = new Map();
  
  platforms.forEach(platform => {
    platform.hot_list.forEach(item => {
      const title = item.title;
      const words = title.split(/[\s,，、！!？?。.""''「」【】《》\-\+\*]/);
      
      words.forEach(word => {
        if (word.length >= 2 && word.length <= 10) {
          const count = keywordMap.get(word) || 0;
          keywordMap.set(word, count + 1);
        }
      });
    });
    
    if (platform.rising_list) {
      platform.rising_list.forEach(item => {
        const title = item.title;
        const words = title.split(/[\s,，、！!？?。.""''「」【】《》\-\+\*]/);
        
        words.forEach(word => {
          if (word.length >= 2 && word.length <= 10) {
            const count = keywordMap.get(word) || 0;
            keywordMap.set(word, count + 1);
          }
        });
      });
    }
  });

  const keywords = Array.from(keywordMap.entries())
    .map(([word, count]) => ({ word, count }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 15);

  return keywords;
}

function findHotEvents(platforms) {
  const events = [];
  const titleMap = new Map();

  platforms.forEach(platform => {
    const allItems = [...platform.hot_list, ...(platform.rising_list || [])];
    allItems.slice(0, 20).forEach(item => {
      const keywords = item.title.split(/[\s,，、！!？?。.""''「」【】《》\-\+\*]/).filter(w => w.length >= 2);
      keywords.forEach(keyword => {
        if (!titleMap.has(keyword)) {
          titleMap.set(keyword, { keyword, platforms: [], items: [] });
        }
        const entry = titleMap.get(keyword);
        if (!entry.platforms.includes(platform.platform)) {
          entry.platforms.push(platform.platform);
        }
        entry.items.push({ ...item, platform: platform.platform });
      });
    });
  });

  const crossPlatformEvents = Array.from(titleMap.values())
    .filter(e => e.platforms.length >= 2 || e.items.length >= 2)
    .sort((a, b) => b.items.length - a.items.length)
    .slice(0, 5);

  crossPlatformEvents.forEach(event => {
    const maxHot = Math.max(...event.items.map(i => i.hot || 0));
    let level = 'warm';
    if (maxHot > 5000000 || event.items.length >= 3) level = 'explosive';
    else if (maxHot > 2000000 || event.items.length >= 2) level = 'hot';

    events.push({
      title: event.keyword,
      level,
      platforms: event.platforms,
      items: event.items.slice(0, 5),
      max_hot: maxHot
    });
  });

  return events;
}

function generateSuggestions(events, platforms) {
  const suggestions = [];
  
  events.forEach((event, index) => {
    let potential = '中';
    if (event.level === 'explosive') potential = '高';
    else if (event.level === 'hot') potential = '中高';

    const angles = [];
    if (event.title.includes('游戏')) {
      angles.push('游戏攻略', '版本解析', '玩家体验');
    } else if (event.title.includes('电影') || event.title.includes('剧')) {
      angles.push('剧情解析', '角色分析', '幕后花絮');
    } else if (event.title.includes('音乐') || event.title.includes('演唱会')) {
      angles.push('现场回顾', '歌单分享', '幕后故事');
    } else {
      angles.push('深度解析', '热点追踪', '观点输出');
    }

    suggestions.push({
      id: index + 1,
      title: `${event.title}相关选题`,
      angles,
      potential,
      platforms: event.platforms
    });
  });

  if (suggestions.length < 5) {
    platforms.forEach(platform => {
      if (platform.hot_list.length > 0 && suggestions.length < 5) {
        const topItem = platform.hot_list[0];
        if (!suggestions.find(s => s.title.includes(topItem.title.substring(0, 4)))) {
          suggestions.push({
            id: suggestions.length + 1,
            title: `${topItem.title.substring(0, 10)}相关选题`,
            angles: ['深度解析', '热点追踪', '观点输出'],
            potential: '中',
            platforms: [platform.platform]
          });
        }
      }
    });
  }

  return suggestions.slice(0, 5);
}

function generateHTML(data, keywords, events, suggestions) {
  const today = data.date;
  const totalItems = data.summary.total_items;
  const platformsCount = data.summary.platforms_count;
  
  const allItems = data.platforms.flatMap(p => [...p.hot_list, ...(p.rising_list || [])]);
  const maxHot = Math.max(...allItems.map(i => i.hot || 0));

  const douyinData = data.platforms.find(p => p.platform === 'douyin') || { hot_list: [], rising_list: [] };
  const bilibiliData = data.platforms.find(p => p.platform === 'bilibili') || { hot_list: [] };
  const xiaohongshuData = data.platforms.find(p => p.platform === 'xiaohongshu') || { hot_list: [] };
  const weiboData = data.platforms.find(p => p.platform === 'weibo') || { hot_list: [] };
  const githubData = data.platforms.find(p => p.platform === 'github') || { hot_list: [] };
  const youtubeData = data.platforms.find(p => p.platform === 'youtube') || { hot_list: [] };
  const twitterData = data.platforms.find(p => p.platform === 'twitter') || { hot_list: [] };

  const formatHot = (hot) => {
    if (hot >= 10000000) return (hot / 10000000).toFixed(1) + '千万';
    if (hot >= 10000) return (hot / 10000).toFixed(0) + '万';
    return hot.toString();
  };

  const getHeatPercent = (hot, platformMaxHot) => platformMaxHot > 0 ? Math.round((hot / platformMaxHot) * 100) : 0;
  const getHeatClass = (percent) => percent >= 60 ? 'very-hot' : percent >= 30 ? 'hot' : 'warm';

  const keywordHTML = keywords.map(k => {
    const isRising = k.count >= 2;
    return `<div class="keyword-tag ${isRising ? 'rising' : 'stable'}">${isRising ? '📈' : '➡️'} ${k.word} <span class="count">${k.count}</span></div>`;
  }).join('\n                ');

  const generateListHTML = (items, platform) => {
    const platformMaxHot = Math.max(...items.map(i => i.hot || 0), 1);
    return items.slice(0, 15).map((item, i) => {
      const rankClass = i === 0 ? 'top1' : i === 1 ? 'top2' : i === 2 ? 'top3' : 'normal';
      const heatPercent = getHeatPercent(item.hot, platformMaxHot);
      const heatClass = getHeatClass(heatPercent);
      const categoryHTML = item.category ? `<span class="hot-category">${item.category}</span>` : '';
      const authorHTML = item.author ? `<span class="hot-author">UP: ${item.author}</span>` : '';
      
      const url = item.url || '#';
      const isClickable = url && url !== '#' && !url.endsWith('/hot') && url.startsWith('http');
      
      return `<li class="hot-item">
                            <div class="hot-rank ${rankClass}">${i + 1}</div>
                            <div class="hot-content">
                                <div class="hot-title">${isClickable ? `<a href="${url}" target="_blank" rel="noopener noreferrer" class="hot-link">${item.title}</a>` : item.title}</div>
                                <div class="hot-meta">
                                    <span class="hot-heat">🔥 ${formatHot(item.hot)}</span>
                                    ${categoryHTML}
                                    ${authorHTML}
                                    <div class="heat-bar-container"><div class="heat-bar ${heatClass}" style="width:${heatPercent}%"></div></div>
                                </div>
                            </div>
                        </li>`;
    }).join('\n                        ');
  };

  const getPlatformBadge = (p) => {
    const badges = {
      'douyin': '<span class="platform-badge platform-douyin">🎵 抖音</span>',
      'bilibili': '<span class="platform-badge platform-bilibili">📺 B站</span>',
      'xiaohongshu': '<span class="platform-badge platform-xiaohongshu">📕 小红书</span>',
      'weibo': '<span class="platform-badge platform-weibo">📱 微博热搜</span>',
      'github': '<span class="platform-badge platform-github">🐙 GitHub</span>',
      'youtube': '<span class="platform-badge platform-youtube">▶️ YouTube</span>',
      'twitter': '<span class="platform-badge platform-twitter">🐦 X(Twitter)</span>'
    };
    return badges[p] || `<span class="platform-badge">${p}</span>`;
  };

  const eventHTML = events.map(e => {
    const levelClass = e.level;
    const levelText = e.level === 'explosive' ? '🔥 爆火' : e.level === 'hot' ? '🔥 热门' : '🔥 温和';
    const platformBadges = e.platforms.map(p => getPlatformBadge(p)).join('\n                    ');

    return `<div class="event-card ${levelClass}">
                <div class="event-title">${e.title} <span class="event-badge ${levelClass}">${levelText}</span></div>
                <div class="event-desc">跨平台热度事件，共${e.items.length}条相关内容，最高热度${formatHot(e.max_hot)}</div>
                <div class="event-platforms">
                    ${platformBadges}
                </div>
            </div>`;
  }).join('\n\n            ');

  const suggestionHTML = suggestions.map(s => {
    const platformBadges = s.platforms.map(p => getPlatformBadge(p)).join(' ');

    return `<div class="suggestion-card">
                <div class="suggestion-number">${String(s.id).padStart(2, '0')}</div>
                <div class="suggestion-title">${s.title}</div>
                <div class="suggestion-angle">可考虑角度：${s.angles.join('、')}</div>
                <div class="suggestion-meta">
                    <div class="meta-item potential">📈 潜力: ${s.potential}</div>
                    ${platformBadges}
                </div>
            </div>`;
  }).join('\n            ');

  return `<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>热点分析报告 - ${today}</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Playfair+Display:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: linear-gradient(135deg, #FDF2F8 0%, #FCE7F3 50%, #FBCFE8 100%);
            min-height: 100vh;
            color: #831843;
            line-height: 1.6;
        }
        .container { max-width: 1400px; margin: 0 auto; padding: 20px; }
        header {
            text-align: center;
            padding: 40px 20px;
            background: rgba(255,255,255,0.8);
            border-radius: 20px;
            margin-bottom: 30px;
            box-shadow: 0 4px 20px rgba(236, 72, 153, 0.15);
        }
        header h1 {
            font-family: 'Playfair Display', serif;
            font-size: 2.5em;
            background: linear-gradient(90deg, #EC4899, #8B5CF6);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 10px;
        }
        .section {
            background: rgba(255,255,255,0.8);
            border-radius: 20px;
            padding: 30px;
            margin-bottom: 30px;
            box-shadow: 0 4px 20px rgba(236, 72, 153, 0.1);
        }
        .section h2 {
            font-family: 'Playfair Display', serif;
            font-size: 1.8em;
            margin-bottom: 25px;
            padding-bottom: 15px;
            border-bottom: 2px solid rgba(236, 72, 153, 0.2);
            color: #BE185D;
        }
        .keyword-cloud { display: flex; flex-wrap: wrap; gap: 12px; justify-content: center; }
        .keyword-tag {
            padding: 10px 18px;
            border-radius: 50px;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 0.9em;
            box-shadow: 0 2px 10px rgba(236, 72, 153, 0.2);
        }
        .keyword-tag.rising { background: linear-gradient(135deg, #EC4899, #BE185D); color: #fff; }
        .keyword-tag.stable { background: linear-gradient(135deg, #F9A8D4, #FBCFE8); color: #831843; }
        .keyword-tag .count {
            background: rgba(255,255,255,0.3);
            padding: 2px 8px;
            border-radius: 10px;
            font-size: 0.85em;
        }
        .hot-list { list-style: none; }
        .hot-item {
            display: flex;
            align-items: center;
            padding: 18px 20px;
            background: rgba(255,255,255,0.9);
            border-radius: 12px;
            margin-bottom: 12px;
            transition: all 0.3s;
            box-shadow: 0 2px 10px rgba(236, 72, 153, 0.1);
        }
        .hot-item:hover { 
            background: rgba(255,255,255,1); 
            transform: translateX(5px); 
            box-shadow: 0 4px 20px rgba(236, 72, 153, 0.2);
        }
        .hot-rank {
            width: 45px;
            height: 45px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            margin-right: 15px;
            font-size: 1.3em;
            flex-shrink: 0;
        }
        .hot-rank.top1 { background: linear-gradient(135deg, #EC4899, #BE185D); color: #fff; }
        .hot-rank.top2 { background: linear-gradient(135deg, #F9A8D4, #FBCFE8); color: #831843; }
        .hot-rank.top3 { background: linear-gradient(135deg, #8B5CF6, #A78BFA); color: #fff; }
        .hot-rank.normal { background: rgba(236, 72, 153, 0.1); color: #BE185D; }
        .hot-content { flex: 1; }
        .hot-title { font-size: 1.1em; margin-bottom: 8px; color: #831843; font-weight: 500; }
        .hot-link { color: #831843; text-decoration: none; transition: color 0.3s; cursor: pointer; }
        .hot-link:hover { color: #EC4899; text-decoration: underline; }
        .hot-meta { display: flex; gap: 15px; font-size: 0.85em; color: #9D174D; align-items: center; flex-wrap: wrap; }
        .hot-heat { color: #EC4899; font-weight: 600; }
        .hot-category, .hot-author { background: rgba(236, 72, 153, 0.1); padding: 3px 10px; border-radius: 5px; color: #BE185D; }
        .heat-bar-container {
            width: 120px;
            height: 6px;
            background: rgba(236, 72, 153, 0.2);
            border-radius: 3px;
            overflow: hidden;
        }
        .heat-bar {
            height: 100%;
            border-radius: 3px;
        }
        .heat-bar.very-hot { background: linear-gradient(90deg, #EC4899, #BE185D); }
        .heat-bar.hot { background: linear-gradient(90deg, #F9A8D4, #FBCFE8); }
        .heat-bar.warm { background: linear-gradient(90deg, #8B5CF6, #A78BFA); }
        .event-card {
            background: rgba(255,255,255,0.9);
            border-radius: 15px;
            padding: 25px;
            margin-bottom: 20px;
            border-left: 4px solid;
            box-shadow: 0 2px 15px rgba(236, 72, 153, 0.1);
        }
        .event-card.explosive { border-color: #EC4899; }
        .event-card.hot { border-color: #F9A8D4; }
        .event-card.warm { border-color: #8B5CF6; }
        .event-title { font-size: 1.3em; font-weight: 600; margin-bottom: 12px; display: flex; align-items: center; gap: 10px; flex-wrap: wrap; color: #831843; }
        .event-badge {
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.75em;
        }
        .event-badge.explosive { background: #EC4899; color: #fff; }
        .event-badge.hot { background: #F9A8D4; color: #831843; }
        .event-badge.warm { background: #8B5CF6; color: #fff; }
        .event-desc { color: #9D174D; margin-bottom: 15px; line-height: 1.7; }
        .event-platforms { display: flex; gap: 8px; margin-top: 12px; flex-wrap: wrap; }
        .suggestion-card {
            background: linear-gradient(135deg, rgba(236, 72, 153, 0.1), rgba(139, 92, 246, 0.1));
            border-radius: 15px;
            padding: 25px;
            margin-bottom: 20px;
            position: relative;
            border-left: 5px solid;
            border-image: linear-gradient(180deg, #EC4899, #8B5CF6) 1;
            box-shadow: 0 2px 15px rgba(236, 72, 153, 0.1);
        }
        .suggestion-number {
            position: absolute;
            top: 15px;
            right: 20px;
            font-size: 3em;
            font-weight: bold;
            opacity: 0.1;
            color: #EC4899;
        }
        .suggestion-title { font-size: 1.3em; font-weight: 600; margin-bottom: 10px; color: #831843; }
        .suggestion-angle {
            color: #9D174D;
            margin-bottom: 15px;
            padding-left: 15px;
            border-left: 2px solid rgba(236, 72, 153, 0.3);
            line-height: 1.6;
        }
        .suggestion-meta { display: flex; gap: 20px; flex-wrap: wrap; align-items: center; }
        .meta-item { display: flex; align-items: center; gap: 5px; font-size: 0.9em; }
        .meta-item.potential { color: #EC4899; font-weight: 600; }
        .platform-badge {
            display: inline-flex;
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 0.85em;
        }
        .platform-bilibili { background: #fb7299; color: #fff; }
        .platform-douyin { background: linear-gradient(135deg, #000, #25f4ee); color: #fff; }
        .platform-xiaohongshu { background: #ff2442; color: #fff; }
        .platform-weibo { background: #e6162d; color: #fff; }
        .platform-github { background: #24292e; color: #fff; }
        .platform-youtube { background: #ff0000; color: #fff; }
        .platform-twitter { background: #1da1f2; color: #fff; }
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        .stat-card {
            background: rgba(255,255,255,0.9);
            border-radius: 15px;
            padding: 20px;
            text-align: center;
            box-shadow: 0 2px 15px rgba(236, 72, 153, 0.1);
        }
        .stat-value {
            font-size: 2.2em;
            font-weight: bold;
            background: linear-gradient(90deg, #EC4899, #8B5CF6);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        .stat-label { color: #9D174D; margin-top: 5px; font-size: 0.9em; }
        .footer { text-align: center; padding: 30px; color: #9D174D; }
        .platform-section {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 30px;
        }
        @media (max-width: 1200px) {
            .platform-section { grid-template-columns: repeat(2, 1fr); }
        }
        @media (max-width: 800px) {
            .platform-section { grid-template-columns: 1fr; }
        }
        .platform-block {
            background: rgba(255,255,255,0.9);
            border-radius: 15px;
            padding: 20px;
            box-shadow: 0 2px 15px rgba(236, 72, 153, 0.1);
        }
        .platform-block h3 {
            font-size: 1.3em;
            margin-bottom: 15px;
            display: flex;
            align-items: center;
            gap: 10px;
            color: #BE185D;
        }
        .douyin-section {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin-bottom: 30px;
        }
        @media (max-width: 800px) {
            .douyin-section { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>📊 今日热点分析报告</h1>
            <p style="color: #9D174D; font-size: 1.1em;">生成时间: ${today}</p>
            <div style="margin-top: 15px;">
                <span class="platform-badge platform-douyin">🎵 抖音</span>
                <span class="platform-badge platform-bilibili">📺 B站</span>
                <span class="platform-badge platform-xiaohongshu">📕 小红书</span>
                <span class="platform-badge platform-weibo">📱 微博热搜</span>
                <span class="platform-badge platform-github">🐙 GitHub</span>
                <span class="platform-badge platform-youtube">▶️ YouTube</span>
                <span class="platform-badge platform-twitter">🐦 X(Twitter)</span>
            </div>
        </header>

        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-value">${platformsCount}</div>
                <div class="stat-label">已配置平台</div>
            </div>
            <div class="stat-card">
                <div class="stat-value">${totalItems}</div>
                <div class="stat-label">热榜数据条数</div>
            </div>
            <div class="stat-card">
                <div class="stat-value">${keywords.length}</div>
                <div class="stat-label">热门关键词</div>
            </div>
            <div class="stat-card">
                <div class="stat-value">${events.length}</div>
                <div class="stat-label">热点事件</div>
            </div>
            <div class="stat-card">
                <div class="stat-value">${formatHot(maxHot)}</div>
                <div class="stat-label">最高热度</div>
            </div>
        </div>

        <section class="section">
            <h2>🔥 热门关键词 TOP ${keywords.length}</h2>
            <div class="keyword-cloud">
                ${keywordHTML}
            </div>
        </section>

        <section class="section">
            <h2>📊 各平台热榜速览</h2>
            
            <div class="douyin-section">
                <div class="platform-block">
                    <h3><span class="platform-badge platform-douyin">🎵 抖音实时热点</span> TOP 15</h3>
                    <p style="color: #9D174D; margin-bottom: 15px; font-size: 0.85em;">
                        数据来源：抖音热榜 | 点击标题跳转
                    </p>
                    <ul class="hot-list">
                        ${generateListHTML(douyinData.hot_list, 'douyin')}
                    </ul>
                </div>

                <div class="platform-block">
                    <h3><span class="platform-badge platform-douyin">🎵 抖音飙升热点</span> TOP 15</h3>
                    <p style="color: #9D174D; margin-bottom: 15px; font-size: 0.85em;">
                        数据来源：抖音热榜 | 点击标题跳转
                    </p>
                    <ul class="hot-list">
                        ${generateListHTML(douyinData.rising_list || [], 'douyin')}
                    </ul>
                </div>
            </div>

            <div class="platform-section">
                <div class="platform-block">
                    <h3><span class="platform-badge platform-bilibili">📺 B站热榜</span> TOP 15</h3>
                    <p style="color: #9D174D; margin-bottom: 15px; font-size: 0.85em;">
                        数据来源：B站热榜 | 点击标题跳转
                    </p>
                    <ul class="hot-list">
                        ${generateListHTML(bilibiliData.hot_list, 'bilibili')}
                    </ul>
                </div>

                <div class="platform-block">
                    <h3><span class="platform-badge platform-xiaohongshu">📕 小红书热榜</span> TOP 15</h3>
                    <p style="color: #9D174D; margin-bottom: 15px; font-size: 0.85em;">
                        数据来源：小红书热榜 | 点击标题跳转
                    </p>
                    <ul class="hot-list">
                        ${generateListHTML(xiaohongshuData.hot_list, 'xiaohongshu')}
                    </ul>
                </div>

                <div class="platform-block">
                    <h3><span class="platform-badge platform-weibo">📱 微博热搜</span> TOP 15</h3>
                    <p style="color: #9D174D; margin-bottom: 15px; font-size: 0.85em;">
                        数据来源：微博热搜榜 | 点击标题跳转
                    </p>
                    <ul class="hot-list">
                        ${generateListHTML(weiboData.hot_list, 'weibo')}
                    </ul>
                </div>

                <div class="platform-block">
                    <h3><span class="platform-badge platform-github">🐙 GitHub Trending Weekly</span> TOP 15</h3>
                    <p style="color: #9D174D; margin-bottom: 15px; font-size: 0.85em;">
                        数据来源：GitHub Trending | 点击标题跳转
                    </p>
                    <ul class="hot-list">
                        ${generateListHTML(githubData.hot_list, 'github')}
                    </ul>
                </div>

                <div class="platform-block">
                    <h3><span class="platform-badge platform-youtube">▶️ YouTube热榜</span> TOP 15</h3>
                    <p style="color: #9D174D; margin-bottom: 15px; font-size: 0.85em;">
                        数据来源：YouTube Trending | 点击标题跳转
                    </p>
                    <ul class="hot-list">
                        ${generateListHTML(youtubeData.hot_list, 'youtube')}
                    </ul>
                </div>

                <div class="platform-block">
                    <h3><span class="platform-badge platform-twitter">🐦 X(Twitter)热榜</span> TOP 15</h3>
                    <p style="color: #9D174D; margin-bottom: 15px; font-size: 0.85em;">
                        数据来源：X(Twitter) Explore | 点击标题跳转
                    </p>
                    <ul class="hot-list">
                        ${generateListHTML(twitterData.hot_list, 'twitter')}
                    </ul>
                </div>
            </div>
        </section>

        <section class="section">
            <h2>⚡ 热点事件追踪</h2>
            ${eventHTML}
        </section>

        <section class="section">
            <h2>💡 选题建议</h2>
            ${suggestionHTML}
        </section>

        <footer class="footer">
            <p>📊 热点关键词分析报告 | 数据来源: 抖音热榜 + B站热榜 + 小红书热榜 + 微博热搜 + GitHub Trending + YouTube + X(Twitter)</p>
            <p style="margin-top: 10px;">本报告由 Hotspot Tracker Skill 自动生成 | 浏览器模拟抓取</p>
            <p style="margin-top: 10px; color: #EC4899;">✅ 已配置平台: 抖音(${douyinData.hot_list.length + (douyinData.rising_list?.length || 0)}条) + B站(${bilibiliData.hot_list.length}条) + 小红书(${xiaohongshuData.hot_list.length}条) + 微博(${weiboData.hot_list.length}条) + GitHub(${githubData.hot_list.length}条) + YouTube(${youtubeData.hot_list.length}条) + X(Twitter)(${twitterData.hot_list.length}条)</p>
        </footer>
    </div>
</body>
</html>`;
}

async function main() {
  const today = new Date().toISOString().split('T')[0];
  const timestamp = new Date().toISOString();
  
  console.log('🚀 启动热点追踪器...');
  console.log(`📅 日期: ${today}`);
  console.log(`📁 输出目录: ${OUTPUT_DIR}`);
  console.log(`🖥️ 无头模式: ${HEADLESS}`);

  if (!fs.existsSync(OUTPUT_DIR)) {
    fs.mkdirSync(OUTPUT_DIR, { recursive: true });
  }

  const browser = await chromium.launch({
    headless: HEADLESS,
    args: [
      '--disable-blink-features=AutomationControlled',
      '--disable-features=IsolateOrigins,site-per-process',
      '--no-sandbox',
      '--disable-setuid-sandbox',
    ]
  });

  let outputData;
  
  try {
    console.log('\n📡 开始抓取数据...');
    
    const douyinResult = await scrapeDouyinHot(browser);
    
    const results = await Promise.all([
      Promise.resolve(douyinResult),
      scrapeBilibiliHot(browser),
      scrapeXiaohongshuHot(browser),
      scrapeWeiboHot(browser),
      scrapeGitHubTrending(browser),
      scrapeYouTubeTrending(browser),
      scrapeXTrending(browser)
    ]);

    outputData = {
      date: today,
      scraped_at: timestamp,
      platforms: results,
      summary: {
        total_items: results.reduce((sum, r) => sum + r.hot_list.length + (r.rising_list?.length || 0), 0),
        platforms_count: results.filter(r => r.hot_list.length > 0 || (r.rising_list?.length || 0) > 0).length
      }
    };

    const jsonPath = path.join(OUTPUT_DIR, `hotspot-data-${today}.json`);
    fs.writeFileSync(jsonPath, JSON.stringify(outputData, null, 2), 'utf-8');
    console.log(`\n✅ 数据已保存: ${jsonPath}`);

  } finally {
    await browser.close();
    console.log('\n🔚 浏览器已关闭');
  }

  console.log('\n📝 开始生成报告...');

  const keywords = extractKeywords(outputData.platforms);
  console.log(`   🔑 提取关键词: ${keywords.length} 个`);

  const events = findHotEvents(outputData.platforms);
  console.log(`   ⚡ 发现热点事件: ${events.length} 个`);

  const suggestions = generateSuggestions(events, outputData.platforms);
  console.log(`   💡 生成选题建议: ${suggestions.length} 条`);

  const html = generateHTML(outputData, keywords, events, suggestions);
  const htmlPath = path.join(OUTPUT_DIR, `hotspot-report-${today}.html`);
  fs.writeFileSync(htmlPath, html, 'utf-8');
  console.log(`\n✅ 报告已生成: ${htmlPath}`);

  console.log('\n🎉 全部完成!');
  console.log(`   📊 总数据: ${outputData.summary.total_items} 条`);
  console.log(`   📱 成功平台: ${outputData.summary.platforms_count} 个`);
  console.log(`   📄 数据文件: ${path.join(OUTPUT_DIR, `hotspot-data-${today}.json`)}`);
  console.log(`   🌐 报告文件: ${htmlPath}`);

  return outputData;
}

main()
  .then(data => {
    process.exit(0);
  })
  .catch(error => {
    console.error('\n❌ 执行失败:', error.message);
    process.exit(1);
  });
