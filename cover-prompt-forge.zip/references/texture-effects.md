# 材质纹理效果库

## 数字/科技类纹理

### 1. 网格/线条纹理

**描述：** 几何网格、线条、矩阵图案

**适用场景：**
- 科技、数据、AI主题
- 未来感、数字化风格
- 游戏、科幻内容

**Prompt关键词：**
```
subtle grid pattern, geometric line texture
digital matrix background, circuit-like lines
wireframe overlay, technical blueprint aesthetic
```

**变体：**
- 霓虹网格：`neon grid lines, glowing wireframe`
- 透视网格：`perspective grid, vanishing point lines`
- 点阵网格：`dot matrix pattern, pixelated grid`

---

### 2. 半调网格 (Halftone Grid)

**描述：** 半色调网点图案，兼具网格结构和印刷质感，复古与现代的交叉点

**适用场景：**
- 波普艺术、漫画风格
- 复古海报、丝网印刷
- 暗色科技拼贴风（低透明度叠加）
- 需要增加层次感和质感的内容

**Prompt关键词：**
```
halftone grid pattern, ben-day dots overlay
screen-print halftone texture, retro dot matrix
coarse halftone mesh, newspaper print dots
```

**变体：**
- 粗网点半调：`large halftone dots, coarse ben-day pattern, visible dot structure`
- 细网点半调：`fine halftone grid, subtle dot texture, delicate screen print`
- 渐变半调：`gradient halftone, varying dot density, tonal halftone transition`
- 彩色半调：`color halftone separation, CMYK halftone overlay, multi-color ben-day`
- 半调网格叠加：`halftone grid overlay at low opacity, subtle halftone texture beneath image`

**与其他纹理组合：**
- 半调+噪点：`halftone dots with film grain overlay, vintage print texture`
- 半调+网格：`halftone pattern over geometric grid lines, layered texture`
- 半调+做旧：`worn halftone print, distressed ben-day dots, aged screen print`

---

### 3. 噪点/颗粒纹理

**描述：** 细微噪点、胶片颗粒感

**适用场景：**
- 增加质感、避免画面过于平滑
- 复古、胶片风格
- 艺术感、高级感

**Prompt关键词：**
```
film grain texture, subtle noise overlay
fine grain pattern, photographic texture
slight grit texture, organic surface quality
```

**变体：**
- 粗颗粒：`heavy grain, coarse texture`
- 细颗粒：`fine grain, delicate noise`
- 彩色噪点：`color noise, chromatic grain`

---

### 3. 光效/发光纹理

**描述：** 光晕、辉光、光线效果

**适用场景：**
- 科技、未来感
- 强调重点元素
- 营造氛围

**Prompt关键词：**
```
subtle glow effect, soft light emission
lens flare accents, light bloom
glowing highlights, luminous edges
```

---

## 复古/印刷类纹理

### 4. 半色调网点 (Halftone)

**描述：** 印刷网点图案，复古报纸/漫画风格

**适用场景：**
- 复古海报、波普艺术
- 漫画风格、插画感
- 怀旧、经典主题

**Prompt关键词：**
```
halftone dot pattern, vintage print texture
newspaper print dots, Ben-Day dots
retro printing texture, comic book style dots
```

**变体：**
- 粗网点：`large halftone dots, coarse print`
- 细网点：`fine halftone, subtle dot pattern`
- 渐变网点：`gradient halftone transition`

---

### 5. 丝网印刷纹理 (Screen Print)

**描述：** 丝网印刷的厚重油墨感、轻微错位

**适用场景：**
- 海报、艺术印刷
- 街头文化、潮流
- 手工感、艺术感

**Prompt关键词：**
```
screen print texture, thick ink application
slight color misregistration, print overlay effect
bold graphic print style, poster art texture
```

---

### 6. 纸张纹理

**描述：** 纸张肌理、纤维感

**适用场景：**
- 书籍、文学类
- 自然、环保主题
- 增加真实感

**Prompt关键词：**
```
paper texture background, subtle fiber pattern
canvas texture, slight roughness
natural paper grain, organic surface
```

**变体：**
- 粗糙纸张：`rough paper, heavy texture`
- 光滑纸张：`smooth paper, subtle grain`
- 复古纸张：`aged paper, yellowed texture`
- 水彩纸：`watercolor paper texture, cold press`

---

### 7. 复古做旧效果

**描述：** 磨损、褪色、污渍、折痕

**适用场景：**
- 复古、怀旧主题
- 历史、档案感
- 增加故事感

**Prompt关键词：**
```
vintage worn texture, aged appearance
distressed edges, faded colors
stains and scratches, antique patina
fold marks, creased paper effect
```

---

## 自然/有机类纹理

### 8. 水彩/晕染效果

**描述：** 水彩颜料的流动、晕染、渐变

**适用场景：**
- 艺术、创意类
- 柔和、梦幻风格
- 女性、情感主题

**Prompt关键词：**
```
watercolor wash texture, soft color bleeding
ink diffusion effect, fluid art texture
soft gradient transitions, organic color flow
```

---

### 9. 大理石/流体纹理

**描述：** 大理石纹路、流体艺术、丙烯泼洒

**适用场景：**
- 高端、奢华感
- 艺术、设计类
- 抽象背景

**Prompt关键词：**
```
marble texture, swirling patterns
fluid art background, acrylic pour effect
agate stone pattern, mineral texture
```

---

### 10. 自然元素纹理

**描述：** 木纹、石纹、植物纹理

**适用场景：**
- 自然、环保主题
- 手工、匠心类
- 温暖、质朴感

**Prompt关键词：**
```
wood grain texture, natural wood pattern
stone texture, rough mineral surface
leaf vein pattern, botanical texture
```

---

## 特殊效果类纹理

### 11. 故障艺术 (Glitch)

**描述：** 数字故障、错位、RGB分离

**适用场景：**
- 科技、赛博朋克
- 音乐、电子文化
- 前卫、实验性

**Prompt关键词：**
```
glitch effect, digital distortion
RGB split, chromatic aberration
scan lines, pixel sorting
signal interference, corrupted data aesthetic
```

---

### 12. 磨砂/毛玻璃效果

**描述：** 半透明磨砂质感、模糊背景

**适用场景：**
- 现代UI风格
- 需要突出前景文字
- 简洁、高级感

**Prompt关键词：**
```
frosted glass effect, blurred background
matte texture, soft focus overlay
semi-transparent layer, diffused light
```

---

### 13. 金属质感

**描述：** 金属光泽、拉丝、反射

**适用场景：**
- 高端、奢华
- 科技、工业
- 强调品质感

**Prompt关键词：**
```
metallic texture, brushed metal surface
chrome reflection, polished steel
gold foil texture, metallic sheen
```

**变体：**
- 拉丝金属：`brushed aluminum, linear metal texture`
- 镜面金属：`mirror finish, reflective chrome`
- 做旧金属：`oxidized metal, rust patina`

---

## 纹理组合建议

### 科技风格组合
```
subtle grid pattern + fine grain texture + slight glow effect
```

### 复古风格组合
```
halftone dots + paper texture + vintage worn edges
```

### 艺术风格组合
```
watercolor wash + paper texture + subtle grain
```

### 奢华风格组合
```
marble texture + metallic accents + frosted glass overlay
```

### 街头风格组合
```
screen print texture + bold graphic elements + slight distress
```

---

## 纹理强度控制

**微妙（Subtle）：**
```
subtle texture, barely visible
light texture overlay, delicate pattern
soft textural quality
```

**中等（Moderate）：**
```
noticeable texture, clear pattern
distinct surface quality
visible textural element
```

**强烈（Strong）：**
```
heavy texture, prominent pattern
dominant textural element
bold surface treatment
```

---

## 纹理与主题匹配

| 主题 | 推荐纹理 | 强度 |
|-----|---------|-----|
| 科技/AI | 网格、噪点、光效 | 微妙-中等 |
| 复古/怀旧 | 半色调、纸张、做旧 | 中等-强烈 |
| 艺术/创意 | 水彩、流体、纸张 | 中等 |
| 高端/奢华 | 大理石、金属、磨砂 | 微妙-中等 |
| 自然/环保 | 木纹、纸张、植物 | 中等 |
| 街头/潮流 | 丝网印、做旧、故障 | 强烈 |
