# 8大版式设计原则速查

## 原则1：到位的对齐 (Alignment)

**核心概念：**
页面上的每个元素都应当与页面上的另一个元素有某种视觉联系。

**常见对齐方式：**
- **左对齐**：最常用，符合阅读习惯，稳定感
- **右对齐**：打破常规，现代感，适合短文本
- **居中对齐**：正式、稳重，适合标题
- **两端对齐**：整齐，但中文慎用（易产生 rivers）

**Prompt关键词：**
```
clean alignment, strict grid system
aligned to left edge, consistent margins
organized layout, structured composition
```

**常见错误：**
- 多种对齐方式混用
- 元素随意摆放，无基准线
- 间距不一致

---

## 原则2：明显的组合/亲密度 (Proximity)

**核心概念：**
相关的元素应当靠近，不相关的元素应当分离。通过距离建立视觉分组。

**实现方式：**
- **距离**：相关元素间距小，不同组间距大
- **线条**：用线条框选或分隔
- **背景色块**：用色块包裹相关元素
- **留白**：通过负空间自然分组

**Prompt关键词：**
```
clear visual grouping, related elements clustered
tight spacing within groups, generous spacing between groups
contained text blocks, organized information hierarchy
```

**常见错误：**
- 所有元素间距相同，无法区分组别
- 相关元素分散在画面各处
- 不同信息挤在一起

---

## 原则3：分明的层级/对比 (Hierarchy/Contrast)

**核心概念：**
通过大小、颜色、粗细等差异建立视觉层级，引导阅读顺序。

**层级构建要素：**
- **大小对比**：主标题最大，逐级递减
- **粗细对比**：重要信息加粗，辅助信息细体
- **色彩对比**：重要信息用高对比色
- **空间对比**：重要信息占据更多空间

**三级信息架构：**
```
一级信息（核心）：抓注意力，必须第一眼看到
  ↓
二级信息（补充）：细化核心，被吸引后了解
  ↓
三级信息（辅助）：需要才看，可以不看
```

**Prompt关键词：**
```
strong visual hierarchy, clear information priority
extreme size contrast, bold headlines with subtle details
emphasis on main message, supporting elements secondary
dominant focal point with supporting context
```

**常见错误：**
- 所有文字大小相近，无主次
- 重要信息不够突出
- 层级过多（超过3级）

---

## 原则4：规矩的重复 (Repetition)

**核心概念：**
重复使用视觉元素（颜色、字体、图形、间距等），建立统一感和品牌识别。

**可重复元素：**
- **颜色**：主色、辅助色贯穿始终
- **字体**：标题字体、正文字体保持一致
- **图形**：Logo、图标、装饰元素的重复
- **间距**：统一的行距、段距、边距
- **纹理**：统一的背景纹理或图案

**Prompt关键词：**
```
consistent visual elements, repeating patterns
cohesive design language, unified style
brand consistency, rhythmic repetition
```

**常见错误：**
- 每页/每张图风格完全不同
- 颜色、字体随意变化
- 缺乏统一的视觉语言

---

## 原则5：得当的字体 (Typography)

**核心概念：**
字体的选择要符合主题意境，且一个画面不超过三种字体。

**字体选择原则：**
- **衬线体**：优雅、传统、文艺
- **非衬线体**：现代、简洁、力量
- **圆体**：友好、亲和、活泼
- **手写体**：个性、温度、艺术

**字体搭配：**
- 1种字体：通过大小/粗细变化建立层级
- 2种字体：标题字体 + 正文字体
- 3种字体：标题 + 正文 + 点缀（尽量少用）

**Prompt关键词：**
```
appropriate font choice, harmonious typography
consistent type family, readable text hierarchy
font matches theme and mood
```

**常见错误：**
- 一个画面使用超过3种字体
- 字体风格与主题不符
- 可读性差（过小、过细、过于装饰）

---

## 原则6：平衡的构图 (Composition)

**核心概念：**
画面元素的视觉重量均衡分布，创造稳定或动态的美感。

**经典构图法则：**
- **三分法**：画面分为3×3网格，重点放在交点
- **中心对称**：稳定、正式、庄重
- **对角线构图**：动感、活力、引导视线
- **黄金分割**：1:1.618 比例，自然美感
- **留白构图**：大量负空间，高级感

**视觉重量因素：**
- 大尺寸 = 重
- 高饱和度 = 重
- 深色调 = 重
- 复杂纹理 = 重
- 位于画面上方 = 较重

**Prompt关键词：**
```
balanced composition, visual equilibrium
rule of thirds, golden ratio placement
dynamic diagonal layout, centered symmetry
ample negative space, breathing room
```

**常见错误：**
- 画面一边过重，另一边过轻
- 元素挤在一起，无留白
- 主体位置尴尬（如正中间但无意义）

---

## 原则7：协调的配色 (Color)

**核心概念：**
色彩选择要和谐统一，通常2-4个主色即可。

**配色方法：**
- **单色法**：同一色相的不同明度/饱和度
- **互补法**：色环对面的颜色（蓝-橙、红-绿）
- **类似法**：色环相邻的颜色（蓝-蓝绿-绿）
- **三角法**：色环上等距的三种颜色

**配色比例（60-30-10法则）：**
- 60%：主色（背景）
- 30%：辅助色（主体/文字）
- 10%：点缀色（强调元素）

**Prompt关键词：**
```
harmonious color palette, cohesive color scheme
limited color palette, 2-3 main colors
color balance, appropriate saturation and contrast
```

**常见错误：**
- 颜色过多（超过4个主色）
- 颜色之间无关联，杂乱无章
- 对比度过低（看不清）或过高（刺眼）

---

## 8大原则速查表

| 原则 | 核心 | 检查问题 |
|-----|------|---------|
| 对齐 | 元素有视觉联系 | 有对齐基准线吗？ |
| 亲密度 | 相关靠近，无关分离 | 信息分组清晰吗？ |
| 层级 | 大小/颜色/粗细对比 | 一眼能看出主次吗？ |
| 重复 | 统一视觉元素 | 风格一致吗？ |
| 字体 | ≤3种，符合主题 | 字体合适吗？可读吗？ |
| 构图 | 视觉重量均衡 | 画面平衡吗？有留白吗？ |
| 配色 | 2-4色，和谐统一 | 颜色协调吗？ |
| 模块组织 | Prompt按学科拆分模块 | 每个模块只描述一个维度吗？ |

---

## 原则8：模块化的 Prompt 组织 (Modular Structure)

**核心概念：**
AI 生图模型是单次渲染，没有图层能力。将 Prompt 按设计学科拆分为独立模块，每个模块只负责一个维度，互不交叉污染。这比按空间叙事（如"前中后三层"）把不同的设计学科混在一起更有效。

**7 模块 Prompt 结构：**

```
COMPOSITION:  [版式骨架]   → 分割比例 + 对齐方式 + 留白 + 出血裁切
STYLE:        [画风层]     → 统一渲染语言、画法、光影逻辑（风格唯一挂载点）
SUBJECT:      [主体层]     → 人物/物体 + 情绪姿势 + 边缘/质感处理
TYPOGRAPHY:   [文字层]     → 标题字体/字号/颜色 + 副标题/角标块 + 图文穿插
COLOR:        [色彩层]     → 背景色调 + 文字色 + 点缀色 + 统领色调
TEXTURE:      [肌理层]     → 半调/噪点/纸张/水印满铺 + 各层透明度差异
SEPARATION:   [分离层]     → 三层分离手法 + Z轴三明治 + 焦点层级链
```

**模块编写铁律：**
- 每个模块只描述自己维度的事，不跨越到其他模块
- STYLE 段声明画风，不写构图/色值/文字内容
- SUBJECT 段不包含文字信息，TYPOGRAPHY 段不描述人物外貌
- COMPOSITION 只描述骨架（在哪里 / 怎么分 / 多少留白），不描述放什么
- 图文交叉效果写进 TYPOGRAPHY 段；Z 轴叠压关系写进 SEPARATION 段
- 每段之间用空行分隔，模块标题大写

**为什么不用空间叙事法：**
空间叙事（背景→中景→前景）会把 SUBJECT、TYPOGRAPHY、COMPOSITION 三个维度压缩到一条 Z 轴上混着写，导致改文字时要翻三个层、改配色时散落各处。模块化结构让每个设计维度独立，改一个字不影响其他模块。

**常见错误：**
- 按空间深度（前中后三层）把主体、文字、版式混在同一段落里
- TYPOGRAPHY 段里夹带人物外貌描述
- SUBJECT 段里混入版式决策

---

## Prompt中的原则映射

将8大原则融入AI Prompt的对应关系：

```
COMPOSITION → 原则1（对齐）+ 原则2（亲密度）+ 原则6（构图）
STYLE       → 原则4（重复）：统一渲染语言、画法一致
SUBJECT     → 原则3（层级）：明确视觉焦点
TYPOGRAPHY  → 原则3（层级）+ 原则5（字体）
COLOR       → 原则7（配色）
TEXTURE     → 原则4（重复）
SEPARATION  → 原则3（层级）：三层分离 + Z轴秩序
（原则8 模块组织 = 本结构本身）
```

**完整Prompt公式（7模块法）：**
```
COMPOSITION: [...]
  ↓
STYLE: [...]
  ↓
SUBJECT: [...]
  ↓
TYPOGRAPHY: [...]
  ↓
COLOR: [...]
  ↓
TEXTURE: [...]
  ↓
SEPARATION: [...]
  ↓
--ar [比例]
```
