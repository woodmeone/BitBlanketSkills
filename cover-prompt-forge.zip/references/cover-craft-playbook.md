# 爆款封面手法库（Cover Craft Playbook）

> 来源：从高播放量封面案例反向拆解的**通用设计手法**。
> 核心思想：**手法是机制，风格是皮肤。** 每个手法 = 风格无关的核心机制（为什么有效）+ 多风格实现变体（在你的风格里怎么写 prompt）。
> 组织方式：按 7 模块维度分章，生成 prompt 时按模块取用，不写进错误模块。
> 使用原则：每张封面从各维度挑 1–2 个手法即可，**禁止全堆**——手法之间会互相稀释焦点。

---

## 零、闸门（Z1–Z5）⚠️ 先过闸门，再挑手法

> **来源**：2026-09-13 对账号历史封面（Midnight V3 / V2 / 省token 三期）的诊断 + 封面案例库 11 张爆款反向拆解。
> **核心发现**：账号历史封面的问题**不是手法不够，而是元素太多**（单张 15–20 个元素），四个区域平均用力导致**没有绝对主角**；爆款封面元素预算仅 **2–5 个**。
> **底层约束（第一性原理）**：封面要在**手机端约 200px 宽 + 0.5 秒扫视**下工作。该尺寸下人眼可辨识的信息预算 ≈ **1 个焦点 + 3–5 个汉字**，超出的元素全部退化为噪点。
> **执行顺序**：本库其余章节（T/S/C/L/X/K）全是"加法手法"。**必须先用 Z1–Z4 把元素砍到预算内，再用 Z5 把层级落差拉开，最后才用加法手法放大留下来的那个主角**。顺序反了 = 加法叠在超载/平平的画面上，越做越糊越平。

---

### 手法 Z1：单点暴力放大（Hero Rule）

**机制：** 一张封面**只允许 1 个元素占画面面积 ≥40%**，它是唯一英雄。其余元素合计 ≤40%，全部服务于英雄。爆款的英雄可以是：一张夸张的人脸、一个占半屏的产品、一个巨大数字（如"6""75%"）、或一团巨大文字。

**判定方法（眯眼测试）：** 把封面缩到 200px 宽、再眯眼 1 秒——**只能有一个"第一眼"**。若第一眼看到两个或以上东西，说明没有英雄，直接重做。

**风格无关核心写法：**
```
one single hero element dominating at least 40% of the canvas area, 
everything else is supporting cast at a smaller scale, 
no two elements of comparable visual weight, 
unambiguous single focal point — squinting at a 200px thumbnail reveals exactly one thing
```

**风格化变体：**
| 风格 | 变体写法 |
|------|---------|
| 数字腐蚀/像素 | `the pixel memory cube scaled to fill 45% of canvas, its glow the brightest area, all icons shrunk to faint background dots` |
| 写实/测评 | `the product held at extreme close-up filling half the frame, presenter's face at comparable scale` |
| 极简扁平 | `one gigantic character occupying the center 40%, everything else pure negative space` |
| 电影感 | `one human face at huge scale in the foreground, environment reduced to atmosphere` |

**反面清单（本账号历史翻车点）：** ❌ 标题、主体、纸片、图标群各占 ~25%（四区平均） ❌ 三个"记忆同步"图标做得和主体一样清晰、各带两行小字 ❌ 边角塞 4 处可读英文小字块

---

### 手法 Z2：元素预算 ≤5

**机制：** 一张封面的**可辨元素总数上限 = 5**：`1 英雄 + 1 巨字(主文案) + 1 辅助 + ≤2 陪衬`。超额的只有两条出路——**合并进背景纹理**（降为不可读的装饰层）或**直接砍掉**。爆款案例的中位数是 **3 个**。

**执行方法（数元素清单）：** 生成 prompt 前，把你写进 prompt 的每一个可辨对象列成清单并计数。**每写一个元素前先问："它进得了 200px 缩略图吗？进不了就下沉成纹理。"**

**风格无关核心写法：**
```
strict element budget: total recognizable elements must not exceed five, 
background treated as pure texture rather than additional elements, 
any detail that cannot survive a 200px thumbnail is demoted to low-opacity background texture
```

**注意：** 背景**纹理**（网点、水印、噪点、缩略图墙）不计入元素预算——它们本来就是"不可读层"。计的是**可辨认的对象**（人、产品、图标、纸片、可读文字块）。

**反面清单：** ❌ 单张封面 15–20 个可辨元素 ❌ 图标群每个都带 2 行可读小字 ❌ 四角各塞一块可读信息

---

### 手法 Z3：缩略图验收（Thumbnail Test）

**机制：** 封面设计的**唯一验收尺寸是缩略图尺寸**，不是大图。B站手机端封面宽约 200px。任何只在大图好看、缩略图糊掉的细节，都是负资产。

**三条验收标准（全部通过才算合格）：**
1. **焦点**：缩到 200px，第一眼只剩**唯一**焦点（对应 Z1）
2. **主文案**：缩到 200px，**至少 3 个字可读**（对应 T4 短文案预算）
3. **情绪**：缩到 200px，**情绪能被感知**（脸 / 大符号 / 强色彩冲突，对应 S4）

**风格无关核心写法（写进 prompt 尾部作为收束指令）：**
```
designed to read clearly at 200px thumbnail width, 
maximum contrast between hero and background, 
all secondary details dissolve gracefully into texture when scaled down, 
optimized for single-glance recognition on small mobile screens
```

**注意：** 本闸门是 Z1/Z2/T4/S4 的**联合验收**，生成 prompt 后必须自问一遍再交付。

---

### 手法 Z4：黄金位分配（中央可读 / 四角不可读）

**机制：** 画面**中央 1/3 是黄金位**，只放英雄 + 主文案；**四角与边缘是垃圾位**，只放**不可读**的装饰（重复符号、网点、噪点、代码碎片、缩略图墙）。**可读的小字块放进四角 = 浪费黄金位、污染垃圾位**——它在缩略图下既读不出、又抢焦点，是双重损失。

**风格无关核心写法：**
```
central third of the canvas reserved exclusively for the hero and the main title, 
all four corners and edges hold ONLY non-readable decoration (texture, repeated symbols, halftone dots, noise), 
no readable caption blocks placed in the corners, 
readable text exists only in the central band
```

**注意：** 唯一例外是**账号品牌标版**（如频道名/logo 条），它是品牌资产不是信息，且应做成"识别图形"而非"待阅读的小字"。

**反面清单：** ❌ 四角英文小字块（SAME MEMORY / ONE MEMORY MORE WORLDS…） ❌ 竖排可读英文装饰行被当信息读

---

### 手法 Z5：三级梯度（层次闸门）

> **来源**：2026-09-13 用户对 v2 封面的反馈——"感觉没有层次"。元素已经砍到预算内、英雄也有了，但画面仍然"平"，因为**层级之间的落差不够**。

**机制：** "层次感"的本质不是"排得整齐"，而是**相邻层级之间的落差**。人眼靠**对比**给元素排序——没有对比就没有秩序感。多数"平"的封面不是元素多，而是**几个元素在字号、明度、锐度上几乎一样**，读者不知道先看谁。爆款封面的层级是**每一级在多个维度上同时退后一档**。

**核心规则：全画面只允许 1 个"满配"元素**（最亮 + 最大 + 最锐）＝第一信息。**其余每一个元素都必须至少在一个维度上降档**，越靠后降得越多。

**四个可调维度（相邻两级至少拉开其中 2 个）：**

| 维度 | 一级（满配，唯一） | 二级 | 三级 |
|---|---|---|---|
| 字号 | 100% | **≤55%** | **≤30%** |
| 明度（深底封面） | 纯纸白 `#fbfdfd` 100% | ≤70% 亮度（如 `#bac2f7` 或 70% 不透明纸白） | ≤45% 亮度（暗灰，接近背景） |
| 锐度 | 0 blur，边缘最锐 | 轻微软化 / 降分辨率 / 半调化 | 明显虚化或并入背景纹理 |
| 面积 | ≥40%（英雄） | ≤15% | ≤5%（并入装饰层） |

**硬约束：**
1. **相邻字号比 ≥ 1.6×**（100 : 55 : 30）。**禁止 100 : 80 这种"看起来差不多大"**——这是二级压不住一级、画面变平的头号原因。
2. **全画面只允许一个最亮元素**；第二亮与最亮之间要有**肉眼可感**的亮度台阶（建议 ≥25% 明度差）。
3. **文字与主体必须有 Z 轴叠压关系**（见 L1），**禁止纯上下/左右并排**——并排是"平"的首因；叠压（遮挡+投影）才有纵深。
4. 焦点链只有一条、只分三级（文案/主体/背景的锐度排序），**不设第四级中间态**（见 L2）。

**风格无关核心写法：**
```
strict three-tier visual hierarchy: exactly one element at full intensity (brightest AND largest AND sharpest), 
every other element steps down at least two notches across size, brightness and sharpness, 
adjacent tiers differ by at least 1.6x in type size and a clearly visible brightness step, 
a single three-level focus chain — sharpest → softened → most diffused — with no fourth intermediate level, 
title and subject overlap on the Z axis with occlusion and cast shadows rather than sitting side by side
```

**判定方法（灰度缩略图测试）：** 把封面转成**灰度**、缩到 200px——应能看出一条**清楚的明度梯子**（一个最亮 → 次亮 → 暗），而不是"几个差不多亮的白块平铺"。若灰度图里主标题、主体、副标题亮度接近，即未通过。

**注意：** Z5 与 Z1 互补，不冲突——Z1 管"只有 1 个主角"（面积），Z5 管"主角比配角亮/大/锐多少"（梯度）。英雄定完之后，**必须用 Z5 把其余元素逐级压低**，否则英雄立不住。

**反面清单（本账号历史翻车点）：** ❌ 主标题与主体方块同亮度、同锐度，互相抢"最亮" ❌ 副标题字号做到主标题的 70–80%，二级反压一级 ❌ 全画面元素都锐、都白、全在同一个"亮度平面"上 ❌ 主标题与主体上下并排、零叠压

---

### 闸门速查（生成 prompt 前逐条打勾）

| 闸门 | 判定 | 不过怎么办 |
|---|---|---|
| Z1 英雄唯一 | 眯眼看 200px，只有 1 个第一眼 | 放大英雄到 ≥40%，其余缩小 |
| Z2 元素 ≤5 | 可辨元素数清单 ≤5 | 合并进纹理 / 砍掉 |
| Z3 缩略图验收 | 焦点 + 3 字可读 + 情绪 | 回到 Z1/T4/S4 调 |
| Z4 黄金位 | 四角无可读小字 | 小字块移入中央或删除 |
| Z5 三级梯度 | 灰度 200px 下能看出明度梯子；相邻字号 ≥1.6× | 压低二/三级的字号、明度、锐度；给文字与主体加叠压 |

---

## 一、文案配置（TYPOGRAPHY 维度）

### 手法 T1：超大出血标题

**机制：** 标题字号大到顶出/切出画面边界，文字从"标签"升级为"建筑"。字被边框切掉一部分反而制造冲击力——读者会脑补完整字形，参与感更强。高播放封面几乎全员使用。

**字号基准：** 主标题 ≥ 画面高度的 20–25%（多数模板默认 14–18%，偏小）。文字面积可占画面 30–40%，成为构图骨架本身。

**风格无关核心写法：**
```
title characters massively oversized, {20-25}% of canvas height per character, 
extending beyond canvas edges, partially cropped by frame borders, 
typography as architecture not label
```

**风格化变体：**
| 风格 | 变体写法 |
|------|---------|
| 像素风 | `pixel font glyphs with hard pixel edges, cropped at frame border mid-stroke` |
| 手写/书法 | `brush calligraphy strokes bleeding off canvas, ink trail exiting frame` |
| 金属/立体 | `3D beveled metallic letters partially exiting frame, dramatic scale` |
| 极简扁平 | `flat grotesque typeface at architectural scale, single character cropped` |
| 故障/数字腐蚀 | `title glyphs sliced by frame edge with RGB-split glitch residue at the cut` |

**注意：** 出血方向与构图联动——4:3 横版左右出血，3:4 竖版上下出血。被切的笔画不超过单字的 30%，否则字形无法辨认。

---

### 手法 T2：文字层级双路径（主体层 vs 氛围层）

**机制：** 一级文案只有两种合法位置——**当主角**或**当背景**，没有中间态。半大不小、半实半虚的文字是最常见的翻车原因。

**路径 A：文字即主体（实心高对比）**
- 适用：观点/金句类、文字本身有冲击力时
- 写法：`title in solid high-contrast fill, razor-sharp 0px blur, the primary focal layer`
- 变体：金属渐变立体（舞台感）、实心黑体（杂志感）、像素实心（科技感）

**路径 B：文字退成氛围（风格化退后）**
- 适用：主体（人物/IP/产品）是焦点时
- 机制：用**风格自有的"退后手段"**降低文字焦点级别，主体在前
- 退后手段按风格选择，**禁止跨风格混用**：

| 风格 | 退后手段 | 写法 |
|------|---------|------|
| 电影感/梦幻 | 虚化+柔光 | `background title softly defocused, gaussian blur 6-10px, glowing haze` |
| 故障/数字腐蚀 | RGB 通道分离残影 | `background title with chromatic aberration ghost offset in {accent1}/{accent2}, base glyph dimmed to 40% opacity` |
| 像素风 | 降分辨率+降饱和 | `background title rendered at half pixel resolution, desaturated, dithered` |
| 复古印刷 | 半调网点化 | `background title dissolved into coarse halftone dots, ink fading` |
| 水彩/手绘 | 洇开淡化 | `background title bleeding into wet watercolor wash, edges dissolving` |

---

### 手法 T3：角标信息块（杂志感小字）

**机制：** 二级/三级文案**收拢成角落小字块**，主标题独占视觉层级。小字块提升信息密度和设计感（杂志感），同时不和主标题抢戏。解决"二级文案太小看不清"的反例是——它本来就不该大，而是该**聚拢、成型、有边界**。

**三种形态：**
1. **角落信息块**：左下/右下 2–4 行短句（中文关键词 + 英文小字对照）
2. **竖排装饰行**：画面侧缘竖排英文/拼音，纯装饰性
3. **胶囊/贴纸标签**：主体附近的胶囊形小标签（背书词：免费/开源/实测）

**风格无关核心写法：**
```
small caption block anchored at {bottom-left} corner, 2-4 lines of compact text: 
"{keyword_cn}" with english translation "{keyword_en}" beneath in smaller size, 
plus one vertical decorative text line "{vertical_text}" along the {right} edge, 
these tertiary texts are intentionally small and grouped, 
they do NOT compete with the main title
```

**风格化变体：**
- 像素风：`pixel sticker tag with 1px border, looks like a peeled label pasted on canvas`
- 杂志/编辑风：`thin rule line above caption block, swiss editorial layout`
- 赛博/科技：`HUD-style data readout corner block, monospace font`

**注意：** 角标块总面积 ≤ 画面 8%。竖排装饰行不承担信息职责，看不清也无所谓。
**⚠️ 与 Z4 的优先级：** 本手法在**大图/海报**中成立；在**缩略图场景**下 Z4 优先——角标块必须**紧邻中央黄金带**（如主体正下方同列），或直接降级为不可读装饰。**禁止把可读小字孤零零丢在四角**（缩略图下既读不出又抢焦点）。

---

### 手法 T4：短文案硬预算（主 ≤6 字 / 副 ≤12 字）

**机制：** 缩略图下主文案可读字数上限约 **6 个汉字**（200px 宽时更少）。爆款主文案实测均值 **4–5 字**（"诺兰""AI虚拟小镇""AI界卷王""实测GPT6""直接省75%"）。**长句不是不能有，而是不该出现在封面主文案位**——它应该下沉到标题栏与简介，由平台 UI 承担。

**三级字数预算：**
| 层级 | 上限 | 位置 | 例子 |
|---|---|---|---|
| 主文案 | **≤6 字** | 中央黄金带或当作巨字英雄 | 省 75% token / 手机AI / 它还记得你 |
| 副文案 | **≤12 字** | 紧邻主文案下方（同列） | token 直接砍半 |
| 三级信息 | 不上封面 | 下沉到标题/简介 | （本期三件更新…） |

**风格无关核心写法：**
```
main cover text limited to six Chinese characters maximum in oversized type, 
one optional subline of no more than twelve characters directly beneath it, 
all longer explanations removed from the cover and left to the title field, 
the cover text is a slogan NOT a sentence
```

**注意：** 字数超预算时，**先砍信息、再砍字数**——保留钩子词（疼点/数字/结果），删掉修饰与并列。例：`装了这个skill，直接多平台通用记忆库`（16 字）→ 拆解后主文案取 `换工具，还记得你`（7 字，仍超 1 字，可压成 `换了它，还记得你`）。**判断标准：缩到 200px 后还能读出 ≥3 字。**

**反面清单（本账号历史翻车点）：** ❌ 主标题写满两行 12+ 字（"装了这个skill / 直接多平台通用记忆库"） ❌ 副文案再写两行 12 字（"这次接通了本地向量 / token优化了不少"）→ 封面共 4 行中文，缩略图全糊

---

## 二、主体配置（SUBJECT 维度）

### 手法 S1：情绪姿势（主体要有"戏"）

**机制：** 主体不是站桩证件照，而是**进行中的情绪动作**。高播放封面的主体全部带"戏"：摊手（无奈/摊牌）、趴桌（慵懒/摆烂）、捧脸对峙（亲密/冲突）、侧脸凝视（故事感）。情绪姿势让封面在 0.5 秒内传递内容调性。

**姿势速查库：**
| 内容调性 | 姿势 | prompt 关键词 |
|---------|------|--------------|
| 测评/分享 | 摊手、耸肩 | `shrugging with open palms, expressive "what can you do" gesture` |
| 反卷/躺平 | 趴桌、靠椅 | `slumping on desk, chin resting on arm, languid pose` |
| 悬念/故事 | 侧脸、回头 | `profile view gazing into distance, contemplative` |
| 冲突/对比 | 双人互动、对峙 | `two figures in dramatic interaction, tension between them` |
| 兴奋/安利 | 前倾、指向 | `leaning toward viewer, pointing at focal element` |

**风格无关核心写法：**
```
subject captured mid-gesture, {pose_keyword}, emotionally expressive, 
NOT a static passport-style standing pose, 
the pose itself narrates the content's tone
```

**非人物主体的迁移：** 无人物时让**物体拟人化做动作**——天平正在倾倒、链条正在崩断、齿轮正在咬合。关键词：`frozen at the peak moment of {action}`（见 S2）。

---

### 手法 S2：瞬间峰值帧

**机制：** 选动作张力最高的那一帧，而不是动作的完成态。倾倒 30° 比已倒下更有张力，断裂中途比已断更有张力。悬念来自"下一秒会怎样"。

**风格无关核心写法：**
```
frozen at the peak moment of the action, mid-motion, 
the instant of highest tension, motion implied but suspended, 
NOT the completed/resting state
```

**风格化变体：**
- 故障/数字腐蚀：在动作方向上拖 RGB 残影，兼作运动拖尾 `glitch ghost trailing along the direction of motion, doubling as motion blur`
- 动漫/二次元：速度线+形变 `speed lines, slight smear-frame distortion`
- 写实/摄影：高速快门感 `high-speed photography freeze, suspended particles`

---

### 手法 S3：轮廓光剥离

**机制：** 用边缘光（逆光/侧逆光）把主体从背景中"剥"出来，尤其适合主体与背景色调接近时。比描边柔和，比无处理立体。

**风格无关核心写法：**
```
strong rim light from behind-side outlining the subject's silhouette, 
glowing edge separating subject from background, 
subject partially backlit with halo on the contour
```

**风格化变体：**
- 赛博/科技：霓虹色轮廓光 `neon {accent} rim glow`
- 电影感：暖金逆光 `warm golden backlight, anamorphic haze`
- 像素风：用 1–2px 亮色像素描边替代柔光 `hard pixel outline in {accent}, no soft glow`

---

### 手法 S4：情绪锚点降级链（脸 → 符号 → 拟人）

**机制：** 大脑对面孔有硬连线优先识别，这就是爆款封面几乎都有夸张人脸的原因。但**无真人/无 IP 可用时不能放弃情绪锚点**——按降级链取第一个可用的：**真人脸 → 巨大情绪符号（`!` `?` ❓）→ 巨大数字 → 拟人化角色**。四者至少命中一个，情绪才能在 200px 缩略图下被感知（Z3 的第三条验收）。

**降级链与写法：**
| 优先级 | 锚点 | 适用 | prompt 关键词 |
|---|---|---|---|
| 1 | 真人夸张表情 | 有出镜/IP | `exaggerated facial expression, wide eyes, open mouth, brows raised` |
| 2 | 巨大情绪符号 | 无人物、抽象议题 | `giant exclamation and question marks floating at huge scale, expressing shock and confusion` |
| 3 | 巨大数字 | 有量化结果 | `one giant numeral as the visual hero, oversized to 40% of canvas` |
| 4 | 拟人化角色 | 像素/插画风 | `a small mascot character scaled up to 25-30% of canvas, acting out the emotion` |

**风格无关核心写法：**
```
one emotional anchor present at large scale — either an exaggerated human face, 
or a giant punctuation symbol, or an oversized numeral, or an anthropomorphic mascot, 
the emotional state readable at a glance even in a 200px thumbnail
```

**反面清单（本账号历史翻车点）：** ❌ 全画面只有方块/数据库/图标等无生命体 ❌ 像素小人是现成的情绪资产，却缩在角落纸片里只有指甲盖大（应在像素风封面中放大到 25–30% 当锚点）

---

## 三、构图配置（COMPOSITION 维度）

### 手法 C1：出血裁切

**机制：** 元素主动伸出画面边界，打破"裱在框里"的局促感。文字出血（T1）之外，主体同样可以出血——脚踩出底边、头顶出上边。

**风格无关核心写法：**
```
{subject/title} deliberately bleeding off the {bottom/side} frame edge, 
break-the-frame effect, composition extends beyond canvas, 
NOT everything contained with margins
```

**注意：** 一张图最多两类元素出血（如字+主体），全出血等于没出血。

---

### 手法 C2：文字即构图骨架

**机制：** 文字面积占 30–40% 时，文字本身就是构图的分割线/配重块，不再是"摆在构图里的字"。左图右文不再是 40/60 分割，而是"字墙 vs 主体"的对抗构图。

**风格无关核心写法：**
```
the oversized typography itself forms the compositional skeleton, 
a wall of characters acting as one mass counterbalanced by the subject mass, 
two-weight composition: text mass vs subject mass
```

---

### 手法 C3：双区对比结构（Before → After / A → B）

**机制：** 案例库中最高频的结构。**两区 + 一个明确对比变量**让观众 0.5 秒内"比出结论"，无需阅读。既有案例：`长卡 800tok →×→ 短卡 200tok`（省token）、`真人 →箭头→ 卡通`（中国人能飞）、`人 →海报宇宙`（诺兰）、`Before 失忆 → After 记忆库`（本账号 V3，结构本身是对的）。

**两个硬约束：**
1. **对比变量唯一**：两区只能有 1 个不同的东西（价格/容量/状态/形态），其余元素保持一致（重复原则，让差异自己跳出来）
2. **对比双方都要大到可辨**：两区主体各自 ≥画面 30%（Z1 的"英雄"可以是"一对对比体"，但这对对比体必须共同占 ≥40%，且**彼此视觉权重相当**）

**风格无关核心写法：**
```
diptych composition: two zones of comparable area side by side, 
exactly one variable differs between them, everything else mirrored/identical, 
both sides scaled large enough to be legible at thumbnail size, 
a bold arrow or divider between them stating the transformation
```

**反面清单（本账号历史翻车点）：** ❌ 对比主体（Before 纸片 / After 方块）被顶部标题压到只剩 20% 面积，对比关系在缩略图里读不出 ❌ 对比区里又塞了 3 个图标，稀释了那唯一一个对比变量（30% → 20%）→ 应删掉图标，让"失忆 vs 记住"这一组差异独占左/右

---

### 手法 C4：黄金位分配（中央可读 / 四角不可读）

**机制：** 与 Z4 同源，落到构图模块的写法。**中央 1/3 = 英雄 + 主文案（唯一可读带）**；**四角与边缘 = 不可读装饰层**。构图骨架先定"哪里可读哪里不可读"，再去填元素——顺序反了就会像历史封面那样把可读小字撒满四角。

**风格无关核心写法：**
```
composition reserves the central third for the hero and the main title only, 
the four corners and edges are dedicated to non-readable ambient decoration, 
a single readable band runs through the middle of the canvas, 
no readable information lives outside this band (except the brand mark)
```

**注意：** 若必须放品牌标版（频道名/logo 条），把它做成"图形识别块"（高对比、成块、不期待被阅读），并允许置于上方角落——这是 C4 的唯一豁免项。

---

### 手法 C5：视线路径驱动（Z / F / S / 对角 / 放射 / 引导线）

> **来源**：2026-09-13 用户反馈（四）——"构图上应该不止一个居中构图吧？我发现似乎只有居中构图和左右对比构图"。案例来源：`横板构图.png`（11 Z字视觉型 / 12 F型布局型 / 10 对角引导型）+ `竖版构图.png`（7 Z字 / 8 S字 / 9 对角线 / 11 放射 / 15 引导线）。

**机制：** 构图不是"把东西摆在格子里"，而是**先规划眼睛的行走路线**——用一条路径串起 2–4 个视觉停靠点，再把元素挂到路径上。观众"看完"的过程就是"被说服"的过程（先看到什么、再看什么、最后落在结论上）。

| 路径 | 结构 | 视线终点 | 适配内容 | 画幅 |
|---|---|---|---|---|
| **Z 型** | 左上 → 右上 → 左下 → 右下 | 右下角结论 | 图文信息量中等、有前后因果 | 横版主用 |
| **F 型** | 左上重读 → 右上扫 → 纵向快扫 | 左上 | 信息量大的说明类（偏正文版面，封面慎用） | 横版 |
| **S 型** | 上左 → 中右 → 下左 蛇形蜿蜒 | 底部落款/结论 | 故事 / 情感 / 旅行 | 竖版 |
| **对角型** | 左下 → 右上（或反向）单条斜线 | 斜线顶端的主体 | 强动态 / 冲突 / 运动 / 速度感 | 两者皆可 |
| **放射型** | 主张力点居中，元素向心或离心发散 | 中心（向心）/ 四周（离心） | 焦点爆破 / 揭秘 / 发布会 | 竖版强 |
| **引导线型** | 用光带 / 箭头 / 透视线把人眼从边角拽到主体 | 主体 | 主体必须偏置时的补救手段 | 两者皆可 |

**风格无关核心写法：**
```
the composition follows a single {Z / diagonal / S / radial / leading-line} sightline: 
the eyebrow text sits at the first stop, the hero at the focal stop, 
the conclusion line at the terminal stop, 
and {a light band / an arrow / the character baseline} physically draws that path; 
every element sits ON the path, nothing floats off it
```

**注意：** 一张图**只允许一条路径**。两条路径交叉＝视线打架＝等于没有路径。

---

### 手法 C6：块面分割范式（全宽 / 分栏 / 三分 / 上下 / 穿插 / 叠压）

> **来源**：`横板构图.png`（01 全宽视觉型 / 02-03 左图右文·右图左文 / 04-05 图文上下·上文下图 / 06 左右分栏 / 15 图文穿插）+ `竖版构图.png`（4-5 左图右文·右图左文 / 6 图文穿插 / 14 叠压构图）。

**机制：** 横版看"左右怎么分"，竖版看"上下怎么分"。块面分割直接决定**信息密度**与**阅读顺序**。

| 范式 | 结构 | 一句话 | 适配 |
|---|---|---|---|
| **全宽视觉型** | 主体/背景满幅铺满，文字压在视觉焦点上 | 冲击力最大 | 横版｜强情绪 / 大场面 |
| **左右分栏型** | 两栏等权并置（1:1） | 对比 / 并列 | 横版｜A/B 对比（与 C3 叠加使用） |
| **三分格局型** | 三块并置 | 多点并列、节奏均匀 | 横版｜多条目 / 工具盘点（最易违反 Z2） |
| **图文上下型** | 上文字下图像，或上图像下文字 | 层级分明、结构清楚 | 两者皆可｜长文 / 说明 |
| **左图右文 / 右图左文** | 图占 60–70%，文占 30–40% | 平衡、信息清晰 | 竖版｜测评 / 教程 |
| **图文穿插型** | 图文交错咬合、互相穿进对方区域 | 节奏丰富、内容量最大 | 两者皆可｜多段内容 |
| **叠压构图型** | 3–4 层纸片 / 卡片错位叠压 | 纵深最强、信息最多 | 竖版｜合集 / 多素材 |

**风格无关核心写法：**
```
block composition: {full-bleed / two-column / three-panel / stacked / interlocking / layered-overlap}, 
blocks divided by a hard edge or an explicit divider, never more than three blocks, 
block boundaries align to one another on a common grid
```

**注意：** 分栏 / 三分的"多块"最容易违反 Z2 —— **块面整体算 1 个元素，但每块内部的可辨内容必须 ≤2 个**，否则缩略图必糊。

---

### 手法 C7：空间修辞（留白 / 框架 / 螺旋 / 背景延展）

> **来源**：`横板构图.png`（13 框架包围型 / 14 留白呼吸型 / 16 背景延展型）+ `竖版构图.png`（12 框架构图 / 13 留白构图 / 16 黄金螺旋构图）。

**机制：** 三种"用空间本身说话"的构图——**留白＝贵、框架＝聚焦、螺旋＝引导**。

| 范式 | 结构 | 传达 | 适配 |
|---|---|---|---|
| **留白呼吸型** | ≥60% 负空间，主体小且偏置在黄金位 | 高级、克制、可读性高 | 知识 / 极简 / 观点 |
| **框架包围型** | 主体被边框 / 门 / 窗 / 圆框 / 手机屏幕套住 | 聚焦、秩序、安全感 | 揭秘 / 重点强调 |
| **背景延展型** | 背景满幅延展 + 内容压在视觉焦点区 | 氛围强、大气 | 横版｜电影感 |
| **黄金螺旋型** | 元素沿黄金螺旋由大到小渐次排列 | 优雅、天然引导视线 | 大片感 / 故事 |

**风格无关核心写法（留白为例）：**
```
the composition breathes: over 60% clean negative space, 
the hero sits small and off-center on a golden-ratio point, 
the type occupies the calm area, nothing fills the edges
```

**注意：** 留白型封面在小尺寸下会"显空"——**留白里必须有一处最强对比**（唯一的彩色焦点或唯一的高亮），否则缩略图像"没做完"。留白 ≠ 空。

---

### 手法 C8：视觉配重范式（居中 / 上重下轻 / 下重上轻 / 重点突出）

> **来源**：`竖版构图.png`（1 居中构图 / 2 上重下轻 / 3 下重上轻）+ `横板构图.png`（08 重点突出型 / 09 居中聚焦型）。

**机制：** 竖版（3:4）没有"左右分"的余地，真正的变量是**上下的重量分配**；横版则多一个"巨块 + 小字组"的重点突出结构。

| 范式 | 结构 | 视线落点 | 适配 |
|---|---|---|---|
| **居中聚焦型** | 主体居中，其余元素向心 | 正中央 | 通用（最稳，也最平） |
| **上重下轻** | 主体占上半，标题/文字落下方 | 上 → 下 | 竖版通用：人物/产品在上、标题在下 |
| **下重上轻** | 大主体压在下半，标题悬在上部 | 上（标题）→ 下（主体） | 竖版：先给结论再看证据 |
| **重点突出型** | 一个巨块 + 一组小字分列 | 巨块 → 小字 | 横版｜一句话结论 |

**注意：** **居中构图最大的问题是"平"**——它必须与 Z5（明度/字号落差）+ E1（边缘落差）+ L1（Z 轴叠压）联合使用才成立。**单独用居中 ≈ 平庸**，这是本账号历史封面的第二个病因（第一个是元素过载）。选择居中时，自检表必须额外标注"Z5/E1 已启用"。

---

### 构图范式总表（32 型 → 封面可用性分级）

> 星级：★★★ 封面直接可用｜★★ 需配合其他手法（Z5/E1/L1）｜★ 封面慎用（更适合正文版面）

| 横版 16 型（`横板构图.png`） | 星级 | 竖版 16 型（`竖版构图.png`） | 星级 |
|---|---|---|---|
| 01 全宽视觉型 | ★★★ | 1 居中构图 | ★★（须配 Z5/E1） |
| 02 左图右文型 | ★★ | 2 上重下轻 | ★★★ |
| 03 右图左文型 | ★★ | 3 下重上轻 | ★★★ |
| 04 图文上下型 | ★★ | 4 左图右文 | ★★ |
| 05 上文下图型 | ★★ | 5 右图左文 | ★★ |
| 06 左右分栏型 | ★★（与 C3 叠加） | 6 图文穿插 | ★★★ |
| 07 三分布局型 | ★（易破 Z2） | 7 Z 字构图 | ★★★ |
| 08 重点突出型 | ★★★ | 8 S 字构图 | ★★ |
| 09 居中聚焦型 | ★★（须配 Z5/E1） | 9 对角线构图 | ★★★ |
| 10 对角引导型 | ★★★ | 10 三分构图 | ★★ |
| 11 Z 字视觉型 | ★★★ | 11 放射构图 | ★★★ |
| 12 F 型布局型 | ★（偏正文版面） | 12 框架构图 | ★★ |
| 13 框架包围型 | ★★ | 13 留白构图 | ★★★ |
| 14 留白呼吸型 | ★★★ | 14 叠压构图 | ★★★ |
| 15 图文穿插型 | ★★★ | 15 引导线构图 | ★★ |
| 16 背景延展型 | ★★★ | 16 黄金螺旋构图 | ★★ |

### 横竖版构图切换规则

- **横版（4:3 / 16:9）**：优先"左右 + 全宽 + 水平路径"（全宽视觉型、左右分栏、Z 字、对角、背景延展）；文字**左对齐横穿**。
- **竖版（3:4）**：优先"上下 + 向心/螺旋"（上重下轻、下重上轻、Z/S 字、放射、叠压、留白）；文字**居中纵跨**。
- **同一内容换画幅时：只换范式，不换手法组合**（STYLE / COLOR / E1 / E2 跨画幅共享），否则两版封面会像两个账号。

---

## 四、层次配置（SEPARATION 维度）

> **来源（2026-09-13 反馈五）**："层次的构造应该同样不止一个吧？"——把"层次"从单一的 Z5 三级梯度，展开成**六条可独立拉差的构造通道**。**Z5 是总闸门（管"差多少"），下面六条通道是手段（管"用什么差"）。一张封面至少启用 2 条通道**——只靠一条（尤其是只靠字号）仍会显平。

**层次六通道总览（+ 第七条在第七章）：**

| 通道 | 手法 | 主要变量 | 与谁去重 |
|---|---|---|---|
| **Z 轴** | L1 三明治叠压 | 遮挡 / 前后顺序 | — |
| **虚实** | L2 焦点层级链 | 锐度 / 模糊档数 | — |
| **光照** | L3 光影分层 | 受光量 / 光源方向 | ≠ X2（X2 是一块氛围过曝区；L3 是按层级分配受光） |
| **色彩** | L4 饱和分层 | 饱和度 / 冷暖 | ≠ K1（K1 是全场罩同一个色调；L4 是同色调内的饱和梯度） |
| **材质** | L5 材质分层 | 表面精度 / 细节密度 | ≠ X1（X1 是背景重复水印；L5 是主体与背景的材质落差） |
| **空间** | L6 空气透视分层 | 近实远虚 + 近暖远冷 | ≠ L2（L2 只分锐度；L6 需四线同降） |
| **边缘** | E1 边缘落差链（第七章） | 描边 / 投影 / 发光 | 唯一的"边缘"通道 |

---

### 手法 L1：三明治叠压三选一

**机制：** 文字与主体必须有明确的 Z 轴叠压关系，**并排摆放是封面平庸的首要原因**。三种合法结构，按内容焦点三选一：

| 变体 | 结构 | 焦点归属 | 适用 |
|------|------|---------|------|
| **A 字压人** | 背景 → 主体 → 文字（最前） | 文字优先 | 观点/金句/大字报 |
| **B 人压字** | 背景 → 文字 → 主体（最前） | 主体优先 | 人物 IP/产品/测评 |
| **C 前后夹** | 背景 → 文字后排 → 主体 → 文字前排 | 共享焦点，纵深最强 | 故事/影视/高制作感 |

**风格无关核心写法（以 C 为例）：**
```
explicit Z-order sandwich: background → rear title line → subject → front title line, 
front characters cast hard shadows onto the subject, 
rear characters partially occluded by the subject's silhouette, 
vertical sandwich creates aggressive depth, 
elements are NEVER placed side-by-side without overlap
```

**注意：** 变体 C 的"前排文字"通常是主标题的 1–2 个字或副标题，全压会闷死主体。配合 `separation-techniques.md` 的交叉遮挡手法写交界处。

---

### 手法 L2：焦点层级链

**机制：** 全画面只有一条焦点链，三级定死：**文案(最锐) → 主体(次锐) → 背景(最柔)**，或 **主体 → 文案 → 背景**（B 结构时）。用各风格自有的锐度手段实现（虚化/残影/降分辨率，见 T2 表格）。

**量化（与 Z5 配套）：** 三级之间的锐度差必须**肉眼可感**——最锐层 0 blur 硬边，中间层轻微软化/降分辨率（如像素风降一档像素密度），最柔层明显虚化或并入纹理。**禁止第四级中间态**：一旦出现"半锐不锐"的第四层，焦点链就断了，画面就平了。

**风格无关核心写法：**
```
single focus chain: {sharpest layer} razor-sharp → {middle layer} subtly softened → 
{background} most diffused, no fourth intermediate level, 
every element's sharpness matches its rank in the hierarchy
```

---

### 手法 L3：光影分层（照明通道）

**机制：** 光是最诚实的层次语言——**谁被主光照到，谁就是主角**。把"受光量"当层次变量分配：一级被唯一主光直射，二级只吃环境光/反射光，三级落进暗部。**全场均匀打光＝没有层次。**

| 层级 | 照明待遇 |
|---|---|
| 一级 | 唯一主光直射：最亮、最硬、方向最明确 |
| 二级 | 只受环境光/反射光：亮度约一级的 **60–80%**，对比弱 |
| 三级 | 落进暗部：只保留剪影或边缘光，细节不读 |

**风格无关核心写法：**
```
single-key lighting hierarchy: one directional key light strikes only the hero, 
every other layer is lit by ambient bounce at roughly 60-80% of that brightness and far lower contrast, 
the tier-3 layer falls into shadow and survives only as silhouette or rim light; 
no even flat lighting anywhere
```

**注意：** 光源方向必须唯一，且与 E1 的投影方向一致。**N 个光源 = N 个主角 = 没有主角。**

---

### 手法 L4：饱和分层（色彩通道）

**机制：** 在同一个统领色调（K1）之内，再用**饱和度/冷暖**分一层：一级最饱和，向二、三级递减，直到近灰或完全去色。**去色的部分自动退后，留色的部分自动向前。**

| 层级 | 饱和度待遇 |
|---|---|
| 一级 | 全图最饱和，或**唯一真正有彩**的元素 |
| 二级 | 大幅降饱和（约一级的 30–50%），只保留一点色相 |
| 三级 | 近灰 / 完全去色 |

**风格无关核心写法：**
```
a saturation ladder living inside the single tonal cast: 
the hero is the most saturated — or better, the only truly colorful element in the frame — 
tier-2 is heavily desaturated, tier-3 drops to near-greyscale; 
color intensity itself encodes rank
```

**注意：** 若全图走"近乎单色"路线，就把**唯一的彩色留给一级**——这是最强的高亮；反过来，二级若也高饱和，Z5 立刻被削弱。

---

### 手法 L5：材质分层（质感通道）

**机制：** 让不同层级穿不同的"表面处理"：一级**最精**（细节密度高、有高光/反光/材质反射），二级**简化**（纯色平涂块面），三级**最糙**（颗粒、噪点、半调网点、纸纹）。**精度也是等级。**

**风格无关核心写法：**
```
material hierarchy: the hero carries the richest surface (fine detail, specular highlights, material sheen); 
tier-2 is flattened into clean solid shapes; 
the background is coarse (grain, halftone dots, paper fibers); 
surface detail density decreases with rank
```

**注意：** 与 X1/X2 的区别——X1 是"铺一层重复水印"（信息层），L5 是"主体与背景的表面精度落差"（层次层）。二者可叠加。

---

### 手法 L6：空气透视分层（空间通道）

**机制：** 真正意义的"层次"是纵深：前中后三层**同时按四条线衰减**——近大远小、近实远虚、近暖远冷、近对比强远对比弱（远景再被前景遮挡）。**四条一起降才叫空间；只做模糊（L2）只是"虚"，不是"深"。**

| 层 | 位置 | 四条衰减 |
|---|---|---|
| **前景** | 贴边、最大、允许被裁切 | 最实 / 最暖 / 对比最强 / 常压成暗剪影 |
| **中景（主体）** | 视觉焦点 | 次实 / 中性 / 全图对比峰值 |
| **远景** | 最后方、最小 | 最虚 / 最冷（偏蓝灰）/ 对比最弱 / 常被提亮成"雾" |

**风格无关核心写法：**
```
atmospheric perspective built from three planes: a large near silhouette hugging the frame edge, 
the hero in the middle plane in full focus, 
and a distant background receding in four ways at once — smaller, 
blurrier, cooler (drifting toward blue-grey) and lower in contrast — 
so the image reads as depth, not as a flat blur
```

**注意：** 与 C7 的区别——C7 用空间修辞（留白/框架）说话，L6 用纵深衰减说话；与 L2 的区别——L2 只分锐度三档，L6 必须四线同降，否则只有虚、没有深。

---

## 五、纹理配置（TEXTURE 维度）

### 手法 X1：背景水印符号满铺

**机制：** 把品牌/主题符号（logo、图标、关键词）以 5–10% 透明度满铺为背景层。增加"定制感"和信息暗示，又不抢焦点——远看是纹理，近看有内容。

**风格无关核心写法：**
```
background layer with repeating {symbol} watermark pattern at 5-10% opacity, 
evenly tiled like a press-wall backdrop, 
reads as texture from distance, reveals symbols on closer look, 
NEVER brighter than the subject
```

**风格化变体：**
- 科技/测评：品牌 logo 幕布 `logo press-wall, dark curtain with repeating brand marks`
- 像素风：像素网格+图标点阵 `pixel grid interspersed with tiny {icon} sprites at low opacity`
- 复古/纸感：报纸/活字底纹 `vintage letterpress type fragments, ink-stained`

---

### 手法 X2：氛围曝光区

**机制：** 画面留一块高调过曝/柔光区域（通常在主体后方），为暗部元素提供喘息空间，同时制造"光从哪来"的空间感。

**风格无关核心写法：**
```
one zone of the canvas blown out to high-key luminosity behind the subject, 
soft overexposed glow creating spatial depth, 
the rest of the canvas stays in normal/dark exposure, 
single light source logic
```

**注意：** 与账号"去除突兀白底"约束兼容——过曝区必须是**渐变光晕**而非硬边白色块。

---

## 六、色调配置（COLOR 维度）

### 手法 K1：单色调统领

**机制：** 每张高播放封面都有一个**统领色调**罩住全场（暖金逆光/米黑对比/暗金舞台/冷青梦幻）。色调统一比配色数量更重要——画面内所有元素都被同一环境光染色。

**风格无关核心写法：**
```
the entire canvas bathed in one unifying tonal cast: {tone}, 
every element tinted by this ambient light including subject and typography, 
accent colors exist only within this tonal envelope, 
cohesive single-mood color grading
```

**与配色库的关系：** `color-schemes.md` 决定"用哪几个色"，本手法决定"这些色被什么光罩着"。两者叠加使用：先选配色方案，再叠加统领色调。

---

## 七、对比与高亮配置（CONTRAST 维度）

> **来源**：2026-09-13 用户反馈（三）——"有没有类似外描边、阴影这类手法能凸显层次？""缺少对比、高亮这些细节，能不能用颜色/大小/高亮/特殊格式构造？"案例库印证：`手机AI`（荧光黄大字 + 粗黑描边 + 人物遮挡）、`实测GPT6吗`（青色"实测" vs 黄色"GPT/6" vs 巨大"6"，全部粗黑描边）、`MiniMax H3`（同一条副标题里"去油、模糊"橙 → "高动态"蓝的双色对比 + 手写毛笔字跨字渐变）、`去了一趟`（关键词装进旗帜形状）。

### 手法 E1：边缘落差链（描边 / 投影 / 发光按级配）

**机制：** 边缘处理是**最便宜、最硬的层次信号**——它直接告诉大脑"谁在上、谁在前、谁更重要"。爆款封面几乎都有同一个特征：**主角被最重的边缘手段包住**，次级元素逐级减弱到没有。注意：**描边、投影、发光是三种不同的边缘手段，各自独立分级**，不要混为一谈。

**核心规则：边缘处理是 Z5 的"第五个可调维度"，必须跟着层级走，禁止全员同款。**

| 边缘手段 | 一级（满配） | 二级 | 三级 |
|---|---|---|---|
| **投影** | 硬投影 **16–18px**、偏移明显、不虚化 | 软投影 **6–10px** | 无投影（压底栏即可） |
| **发光 / 光环** | 允许（**仅一级可拥有**） | 无 | 无 |
| **描边** | 文字**跨越亮元素处**加粗描边 **6–10px**（交叉描边）；像素风为 2–4px 硬像素边 | 无描边，靠明度对比立住 | 无 |

**三条硬约束：**
1. **投影必须有统一光源方向**，且与 L1 的 Z 轴叠压一致——谁压在谁上面，就由谁投影到对方身上；方向乱掉立刻显廉价。
2. **发光/光环全画面只允许一级拥有**。出现第二个发光元素，焦点就散了。
3. **描边是"分离"不是"装饰"**：只在元素与相邻层**明度接近**时才加；文字压到亮主体上时**必须**给描边（交叉描边，见 `separation-techniques.md` 1.2），否则字会融进主体。全画面**最多两个描边档**（厚/薄），三级无——出现第三个中间厚度就散了。

**风格无关核心写法：**
```
edge treatment is a graded hierarchy variable: 
the tier-1 element carries the heaviest shadow (hard offset drop shadow 16px, one single light direction shared by everything) and is the only element allowed a glow rim; 
tier-2 elements carry only a soft 8px shadow and no glow; 
tier-3 elements carry no shadow and no glow at all; 
outlines are used only to separate where two layers are close in brightness — any text crossing the bright subject gets a thick 8px hard outline — and only two outline weights exist in the whole frame
```

**风格化变体：**
- 像素风/数字腐蚀：`hard pixel outline in {contrast color} 2-4px, hard 1:1 offset drop shadow 16px, no soft glow`
- 拼贴/纸片：`torn paper edge lifted by a hard 14px offset shadow`
- 赛博/科技：`{accent} outer glow 15px, but only on the hero; black stroke 6px on text crossing it`
- 极简/知识：`no outline, one hard black drop shadow 10px under the hero only`

**反面清单：** ❌ 主标题、副标题、方块全都加同款黑描边（一视同仁＝没有层级）❌ 描边与底色同色系（无效描边）❌ 投影方向七零八落 ❌ 两个元素同时发光 ❌ 主标题硬上假 3D 立体字（廉价，除非内容需要）

---

### 手法 E2：局部高亮（对比 / 高亮细节）

**机制：** 整行文字同一个样式＝一堵均匀的墙，眼睛扫不出重点。**在标题里挑 1 个"变量"做高亮**（关键词 / 数字 / 疑问词），等于给眼睛一个落脚点，也让标题自带"结论感"。

**高亮变量矩阵（五类变量 × 14 个子手法，每次只挑 1 个）：**

> **来源（2026-09-13 反馈五）**："强调、高亮的手法应该不止一个吧。"——把 E2 从"4 个子手法"展开为**五类变量**。**一条标题只允许 1 个高亮变量**，即在下面五类里**只选 1 个**（同类内也只选 1 个）。E1 的**分离描边/投影不计入**高亮变量，可叠加。

| 变量 | 子手法 | 做法 | Prompt 写法 | 适用 |
|---|---|---|---|---|
| **① 色彩** | **①-A 关键词异色** | 1 个词换强调色，其余保持主色 | `only the word "{word}" is in {accent}, the rest stays {main color}` | 最通用 |
| | **①-B 字内渐变** | 一行字跨字符从色 A 渐变到色 B | `the title letters carry a left-to-right gradient from {A} to {B}` | 升级 / Before→After |
| | **①-C 异色描边** | 字内部保持主色，只把描边换成强调色 | `"{word}" keeps {main color} fill but is outlined in {accent}, 4px` | 背景杂乱、需要更硬轮廓 |
| | **①-D 镂空反白** | 字被"抠空"，透出背景或反白 | `"{word}" is knocked out of the block, the background shows through the glyphs` | 底是实色块时 |
| **② 尺度** | **②-A 极值字号** | 关键字符/数字放大到相邻字符 **≥2×**，可出血 | `the character "{X}" is scaled to 2.2x the others and breaks out of the baseline` | 数字 / 型号 / 疑问词 |
| | **②-B 倾斜错位** | 1 个词斜置/抬升/下沉，打破基线 | `only "{word}" is tilted 8 degrees off the baseline, everything else sits level` | 需要动感 / 反差 |
| | **②-C 溢出裁切** | 关键词被画布边缘切掉（T1 的局部版） | `only "{word}" is oversized and bleeds off the canvas edge` | 极简大字报 |
| **③ 材质** | **③-A 字体混排** | 1 个词换手写/毛笔/衬线，其余无衬线 | `only "{word}" switches to a brush-written face, the rest stays geometric sans` | 案例：`MiniMax H3` 毛笔字 |
| | **③-B 质感换装** | 1 个词换材质（霓虹/金属/纸张/像素） | `only "{word}" is rendered as {neon tube / brushed metal / torn paper}` | "字即物" |
| | **③-C 荧光底纹** | 关键词下刷一条荧光笔色带 | `a {accent} highlighter swipe sits behind "{word}", the glyphs stay {main color}` | 案例：`手机AI` 荧光黄 |
| **④ 图形** | **④-A 容器徽章** | 词装进色块/胶囊/旗帜/括号 | `"{word}" sits inside a {shape}, as a graphic badge` | 案例：`去了一趟` 旗帜 |
| | **④-B 图形替字** | 1 个字/词被图标或符号替换 | `the second character is replaced by a {icon} glyph of the same height` | 图标语义强时 |
| | **④-C 引线标注** | 关键词旁挂箭头/引线/圈选贴纸 | `a hand-drawn arrow and circle marks "{word}" like a marker annotation` | 口语化 / 揭秘 |
| **⑤ 空间** | **⑤-A 孤立法** | 关键词四周清空，其他元素全部退场 | `"{word}" alone sits in a large void, every other element pulls away from it` | 金句 / 悬念，与 C7 留白合用 |

**三条硬约束：**
1. **一条标题只允许 1 个高亮变量**——在 ①–⑤ 五类里**只选 1 个**（异色 / 渐变 / 异色描边 / 镂空 / 放大 / 倾斜 / 裁切 / 字体混排 / 质感换装 / 荧光底纹 / 容器 / 图形替字 / 引线 / 孤立，**十四选一**）。E1 的**分离描边/投影**不算变量，可叠加。**副标题禁止再高亮**——它已经是三级。
2. **高亮色必须是全画面最"跳"的那个色**，且**整张图只用这一处**——同一个强调色被用第二次就失效（连带把主体/气泡上的同色点缀改掉）。
3. **高亮不得破坏可读性**：异色词与底必须保持高对比；放大字符不得压住主体（与 L1 叠压规则配合）。

**风格无关核心写法：**
```
localized highlight inside the title: exactly one variable is emphasized — only the word "{word}" is rendered in {accent}, 
the rest of the title stays in {main color}; 
this accent is the single most saturated color in the whole frame and appears only once; 
no second highlight anywhere, the subtitle stays uniformly dim
```

**注意：** 与 Z5 的关系——**Z5 管"层级之间差多少"，E1/E2 管"用什么手段差"**。E2 的高亮**只作用于二级（主标题）内部**，不能把主标题里某个字高亮到超过一级（主体）——高亮是"同层内的强调"，**不是越级**。

**反面清单：** ❌ 同一个标题里又异色又放大又换字体（变量超过 1 个，"十四选一"被违反）❌ 标题里两个词都用强调色（重点＝没有重点）❌ 副标题也跟着异色/加框 ❌ 高亮色与背景相近（跳不出来）❌ 除标题外，方块/气泡上还撒同色点缀，稀释了唯一高亮 ❌ 字体混排/质感换装用在超过 1 个词上（全句花掉）

---

### 落地经验（2026-09-13 实测，gpt-image-2）

1. **写"off-white / 米白"无效，模型会直接给纯白**，导致二级元素的峰值追平一级、Z5 当场失效（灰度 200px 实测：标题 max 255 = 方块 max 255）。改成**"低饱和蓝灰 #a7aec6，不是白也不是米白，标题内不得出现纯白像素，峰值≈一级的 80%"**才压得住。凡是"降一档"的色，都要给**具体色值 + 否定词 + 相对峰值百分比**三重描述。
2. **高亮色一旦在别处复用就失效**：给标题挑的强调色，必须同时把画面其他同色点缀（能量线、眉标、边框）改成别的色，否则"唯一高亮"变成普通点缀色。
3. **验证仍用灰度 200px 分层测 max/mean**，一级 peak 必须明显高于二级 peak，且**相邻两级 mean 也要成阶梯**——peak 过了但 mean 齐平，人眼仍觉得"平"。

---

## 手法选择速查表

> **调用顺序：先过「零、闸门」Z1–Z5，再从下表挑加法手法。** 加法手法每维度 1–2 个，禁止全堆。**枚举矩阵按下表全，落笔只选 1–2 个**（构图 1 个范式 + 层次 ≥2 条通道 + 高亮 1 个变量）。

| 维度 | 手法 | 一句话 | 写入模块 |
|------|------|--------|---------|
| **闸门** | **Z1 单点暴力放大** | **只允许 1 个元素 ≥40%** | **COMPOSITION + SUBJECT** |
| **闸门** | **Z2 元素预算 ≤5** | **可辨元素数清单 ≤5** | **全局约束** |
| **闸门** | **Z3 缩略图验收** | **200px 下焦点+3字+情绪** | **Prompt 尾部收束** |
| **闸门** | **Z4 黄金位分配** | **四角只放不可读装饰** | **COMPOSITION** |
| **闸门** | **Z5 三级梯度** | **只有 1 个满配元素，相邻字号 ≥1.6×，明度成阶梯** | **TYPOGRAPHY + COLOR + SEPARATION** |
| 文案 | T1 超大出血 | 字大到被切 | TYPOGRAPHY |
| 文案 | T2 层级双路径 | 文字只当主角或背景 | TYPOGRAPHY + STYLE |
| 文案 | T3 角标信息块 | 小字收角落成型（缩略图下受 Z4 约束） | TYPOGRAPHY |
| **文案** | **T4 短文案硬预算** | **主 ≤6 字 / 副 ≤12 字** | **TYPOGRAPHY** |
| 主体 | S1 情绪姿势 | 主体带戏 | SUBJECT |
| 主体 | S2 瞬间峰值帧 | 定格最高张力 | SUBJECT |
| 主体 | S3 轮廓光剥离 | 边缘光剥出主体 | SUBJECT + SEPARATION |
| **主体** | **S4 情绪锚点降级链** | **脸→符号→数字→拟人，必中其一** | **SUBJECT** |
| 构图 | C1 出血裁切 | 元素伸出框外 | COMPOSITION |
| 构图 | C2 文字即骨架 | 字墙 vs 主体对抗 | COMPOSITION |
| **构图** | **C3 双区对比结构** | **Before→After，变量唯一** | **COMPOSITION** |
| **构图** | **C4 黄金位分配** | **中央可读 / 四角不可读** | **COMPOSITION** |
| **构图** | **C5 视线路径驱动** | **一条路径串起 2–4 个停靠点（Z/F/S/对角/放射/引导线）** | **COMPOSITION** |
| **构图** | **C6 块面分割范式** | **全宽/分栏/三分/上下/穿插/叠压，块面 ≤3** | **COMPOSITION** |
| **构图** | **C7 空间修辞** | **留白 / 框架 / 螺旋 / 背景延展** | **COMPOSITION** |
| **构图** | **C8 视觉配重范式** | **居中 / 上重下轻 / 下重上轻 / 重点突出** | **COMPOSITION** |
| 层次 | L1 三明治三选一 | 字压人/人压字/前后夹 | SEPARATION |
| 层次 | L2 焦点层级链 | 三级锐度定死 | SEPARATION |
| **层次** | **L3 光影分层** | **主光只打一级，其余吃环境光/落暗部** | **SEPARATION + COLOR** |
| **层次** | **L4 饱和分层** | **一级最饱和或唯一有彩，逐级去色** | **COLOR** |
| **层次** | **L5 材质分层** | **一级最精、二级平涂、背景最糙** | **TEXTURE + SUBJECT** |
| **层次** | **L6 空气透视分层** | **近大远小 + 近实远虚 + 近暖远冷，四线同降** | **COMPOSITION + COLOR** |
| 纹理 | X1 水印满铺 | 远看纹理近看符号 | TEXTURE |
| 纹理 | X2 氛围曝光区 | 一块高调柔光区 | TEXTURE + COLOR |
| 色调 | K1 单色调统领 | 一种光罩全场 | COLOR |
| **对比高亮** | **E1 边缘落差链** | **描边/投影/发光按级配，只一级满配** | **SEPARATION + TYPOGRAPHY** |
| **对比高亮** | **E2 局部高亮** | **标题内只 1 个高亮变量（五类变量 · 十四选一）** | **TYPOGRAPHY** |

---

## 与其他 references 的分工

```
cover-craft-playbook.md（本库）  = 手法机制层 —— 为什么有效 + 怎么写 + 多风格变体
templates.md                     = 版式骨架层 —— 画面怎么分（A–E 模板 + 方向变体）
color-schemes.md                 = 配色素材层 —— 用哪几个色
typography-guide.md              = 字体素材层 —— 用什么字型
texture-effects.md               = 肌理素材层 —— 表面质感选项
separation-techniques.md         = 分离技术层 —— 描边/对比/虚实/遮挡的底层写法
design-principles.md             = 原则校验层 —— 8 大原则自查
```

**调用顺序：** Phase 2 匹配时，先按内容类型过一遍本库挑手法组合（每维度 1–2 个），再落到 templates/素材库填充具体实现。
