# 字体风格库

## 字体类型与适用场景

### 1. 衬线字体 (Serif)

**特征：**
- 笔画末端有装饰性线条（衬线）
- 精致、优雅、复古、文艺
- 传统、可信赖、高品质感

**适用场景：**
- 文化艺术类内容
- 女性、美食、生活方式
- 正式场合、教育、书籍
- 需要传达历史感、经典感

**Prompt关键词：**
```
elegant serif font, refined typography, classic letterforms, sophisticated text
```

**变体：**
- 细衬线：`thin serif, delicate strokes`
- 粗衬线：`bold serif, strong contrast`
- 现代衬线：`modern serif, geometric serifs`

---

### 2. 非衬线字体 (Sans-serif)

**特征：**
- 笔画末端无装饰，简洁干净
- 醒目、突出、现代、力量
- 清晰、直接、易读

**适用场景：**
- 科技、产品、教程
- 新闻、资讯、数据
- 需要现代感、专业感
- 屏幕显示优先

**Prompt关键词：**
```
bold sans-serif font, clean modern typography, geometric letterforms, strong impactful text
```

**变体：**
- 圆角非衬线：`rounded sans-serif, soft friendly`
- 窄体非衬线：`condensed sans-serif, compact`
- 超粗非衬线：`extra bold sans-serif, heavy weight`

---

### 3. 圆体字 (Rounded)

**特征：**
- 笔画末端圆润
- 灵动、柔美、友好、亲和
- 年轻、活泼、轻松

**适用场景：**
- 儿童、亲子类内容
- 美食、甜品、可爱风
- 生活方式、轻松话题
- 需要降低严肃感

**Prompt关键词：**
```
rounded font, soft typography, friendly letterforms, playful rounded edges
```

---

### 4. 手写体/书法体 (Script/Handwritten)

**特征：**
- 模拟手写或书法笔触
- 个性化、艺术感、温度
- 独特、有情感

**适用场景：**
- 个人品牌、Vlog
- 情感类、日记类
- 创意、艺术类内容
- 需要人文气息

**Prompt关键词：**
```
handwritten script font, calligraphic text, brush stroke typography, personal handwritten style
```

**变体：**
- 毛笔书法：`Chinese calligraphy, brush strokes`
- 手写英文：`casual handwriting, marker style`
- 艺术字体：`decorative script, ornamental`

---

### 5. 装饰字体 (Display/Decorative)

**特征：**
- 高度风格化，设计感强
- 独特、吸睛、有主题性
- 不适合大段文字

**适用场景：**
- 标题、Logo
- 特定主题（复古、未来、节日）
- 需要强烈视觉冲击

**Prompt关键词：**
```
decorative display font, stylized typography, unique custom lettering, thematic text design
```

---

## 字体组合原则

### 黄金法则

**"一个画面不超过三种字体"**

推荐组合：
1. **单一字体变体**：一种字体的不同粗细/大小
2. **两种字体搭配**：
   - 衬线 + 非衬线（经典组合）
   - 粗体 + 细体（对比组合）
   - 正体 + 手写体（层次组合）

### 字体层级构建

```
主标题：最大字号，最粗或最醒目字体
  ↓
副标题：中等字号，同系列较细字重或辅助字体
  ↓
辅助文字：最小字号，简洁易读字体
```

### 二级文案规则（副标题/二级文案必须"显眼但不抢主标题"）

> 反复踩坑点：二级文案要么太小看不清、要么喧宾夺主盖过主标题。用以下规则保证"清晰可辨 + 层级正确"。

- **显眼（确保看得清）**：
  - 二级文案字号要够大，**不因"比主标题小"而小到糊**——至少占主标题的 60-70% 字号，保证小缩略图下也清晰。
  - 若画面底纹复杂，二级文案必须配**半透明深色衬底**（dark translucent panel），与背景分离。
  - 用高对比亮色（如纸白），避免与主体同色混叠。
- **不抢主体（保持层级）**：
  - 一级主标题保持**唯一最亮/最大焦点**（全画面单焦点）。
  - 二级文案**不加 glitch/RGB 分离等故障特效**——故障特效只允许出现在一级标题（制造注意力集中）。
  - 用**位置**区分：二级文案放画面下方/边角优势位，一级放中央高位；或用"一级在后被主体遮挡、二级在最前"的深度分层。
  - 字号、色彩饱和度都**故意低于一级**，保证视觉优先级明确。
- **Prompt 落地**：上述约束必须写进 TYPOGRAPHY 模块（明确主/副字号关系、衬底、glitch 归属、位置、深度分层），不能只在脑子里想，要让生图模型收到明确指令。

> 设计依据：2026-08-26 用户反馈"二级文案不明显、又小、又没合适位置"——需要显式规则而非自然生成。

---

## 字体与主题匹配表

| 主题类型 | 推荐字体 | 理由 |
|---------|---------|------|
| 科技/AI | 非衬线、粗体 | 现代、力量、清晰 |
| 财经/商业 | 衬线、非衬线均可 | 专业、可信 |
| 美食/生活 | 圆体、手写体 | 温暖、亲和 |
| 文化/艺术 | 衬线、书法体 | 优雅、深度 |
| 儿童/教育 | 圆体、粗非衬线 | 友好、易读 |
| 时尚/美妆 | 细衬线、装饰体 | 精致、高级 |
| 运动/健身 | 粗非衬线、斜体 | 力量、动感 |
| 复古/怀旧 | 衬线、装饰体 | 历史感、经典 |

---

## 文字设计技巧Prompt关键词

### 大小对比
```
extreme size contrast, large dominant title with small supporting text
huge bold main text with tiny fine print
```

### 粗细对比
```
strong weight contrast, bold headlines with light body text
heavy typography vs delicate lettering
```

### 镂空/描边效果
```
hollow text, outlined typography, stroke-only letters
see-through text with background visible through letterforms
```

### 立体/阴影效果
```
3D text, dimensional typography, drop shadow on text
embossed lettering, raised text effect
```

### 渐变填充
```
gradient text, color transition within letters
metallic gradient typography, chrome effect text
```

### 破损/复古效果
```
distressed text, vintage worn typography
stamped letterpress effect, ink bleed texture
```

### 发光/霓虹效果
```
neon text, glowing typography, light emission from letters
halo effect, illuminated signage style
```

---

## 中文排版特殊考虑

### 中文标题设计

**大字设计：**
- 中文笔画复杂，超大字号时注意笔画清晰度
- 可适当加粗或描边增强识别
- 避免过于纤细的字体作为大标题

**竖排文字：**
```
vertical Chinese text, top-to-bottom reading direction
traditional Chinese column layout
```

**横排文字：**
- 现代标准，易读性强
- 适合大多数场景

### 中英混排

**原则：**
- 中文字体决定整体气质
- 英文字体作为辅助，不抢戏
- 字号：英文通常比中文小一号

**Prompt示例：**
```
Chinese characters in bold sans-serif, English subtitle in clean geometric sans-serif
```

---

## 字体Prompt生成公式

```
[字体类型] + [字重/粗细] + [特殊效果] + [排版方式]

例：
bold sans-serif font + heavy weight + slight 3D shadow + centered alignment
```
