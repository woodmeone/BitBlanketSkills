# 版式模板库

> 每个模板包含：**共享层**（STYLE / SUBJECT / COLOR / TEXTURE / SEPARATION，跨比例复用）+ **[4:3 变体]** + **[3:4 变体]**（COMPOSITION / TYPOGRAPHY，各自独立）。
> 使用时，根据 Phase 1 确认的 ratio 锁定对应变体，共享层始终不变。
> 模板定义的是"骨架"，`{}` 占位符在生成时替换；具体手法（出血/三明治/角标等）从 `cover-craft-playbook.md` 按风格套用后写入对应模块。

---

## 内置模板

### 模板A：左图右文 / 上图下文（知识/解说/情感故事类）

**适用场景：**
- 知识科普、教程讲解、情感故事
- 需要展示具体图像/产品/人物
- 信息密度较高的内容

---

#### A-共享层（所有比例复用）

**STYLE：**
```
{art_style} — declare one unified rendering language for the whole canvas 
(e.g. soft watercolor illustration / 16-bit pixel art / editorial photo collage / 
flat vector). Consistent lighting direction, one line-weight family, 
no style mixing between layers. The style governs how SUBJECT is rendered 
but does not dictate layout, colors, or text content.
```

**SUBJECT：**
```
[主体描述] positioned prominently, gentle expression, soft natural lighting, 
simple timeless clothing. The edge facing the text zone has a rough torn paper 
collage effect — irregular jagged tear line with visible paper fiber texture, 
drop shadow beneath the torn edge for depth separation.
```

**COLOR：**
```
[背景色] gradient background, [文字色] typography, [点缀色] accents for shadows 
and depth markers. Low saturation, high textural richness.
```

**TEXTURE：**
```
[材质纹理] overlay across full canvas with depth-aware opacity — strongest in 
background, subtler over subject, absent from foreground text. Subtle film grain 
at 5-8% opacity. Aged paper / vintage print aesthetic.
```

**SEPARATION：**
```
Three-layer separation: subject torn-paper edge with drop shadow isolates it from 
the background; foreground text uses high luminosity contrast against background 
for legibility; at the text-subject intersection, the overlap is a hard clipping 
boundary (no soft blend) so neither layer bleeds into the other.
```

---

#### A-[4:3 变体] 左图右文

**COMPOSITION：**
```
4:3 aspect ratio, split left-right layout. Left side occupies approximately 
40% of canvas width housing the main subject. Right 60% is the typography zone 
with ample negative space, strict left-alignment on a consistent baseline grid.
The dividing line is intentionally broken — the subject's right edge has a rough 
torn paper collage edge (vertical jagged tear) that casts a drop shadow onto the 
background. Three depth planes: textured background, crisp midground subject, 
razor-sharp foreground text.
```

**TYPOGRAPHY：**
```
Main title "{main_title}" in large bold Chinese serif calligraphic font, 
approximately 16-18% of canvas height, cream off-white color. The title spatially 
weaves through the figure — some characters pass behind the shoulder/hair 
(partially occluded), others float in front casting soft drop shadows onto the 
clothing. A thin horizontal divider line below the title area, then subtitle 
"{subtitle}" in a smaller cleaner serif font (approximately 40% of main title 
size), strictly left-aligned within the right 60% zone. The subtitle is a stable 
anchor that does NOT participate in the figure-text interweaving.
```

**3:4 转 4:3 注意事项：**
- 撕裂边缘从水平线改为垂直线（右缘）
- 文字对齐从左对齐（竖版中心感）改为居中或左对齐风格
- 与模板 E 的图文穿插技术兼容（拼贴 + 投影 + 部分遮挡）

---

#### A-[3:4 变体] 上图下文

**COMPOSITION：**
```
3:4 aspect ratio, split top-bottom layout. Top section occupies approximately 
45-50% of canvas height housing the main subject. Bottom 50-55% is the typography 
zone with generous vertical negative space, center-aligned on the vertical axis.
The dividing line is intentionally broken — the subject's bottom edge has a rough 
torn paper collage edge (horizontal jagged tear) that casts a drop shadow downward 
onto the background. Three depth planes: textured background, crisp midground 
subject, razor-sharp foreground text.
```

**TYPOGRAPHY：**
```
Main title "{main_title}" in large bold Chinese serif calligraphic font, 
approximately 14-16% of canvas height, cream off-white color. The title straddles 
the torn edge — some characters sit above the tear line (behind the subject's 
lower body, partially occluded), while others fall below the tear line floating 
in front of the background zone with soft drop shadows. This creates a ribbon-like 
spatial weave where text crosses the tear boundary at multiple Z-depths. 
Below the title area, a thin horizontal divider line, then subtitle "{subtitle}" 
in a smaller cleaner serif font (approximately 40% of main title size), 
center-aligned, sitting in the lower 30% of the bottom zone. The subtitle is a 
stable anchor that does NOT participate in the interweaving.
```

**3:4 专属注意事项：**
- 主体占据上半部（横向撕裂线），非左侧
- 文字居中排布（竖窄幅左对齐看起来会歪）
- 图文穿插不再是横穿过，而是纵跨撕裂线

---

### 模板B：上图下文 / 满版竖排（Vlog/情感类）

**适用场景：**
- Vlog封面、生活记录
- 情感类、故事类内容
- 需要营造氛围感的主题

---

#### B-共享层（所有比例复用）

同模板A共享层结构，`{}` 占位替换具体内容。

---

#### B-[4:3 变体] 上图下文

**COMPOSITION：**
```
4:3 aspect ratio, top-bottom split. Image occupies top 65-70% of the frame. 
Bottom 30-35% is a gradient color bar or semi-transparent overlay containing all 
typography. Top-heavy visual rhythm, cinematic atmosphere.
```

**TYPOGRAPHY：**
```
Large bold {text_color} Chinese text "{main_title}" centered in the bottom color 
bar, with smaller subtitle "{subtitle}" below. Clean typography, strong visual 
hierarchy. Main title occupies 60-70% of the bar height.
```

---

#### B-[3:4 变体] 满版竖排

**COMPOSITION：**
```
3:4 aspect ratio, full-bleed subject image. A gradient overlay from bottom 
(40-50% opacity) fading to transparent at top 40%. All typography sits in the 
bottom 35% of the frame, center-aligned.
```

**TYPOGRAPHY：**
```
Large bold {text_color} Chinese text "{main_title}" centered in bottom zone, 
with smaller subtitle "{subtitle}" below. The gradient overlay ensures text 
legibility against the full-bleed image. Cinematic atmosphere, clean typography.
```

---

### 模板C：大字报型（观点/金句类）

**适用场景：**
- 观点评论、金句分享
- 文字本身成为视觉焦点
- 简洁有力的表达

---

#### C-共享层（所有比例复用）

同模板A共享层结构。

---

#### C-[4:3 变体] 大字报横

**COMPOSITION：**
```
4:3 aspect ratio, centered typographic composition. Ample negative space on all 
sides. Background is a solid color with subtle texture. No subject image — the 
text itself is the composition.
```

**TYPOGRAPHY：**
```
Extremely large bold Chinese characters "{main_title}" in {text_color} centered 
horizontally and vertically, occupying 50-60% of canvas width. Smaller Chinese 
text "{subtitle}" positioned below the main title. High contrast typographic 
poster style, modern graphic design, minimalist.
```

---

#### C-[3:4 变体] 大字报竖

**COMPOSITION：**
```
3:4 aspect ratio, centered typographic composition. Generous negative space above 
and below. Background is a solid color with subtle texture.
```

**TYPOGRAPHY：**
```
Extremely large bold Chinese characters "{main_title}" in {text_color} centered, 
occupying 40-50% of canvas width (adjusted for taller canvas), with generous 
vertical spacing. Smaller Chinese text "{subtitle}" below. Main title may use 
two-line stacking if character count exceeds 6 characters. High contrast 
typographic poster style.
```

---

### 模板D：电影感型（故事/影视类）

**适用场景：**
- 影视剪辑、故事叙述
- 需要电影海报质感
- 强调氛围和情绪

---

#### D-共享层（所有比例复用）

同模板A共享层结构。

---

#### D-[4:3 变体] 电影感横

**COMPOSITION：**
```
4:3 aspect ratio, full-bleed background image. A semi-transparent dark overlay 
box positioned in the left-center or bottom-left corner (golden ratio point) 
containing all typography. Movie poster aesthetic.
```

**TYPOGRAPHY：**
```
Bold {text_color} Chinese text "{main_title}" inside the overlay box, with 
smaller subtitle "{subtitle}" below. Additional credit-line style small text 
at the very bottom of the overlay. Atmospheric, professional cinematography style.
```

---

#### D-[3:4 变体] 电影感竖

**COMPOSITION：**
```
3:4 aspect ratio, full-bleed background image. A semi-transparent dark overlay 
box positioned in the bottom 25-30% of the frame, spanning 80-90% of canvas 
width. Movie poster vertical format aesthetic.
```

**TYPOGRAPHY：**
```
Bold {text_color} Chinese text "{main_title}" inside the overlay box, with 
smaller subtitle "{subtitle}" below. Credit-line small text beneath. Main title 
may stack across 2 lines in vertical format for longer titles.
```

---

## 用户自定义模板

> 用户在使用过程中沉淀的个性化模板，命名规则：E, F, G... 依次递增

### 模板E：暗色科技拼贴风（IT/科技/游戏类）

**来源：** 用户实际使用验证的Prompt框架，适用于IT/科技类高点击率封面

**适用场景：**
- IT/科技类视频封面
- 游戏/娱乐类内容
- 需要高冲击力、高对比度的场景

**设计要点：**
- 三明治层次：副标题(前) → 角色(中) → 主标题(后被遮挡)
- 拼贴风格：角色抠图隔离（描边+投影），制造割裂感
- 高对比：全画面只有一个最亮视觉焦点
- 破框感：角色略微裁出画面边缘

**主题色选择：**
| 内容类型 | 主题色 | 色值 |
|---------|--------|------|
| 工具/效率类 | 电光蓝 或 橙色 | `#00CFFF` / `#FF8C00` |
| 游戏/娱乐类 | 品红 或 紫色 | `#FF4DCF` |
| 安全/隐私类 | 警示红 或 暗紫霓虹 | - |
| 创作/设计类 | 渐变彩色 或 金色 | - |

---

#### E-共享层（所有比例复用）

**STYLE：**
```
dark tech collage — cut-out paper aesthetic with digital screen rendering. 
One unified rendering language: hard-edged elements, no painterly blending, 
consistent top-down artificial lighting, high-contrast graphic treatment 
across subject and typography.
```

**SUBJECT：**
```
Main character positioned prominently, occupying 65-80% of frame height, 
{character_description} with emotional expression, cut-out isolation style with 
white or {theme_color} outline stroke 6-10px, drop shadow at 135 degrees 
distance 15px blur 15-20px opacity 70-75%, feet slightly cropped beyond frame 
bottom for break-the-frame effect.
```

**COLOR：**
```
near-black #0D0D0D background + 1 theme accent color + white/contrast secondary 
color. Only one brightest visual focal point in the entire frame.
```

**TEXTURE：**
```
Subtle light gray grid lines at 10-15% opacity, radial gradient glow in 
{theme_color} at 20-35% opacity, extremely subtle film grain noise at 5-8% 
opacity. Digital screen aesthetic.
```

**SEPARATION：**
```
Sandwich depth stack with explicit Z-order: background → main title (behind) → 
character → subtitle/labels (in front). Subject↔background separated by 
outline stroke + hard drop shadow (cut-out isolation); text↔background separated 
by luminosity contrast (only one brightest focal point); text↔subject separated 
by overlap intersection — front elements cast hard shadows onto elements behind 
them, no soft blending at intersections.
```

---

#### E-[4:3 变体] 暗色科技横

**COMPOSITION：**
```
4:3 aspect ratio, dark tech collage style. Left side: main character in cut-out 
isolation. Right side: main title partially occluded by character body. 
Subtitle/labels floating in top-right corner above the character. Five-layer 
depth: background grid+glow → main title (partially behind) → character → 
subtitle (fully in front).
```

**TYPOGRAPHY：**
```
Main title positioned on right side, ultra-bold heavy Chinese text "{main_title}" 
in bright theme color, thick dark outline stroke + hard drop shadow. Character 
body partially occludes the title but does not cover key characters. Subtitle 
at top-right corner, floating above character, bold white text with colored 
outer glow. Optional capsule tag near character: semi-transparent dark 
background + colored border.
```

**文字公式：**
- 主标题（欲望/痛点，≤8字）：`[场景限定] + [欲望结果]`
- 副标题（方案+卖点，≤1行）：`[工具名] + [核心标签1] · [核心标签2]`
- 辅助标签（背书词）：`免费/开源/小白/一键/两天搞定`

---

#### E-[3:4 变体] 暗色科技竖

**COMPOSITION：**
```
3:4 aspect ratio, dark tech collage style. Full-height character occupying 
center 60-70% of canvas width in cut-out isolation. Main title positioned in 
lower section crossing behind the character's lower body. Subtitle/labels 
floating in top-left or top-right. Five-layer depth adapted for vertical: 
background → main title (behind at bottom) → character (center) → subtitle 
(top overlay).
```

**TYPOGRAPHY：**
```
Main title "{main_title}" in ultra-bold heavy Chinese text, bright theme color 
with dark outline stroke + hard drop shadow, positioned in lower 30% of canvas, 
partially occluded by the character's lower body. Subtitle at top corner 
floating above character, bold white text with colored outer glow. Vertical 
format may split long titles across 2 lines.
```

---

## 模板选择指南

| 内容类型 | 推荐模板 | 理由 |
|---------|---------|------|
| IT/科技 | **E** | 三明治层次+拼贴风，高冲击力 |
| 游戏/娱乐 | **E** | 暗色科技风，适合游戏主题 |
| 知识科普 | A或C | 需要清晰传递信息 |
| 观点评论 | C | 文字即焦点，观点突出 |
| Vlog生活 | B | 氛围感优先 |
| 产品展示 | A | 产品图+文字说明 |
| 情感故事 | **A** 或 D | A适合图文穿插表达，D适合氛围渲染 |
| 影视剪辑 | D | 电影海报质感 |
| 教程讲解 | A | 步骤图+文字说明 |
| 金句分享 | C | 文字最大化 |

---

## 模板组合建议

**图文穿插组合（情感/故事）：**
- 模板A + 暖棕/复古配色 + 衬线手写体 + halftone半调

**高冲击力组合（科技/游戏）：**
- 模板E + 暗夜科技/赛博朋克配色 + Gothic Bold

**高对比组合（吸引眼球）：**
- 模板C + 暗夜金/纯净白 + 粗体无衬线

**温暖亲和组合（生活类）：**
- 模板B + 暖阳橙/樱花粉 + 圆体字

**专业可信组合（知识类）：**
- 模板A + 暗夜金/森林绿 + 无衬线体

**神秘氛围组合（故事类）：**
- 模板D + 深蓝渐变 + 衬线体

---

## Prompt 结构最佳实践

> 无论使用哪个模板，生成的 Prompt 必须遵循以下 7 模块结构。模板定义的是"每个模块写什么内容"，7 模块公式定义的是"怎么写"。

### 7 模块 Prompt 骨架

```
COMPOSITION:  [版式骨架]   → 布局怎么分、怎么对齐、多少留白、出血裁切
STYLE:        [画风层]     → 统一渲染语言、画法、光影逻辑（风格唯一挂载点）
SUBJECT:      [主体层]     → 人物/物体特征、情绪姿势、瞬间峰值
TYPOGRAPHY:   [文字层]     → 标题/副标题字体/字号/颜色/位置、图文穿插、角标块
COLOR:        [色彩层]     → 背景色调、文字色、点缀色、统领色调
TEXTURE:      [肌理层]     → 半调/噪点/纸张/水印满铺、各层透明度差异
SEPARATION:   [分离层]     → 三层分离手法、Z轴三明治结构、焦点层级链
```

### 方向变体使用规则

```
Phase 1 确认 ratio=4:3 → 取模板的 [4:3 变体] COMPOSITION + TYPOGRAPHY
Phase 1 确认 ratio=3:4 → 取模板的 [3:4 变体] COMPOSITION + TYPOGRAPHY
共享层 (STYLE + SUBJECT + COLOR + TEXTURE + SEPARATION) → 始终不变
```

### 模块编写铁律

- 每个模块只描述自己维度的事，不跨越到其他模块
- STYLE 段声明画风，不写构图/色值/文字内容
- SUBJECT 段不包含文字信息，TYPOGRAPHY 段不描述人物外貌
- COMPOSITION 只描述骨架（在哪里 / 怎么分 / 多少留白），不描述放什么
- 图文交叉效果写进 TYPOGRAPHY 段；Z 轴叠压关系写进 SEPARATION 段
- 每段之间用空行分隔，模块标题大写

### 模块之间的交叉信息如何归属

| 交叉场景 | 归属模块 | 理由 |
|---------|---------|------|
| 半调网点在人物脸上透明度降低 | TEXTURE | 是肌理维度的事 |
| 人物撕边投影到背景上 | COMPOSITION | 是空间关系的描述 |
| 文字投影到人物衣服上 | TYPOGRAPHY | 是文字与主体的交互 |
| 文字颜色为米白 | TYPOGRAPHY 或 COLOR | 两边都写一句，保持一致 |
| 人物构图占比/裁切方向 | COMPOSITION | 是布局决策，非人物自身属性 |
| 主体用油画还是像素画法渲染 | STYLE | 是画风维度的事 |
| 背景 RGB 残影退后 / 三明治 Z 序 | SEPARATION | 是层次分离维度的事 |
