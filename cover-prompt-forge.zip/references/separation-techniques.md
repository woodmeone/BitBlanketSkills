# 封面设计区分手法库

> 在封面设计中，主体、文案、背景三者需要清晰的视觉区分，避免元素混淆。本文档提供 5 种核心区分手法及其 Prompt 关键词。

---

## 核心原则

**三层分离目标：**
- **主体与背景区分** — 让主体从背景中"跳出来"
- **文案与背景区分** — 保证文字可读性
- **文案与主体区分** — 避免文字与主体粘连

**优先级：** 文案可读性 > 主体识别度 > 背景氛围

---

## 1. 描边类（Stroke / Outline / Glow）

### 手法描述

通过在元素边缘添加描边、外发光或粗边框，强制分离元素与背景/其他元素。

### 变体类型

#### 1.1 外发光（Outer Glow）

**效果：** 元素边缘向外发散柔和光晕

**适用场景：**
- 暗色背景 + 亮色元素
- 科技、赛博朋克风格
- 需要柔和分离效果

**Prompt 关键词：**
```
outer glow, edge glow, soft light emission
neon glow effect, luminous outline
glowing edges with {color} spread {N}px
```

**示例：**
```
[主体与背景] character with neon magenta #FF4DCF outer glow 15px spread
[文案与背景] title with white outer glow 20px against dark background
[文案与主体] text has cyan glow, character has magenta glow, distinct at intersection
```

---

#### 1.2 纯色粗边（Solid Stroke）

**效果：** 元素边缘添加实色描边，硬边缘分离

**适用场景：**
- 高对比度设计
- 像素风、扁平风格
- 需要强烈分离效果

**Prompt 关键词：**
```
bold stroke, thick outline, solid border
hard edge stroke in {color} {N}px
pixel outline, crisp border
black stroke, white stroke, colored outline
```

**常用描边色：**
- 黑色描边：`black stroke, dark outline` — 亮色元素用
- 白色描边：`white stroke, light outline` — 暗色元素用
- 主题色描边：`{theme_color} stroke` — 品牌一致性

**示例：**
```
[主体与背景] character with bold black outline 8px, sharp separation from background
[文案与背景] title with white stroke 6px on dark background, high legibility
[文案与主体] double stroke at intersection: white on text side, black on character side
```

---

#### 1.3 描边 + 发光组合

**效果：** 内层实色描边 + 外层发光，双重分离

**Prompt 关键词：**
```
stroke with outer glow, outlined and glowing
bold stroke {N}px + glow spread {M}px
double edge treatment: inner stroke + outer glow
```

**示例：**
```
title with black stroke 6px inner + magenta glow 15px outer, brutal text isolation
```

---

### 描边类完整示例

```
[主体与背景区分] character with neon magenta #FF4DCF pixel outline 12px + cyan #00CFFF hard drop shadow 18px, isolating figure from background.

[文案与背景区分] title with bold black outer stroke 8px + white inner glow, text sharply separated from dark background.

[文案与主体区分] title characters crossing character have double stroke (white on text side, magenta on character side) at intersection edge.
```

---

## 2. 色彩对比/压色类（Color Contrast / Color Burn）

### 手法描述

利用色彩对比（色相、明度、饱和度差异）或压色混合模式，让元素在色彩层面自然分离。

### 变体类型

#### 2.1 互补色对比（Complementary Contrast）

**效果：** 色轮 180° 对立色，最强对比

**适用场景：**
- 需要强烈视觉冲击
- CTA 按钮、重点文案
- 高点击率设计

**Prompt 关键词：**
```
complementary colors, 180° color opposition
{color1} against {color2} background
maximum color clash, strong contrast
color wheel opposite
```

**常用互补组合：**
| 主色 | 互补色 | 效果 |
|------|--------|------|
| 蓝 #0066FF | 橙 #FF6600 | 科技感 |
| 红 #FF0000 | 绿 #00FF00 | 强冲击 |
| 黄 #FFFF00 | 紫 #9900FF | 活力感 |
| 青 #00FFFF | 品红 #FF00FF | 赛博朋克 |

**示例：**
```
[主体与背景] character in mid-tone grays with neon magenta accents against deep purple background
[文案与背景] title in burning orange #FF8C00, complementary 180° to background purple
[文案与主体] subtitle in cyan #00CFFF, contrasting both orange title and gray character
```

---

#### 2.2 明度对比（Luminosity Contrast）

**效果：** 亮暗差异，不考虑色相

**适用场景：**
- 单色/类似色设计
- 保证可读性
- 极简风格

**Prompt 关键词：**
```
high luminosity contrast, brightness difference
light element on dark background
dark element on light background
{luminosity_diff}% brightness gap
```

**示例：**
```
[主体与背景] character at 50% luminosity, background at 10%, 40% difference
[文案与背景] white text #FFFFFF on dark purple #0D0A14, 90% luminosity contrast
[文案与主体] text brighter than character, clear tonal separation
```

---

#### 2.3 压色混合（Color Burn Blend）

**效果：** 混合模式增强对比，元素交界处加深

**适用场景：**
- 叠加效果
- 增加层次感
- 复杂背景

**Prompt 关键词：**
```
color burn blend mode, color burn overlay
multiply blend, overlay blend
blend mode separation
burned edges at intersection
```

**示例：**
```
[文案与主体] title with color burn blend mode on character overlap zone, natural darkening at intersection
```

---

### 色彩对比类完整示例

```
[主体与背景区分] character in mid-tone grays with neon magenta accents against deep purple #0D0A14 background, 50% luminosity difference.

[文案与背景区分] title in burning orange #FF8C00, complementary 180° to background purple, maximum color clash.

[文案与主体区分] subtitle in cyan #00CFFF, contrasting both orange title and gray character, each layer has distinct color family.
```

---

## 3. 虚实/模糊类（Focus / Blur / Depth of Field）

### 手法描述

利用清晰度差异（锐利 vs 模糊），让元素在视觉焦点层面分离。

### 变体类型

#### 3.1 高斯模糊背景（Gaussian Blur Background）

**效果：** 背景模糊，前景元素锐利

**适用场景：**
- 复杂纹理背景
- 突出主体/文案
- 模拟摄影景深

**Prompt 关键词：**
```
blurred background, gaussian blur {N}px radius
background bokeh, soft background
sharp foreground, crisp subject
depth of field effect, shallow DOF
```

**示例：**
```
[主体与背景] background texture layers gaussian blurred 8px, character razor-sharp
[文案与背景] title in sharp focus plane, background bokeh creates text isolation
```

---

#### 3.2 焦点层次（Focus Hierarchy）

**效果：** 不同元素不同清晰度，建立焦点层级

**适用场景：**
- 多层元素设计
- 引导视觉顺序
- 模拟相机对焦

**Prompt 关键词：**
```
selective focus, focal plane hierarchy
{element1} sharp 0px blur, {element2} soft {N}px blur
focus stack, depth layers
sharp vs soft contrast
```

**焦点层级示例：**
```
文案 0px blur（最锐利）→ 主体 2px blur（次锐利）→ 背景 8px blur（最柔和）
```

**示例：**
```
[文案与主体] character at mid-focus (subtle 2px blur), title razor-sharp (0px blur)
[整体] focus hierarchy: text > character > background
```

---

#### 3.3 运动模糊（Motion Blur）

**效果：** 方向性模糊，营造动感

**适用场景：**
- 动态主题
- 游戏、运动
- 速度感

**Prompt 关键词：**
```
motion blur, directional blur
velocity effect, speed lines
static subject vs blurred background
```

---

### 虚实/模糊类完整示例

```
[主体与背景区分] background texture layers gaussian blurred 8px, character razor-sharp with zero blur, depth of field separation.

[文案与背景区分] title and subtitle in sharp focus plane, background bokeh creates automatic text isolation.

[文案与主体区分] character at mid-focus (subtle 2px blur), title razor-sharp (0px blur), focus hierarchy: text > character > background.
```

---

## 4. 形状/蒙版遮挡类（Shape / Mask / Clipping）

### 手法描述

利用几何形状边界或蒙版裁切，强制分离元素区域。

### 变体类型

#### 4.1 几何容器（Geometric Container）

**效果：** 用形状框住元素，建立视觉边界

**适用场景：**
- 复杂背景上的文案
- 需要干净区域
- 结构化设计

**Prompt 关键词：**
```
geometric container, shape boundary
text inside {shape} (rectangle/circle/angled box)
visual buffer zone
clean contained area
```

**常用形状：**
- 矩形：`rectangle container, rectangular boundary`
- 圆形：`circular container, round boundary`
- 斜切矩形：`angled rectangle, slanted box`
- 不规则：`organic shape, custom mask`

**示例：**
```
[文案与背景] large angled rectangle geometric container behind title zone, shape acts as visual buffer separating text from complex background texture
```

---

#### 4.2 硬切边（Hard Clipping Edge）

**效果：** 元素边缘硬裁切，无过渡

**适用场景：**
- 像素风、扁平风
- 拼贴艺术
- 强烈分离

**Prompt 关键词：**
```
hard clipping edge, sharp cut-out
no soft blend, clean isolation
clipped silhouette, hard mask
pixel-perfect edge
```

**示例：**
```
[主体与背景] character silhouette has hard clipping edge, no soft blend with background, clean cut-out isolation
```

---

#### 4.3 蒙版裁切（Clipping Mask）

**效果：** 用一个形状裁切另一个元素

**适用场景：**
- 图文穿插
- 创意效果
- 区域限制

**Prompt 关键词：**
```
clipping mask, masked by {shape}
clipped at intersection
shape-defined boundary
```

**示例：**
```
[文案与主体] title characters have rectangular bounding box, character body clipped at intersection, hard geometric boundary between text zone and character zone
```

---

### 形状/蒙版遮挡类完整示例

```
[主体与背景区分] character silhouette has hard clipping edge, no soft blend with background, clean cut-out isolation.

[文案与背景区分] large angled rectangle geometric container behind title zone, shape acts as visual buffer separating text from complex background texture.

[文案与主体区分] title characters have rectangular bounding box, character body clipped at intersection, hard geometric boundary between text zone and character zone.
```

---

## 5. 叠加与层次类（Layering / Stacking / Blend Modes）

### 手法描述

明确建立 Z 轴深度层次，通过前后叠加关系分离元素。

### 变体类型

#### 5.1 Z 轴层次（Z-Order Depth Stack）

**效果：** 明确的前中后三层

**适用场景：**
- 图文穿插
- 立体感设计
- 复杂构图

**Prompt 关键词：**
```
three-layer depth stack
background layer (back) → middle layer → foreground layer (front)
explicit Z-order, depth hierarchy
layer {N} in front of layer {M}
```

**示例：**
```
[主体与背景] three-layer depth stack: background layer (back) → character silhouette layer (middle) → text foreground layer (front), explicit Z-order
```

---

#### 5.2 混合模式叠加（Blend Mode Overlay）

**效果：** 通过混合模式让叠加区域自然分离

**适用场景：**
- 叠加效果
- 保持层次同时融合
- 复杂色彩交互

**Prompt 关键词：**
```
multiply blend mode, screen blend, overlay blend
blend mode separation
natural tonal separation at overlap
```

**常用混合模式：**
| 模式 | 效果 | 适用 |
|------|------|------|
| Multiply | 变暗，保留暗部 | 暗色叠加 |
| Screen | 变亮，保留亮部 | 亮色叠加 |
| Overlay | 对比增强 | 通用 |
| Color Burn | 加深对比 | 强分离 |

**示例：**
```
[文案与背景] text layer with multiply blend mode over background, natural tonal separation
```

---

#### 5.3 交叉遮挡（Overlap Intersection）

**效果：** 元素相互穿插，通过前后关系分离

**适用场景：**
- 图文暴力穿插
- 动态构图
- 打破边界

**Prompt 关键词：**
```
overlap intersection, elements crossing
{element1} IN FRONT of {element2}
{element} BEHIND {other_element}
vertical sandwich depth
shadow casting at overlap
```

**示例：**
```
[文案与主体] title OVERLAPS character with hard edge intersection, top line in front casting shadow onto character, bottom line behind character silhouette, vertical sandwich creates brutal depth separation
```

---

### 叠加与层次类完整示例

```
[主体与背景区分] three-layer depth stack: background layer (back) → character silhouette layer (middle) → text foreground layer (front), explicit Z-order.

[文案与背景区分] text layer with multiply blend mode over background, natural tonal separation.

[文案与主体区分] title OVERLAPS character with hard edge intersection, top line in front casting shadow onto character, bottom line behind character silhouette, vertical sandwich creates brutal depth separation.
```

---

## 手法选择指南

### 按设计风格选择

| 风格 | 推荐手法 | 组合建议 |
|------|---------|---------|
| 像素风 | 描边 + 形状遮挡 | 硬切边 + 粗描边 |
| 赛博朋克 | 描边(外发光) + 色彩对比 | 霓虹发光 + 互补色 |
| 极简风 | 色彩对比 + 虚实 | 明度对比 + 模糊背景 |
| 拼贴风 | 叠加层次 + 形状遮挡 | Z轴层次 + 蒙版裁切 |
| 电影感 | 虚实 + 叠加层次 | 景深模糊 + 前后穿插 |

### 按问题场景选择

| 问题 | 解决手法 | 优先级 |
|------|---------|--------|
| 文案看不清 | 描边 / 色彩对比 | 高 |
| 主体融进背景 | 描边 / 虚实 | 中 |
| 文案粘着主体 | 叠加层次 / 形状遮挡 | 高 |
| 背景太抢眼 | 虚实 / 色彩对比 | 中 |
| 层次不清晰 | 叠加层次 | 高 |

### 按内容类型选择

| 内容类型 | 推荐手法组合 |
|---------|-------------|
| 科技/AI | 外发光 + 互补色 + 模糊背景 |
| 知识科普 | 明度对比 + 几何容器 |
| 情感故事 | 虚实 + 柔和叠加 |
| 游戏/电竞 | 粗描边 + 互补色 + Z轴层次 |
| Vlog生活 | 模糊背景 + 明度对比 |

---

## 组合使用建议

### 单一手法（简洁）

```
只用描边：适合极简设计，避免过度处理
只用色彩对比：适合扁平风格
只用虚实：适合摄影风格
```

### 双手法组合（推荐）

```
描边 + 色彩对比：双重保险，最强分离
虚实 + 叠加层次：模拟真实景深
形状遮挡 + 描边：几何感 + 边缘强化
```

### 三手法组合（复杂场景）

```
描边 + 色彩对比 + 叠加层次：赛博朋克风格
虚实 + 形状遮挡 + 叠加层次：电影感设计
```

---

## Prompt 组装模板

### 基础模板

```
[固定内容] {你的封面设计内容}

[区分手法]
[主体与背景区分] {手法描述}
[文案与背景区分] {手法描述}
[文案与主体区分] {手法描述}
```

### 示例：描边类

```
[固定内容] 16-bit pixel art, character holding paper, title "让AI来处理论文的AIGC查重率！", dark purple background.

[区分手法]
[主体与背景区分] character with neon magenta outline 12px + cyan drop shadow 18px.
[文案与背景区分] title with black stroke 8px + white glow.
[文案与主体区分] double stroke at intersection: white on text, magenta on character.
```

---

## 注意事项

1. **避免过度处理** — 太多手法会视觉混乱，推荐 1-2 种
2. **优先保证可读性** — 文案分离优先级最高
3. **保持风格一致** — 手法要匹配整体设计风格
4. **测试实际效果** — 不同 AI 工具对手法解析可能有差异
5. **组合时注意冲突** — 如"模糊背景"与"清晰纹理背景"矛盾

---

## 快速参考表

| 手法 | 核心关键词 | 最适用场景 |
|------|-----------|-----------|
| 描边 | stroke, outline, glow | 暗背景亮元素 |
| 色彩对比 | complementary, contrast | 强冲击设计 |
| 虚实 | blur, focus, DOF | 复杂背景 |
| 形状遮挡 | mask, container, clipping | 结构化设计 |
| 叠加层次 | layer, Z-order, overlap | 图文穿插 |
