#!/usr/bin/env python3
"""
Cover Prompt Forge - 用户偏好档案更新脚本
用于更新飞轮系统的用户档案数据
"""

import json
import sys
from datetime import datetime
from pathlib import Path


def load_profile(profile_path: str) -> dict:
    """加载用户档案"""
    with open(profile_path, 'r', encoding='utf-8') as f:
        return json.load(f)


def save_profile(profile: dict, profile_path: str):
    """保存用户档案"""
    with open(profile_path, 'w', encoding='utf-8') as f:
        json.dump(profile, f, ensure_ascii=False, indent=2)


def update_template_usage(profile: dict, template_id: str):
    """更新模板使用记录"""
    template_key = f"{template_id}"
    if template_key in profile["preferences"]["template_preferences"]:
        profile["preferences"]["template_preferences"][template_key]["used"] += 1
        profile["preferences"]["template_preferences"][template_key]["last_used"] = datetime.now().isoformat()
    else:
        # 新模板（用户自定义）
        profile["preferences"]["template_preferences"][template_key] = {
            "used": 1,
            "rating": 0,
            "last_used": datetime.now().isoformat()
        }


def update_color_preference(profile: dict, color_scheme: str, liked: bool = True):
    """更新配色偏好"""
    if liked:
        if color_scheme not in profile["preferences"]["color_preferences"]["liked"]:
            profile["preferences"]["color_preferences"]["liked"].append(color_scheme)
    else:
        if color_scheme not in profile["preferences"]["color_preferences"]["disliked"]:
            profile["preferences"]["color_preferences"]["disliked"].append(color_scheme)


def update_content_type(profile: dict, content_type: str):
    """更新内容类型统计"""
    if content_type not in profile["preferences"]["content_types"]:
        profile["preferences"]["content_types"][content_type] = 0
    profile["preferences"]["content_types"][content_type] += 1


def update_style_keywords(profile: dict, keywords: list, liked: bool = True):
    """更新风格关键词偏好"""
    target_list = "frequent" if liked else "avoided"
    for keyword in keywords:
        if keyword not in profile["preferences"]["style_keywords"][target_list]:
            profile["preferences"]["style_keywords"][target_list].append(keyword)


def add_history_record(profile: dict, record: dict):
    """添加历史记录"""
    record["timestamp"] = datetime.now().isoformat()
    profile["history"].append(record)
    
    # 限制历史记录数量（保留最近50条）
    if len(profile["history"]) > 50:
        profile["history"] = profile["history"][-50:]


def update_stats(profile: dict):
    """更新统计信息"""
    profile["stats"]["total_covers"] += 1
    
    # 计算最常用模板
    templates = profile["preferences"]["template_preferences"]
    if templates:
        favorite_template = max(templates.items(), key=lambda x: x[1]["used"])
        if favorite_template[1]["used"] > 0:
            profile["stats"]["favorite_template"] = favorite_template[0]


def main():
    """主函数 - 根据命令行参数更新档案"""
    if len(sys.argv) < 2:
        print("Usage: python update_profile.py <command> [args...]")
        print("Commands:")
        print("  template <template_id>          - 记录模板使用")
        print("  color <scheme> <liked|disliked> - 记录配色偏好")
        print("  content <type>                  - 记录内容类型")
        print("  style <keyword> <liked|disliked> - 记录风格偏好")
        print("  history <json_record>           - 添加历史记录")
        sys.exit(1)
    
    # 获取档案路径（相对于脚本位置）
    script_dir = Path(__file__).parent.parent
    profile_path = script_dir / "assets" / "user-profile.json"
    
    # 加载档案
    profile = load_profile(profile_path)
    
    command = sys.argv[1]
    
    if command == "template" and len(sys.argv) >= 3:
        template_id = sys.argv[2]
        update_template_usage(profile, template_id)
        update_stats(profile)
        print(f"✓ Updated template usage: {template_id}")
        
    elif command == "color" and len(sys.argv) >= 4:
        color_scheme = sys.argv[2]
        liked = sys.argv[3] == "liked"
        update_color_preference(profile, color_scheme, liked)
        if liked:
            profile["stats"]["favorite_color_scheme"] = color_scheme
        print(f"✓ Updated color preference: {color_scheme} ({'liked' if liked else 'disliked'})")
        
    elif command == "content" and len(sys.argv) >= 3:
        content_type = sys.argv[2]
        update_content_type(profile, content_type)
        print(f"✓ Updated content type: {content_type}")
        
    elif command == "style" and len(sys.argv) >= 4:
        keyword = sys.argv[2]
        liked = sys.argv[3] == "liked"
        update_style_keywords(profile, [keyword], liked)
        print(f"✓ Updated style preference: {keyword} ({'liked' if liked else 'disliked'})")
        
    elif command == "history" and len(sys.argv) >= 3:
        try:
            record = json.loads(sys.argv[2])
            add_history_record(profile, record)
            print(f"✓ Added history record")
        except json.JSONDecodeError:
            print("✗ Invalid JSON record")
            sys.exit(1)
    else:
        print("✗ Invalid command or arguments")
        sys.exit(1)
    
    # 保存档案
    save_profile(profile, profile_path)
    print(f"✓ Profile saved to {profile_path}")


if __name__ == "__main__":
    main()
